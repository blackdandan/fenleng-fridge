import { FenlengSdkError, resolveFenlengAuthConfig } from '@fenleng/sdk-core';

export class TaroAuthSDK {
  constructor(client, config = {}) {
    if (!client?.storage || typeof client.tokenKey !== 'string') throw new FenlengSdkError('CONFIGURATION_INVALID', 'TaroAuthSDK requires a configured client and storage');
    this.identity = resolveFenlengAuthConfig(config, 'miniapp');
    this.client = client;
    this.refreshKey = `${client.tokenKey}:refresh`;
    this.generation = 0;
    this.authInFlight = null;
    this.refreshInFlight = null;
    this.logoutInFlight = null;
  }
  requestRegistrationEmailVerification(email, options = {}) {
    return this.client.request('/api/platform/v1/auth/registration-email-verification', 'POST', this.input({email}), options);
  }
  register(input, options = {}) {
    if (!input?.verificationCode) return Promise.reject(new FenlengSdkError('VALIDATION_FAILED', 'verificationCode is required'));
    return this.authenticate(() => this.client.request('/api/platform/v1/auth/register', 'POST', this.input(input), options));
  }
  loginWithPassword(email, password, {device, ...options} = {}) {
    return this.authenticate(() => this.client.request('/api/platform/v1/auth/login', 'POST', this.input({email, password, ...(device ? {device} : {})}), options));
  }
  loginWithWechatCode(code, options = {}) { return this.loginWithCode('wechat', code, options); }
  loginWithAlipayCode(code, options = {}) { return this.loginWithCode('alipay', code, options); }
  loginWithDouyinCode(code, options = {}) { return this.loginWithCode('douyin', code, options); }
  loginWithCode(provider, code, {device, ...options} = {}) {
    if (typeof code !== 'string' || !code.trim() || code.length > 1024) return Promise.reject(new FenlengSdkError('VALIDATION_FAILED', 'Platform authorization code is invalid'));
    if (!['wechat','alipay','douyin'].includes(provider)) return Promise.reject(new FenlengSdkError('CONFIGURATION_INVALID', 'Login provider is unsupported'));
    return this.authenticate(() => this.client.request(`/api/platform/v1/auth/${provider}/login`, 'POST', this.input({code, ...(device ? {device} : {})}), options));
  }
  input(value) { return {...value, applicationCode:this.identity.applicationCode, clientId:this.identity.clientId}; }
  authenticate(action) {
    if (this.authInFlight || this.refreshInFlight || this.logoutInFlight) return Promise.reject(pending());
    const generation = this.generation;
    const operation = Promise.resolve().then(action).then(tokens => this.accept(tokens, generation));
    this.authInFlight = operation;
    return operation.finally(() => { if (this.authInFlight === operation) this.authInFlight = null; });
  }
  refresh(options = {}) {
    if (this.refreshInFlight) return this.refreshInFlight;
    if (this.authInFlight || this.logoutInFlight) return Promise.reject(pending());
    const generation = this.generation;
    this.refreshInFlight = (async () => {
      const refreshToken = await this.client.storage.getItem(this.refreshKey);
      if (!refreshToken) {await this.clear();throw new FenlengSdkError('SESSION_MISSING', 'No refresh token is available');}
      try {
        const tokens = await this.client.request('/api/platform/v1/auth/refresh', 'POST', {refreshToken}, options);
        return await this.accept(tokens, generation);
      } catch (error) {
        if (error.status === 401 && generation === this.generation) {
          try {await this.clear();} catch(cause) {throw new FenlengSdkError('SESSION_CLEANUP_FAILED','Local session cleanup failed',{status:401,cause});}
        }
        throw error;
      }
    })().finally(() => { this.refreshInFlight = null; });
    return this.refreshInFlight;
  }
  async accept(tokens, generation) {
    if (generation !== this.generation) throw changed();
    try {await this.storeTokens(tokens);} catch(error) {await this.clear();throw error;}
    if (generation !== this.generation) { await this.clear(); throw changed(); }
    return tokens;
  }
  async storeTokens(tokens) {
    if (![tokens?.accessToken,tokens?.refreshToken].every(value => typeof value === 'string' && value.trim() && !/[\r\n]/.test(value))) throw new FenlengSdkError('TOKEN_RESPONSE_INVALID', 'Platform returned an invalid token response');
    try {
      await this.client.storage.setItem(this.client.tokenKey, tokens.accessToken);
      await this.client.storage.setItem(this.refreshKey, tokens.refreshToken);
    } catch (error) { await this.clear(); throw error; }
  }
  async accessToken() { return this.client.storage.getItem(this.client.tokenKey); }
  async clear() {
    const results = await Promise.allSettled([this.client.storage.removeItem(this.client.tokenKey), this.client.storage.removeItem(this.refreshKey)]);
    const failure = results.find(result => result.status === 'rejected');
    if (failure) throw failure.reason;
  }
  logout(options = {}) {
    if (this.logoutInFlight) return this.logoutInFlight;
    ++this.generation;
    const wait = [this.authInFlight, this.refreshInFlight];
    this.logoutInFlight = (async () => {
      await Promise.allSettled(wait);
      try {
        const refreshToken = await this.client.storage.getItem(this.refreshKey);
        if (refreshToken && !options.localOnly) await this.client.request('/api/platform/v1/auth/logout', 'POST', {refreshToken, allSessions:Boolean(options.allSessions)});
      } finally { await this.clear(); }
    })().finally(() => { this.logoutInFlight = null; });
    return this.logoutInFlight;
  }
  endLocalSession() { return this.logout({localOnly:true}); }
}
function pending() { return new FenlengSdkError('IDENTITY_OPERATION_PENDING', 'Another identity operation is pending'); }
function changed() { return new FenlengSdkError('SESSION_CHANGED', 'The original identity session has ended'); }
