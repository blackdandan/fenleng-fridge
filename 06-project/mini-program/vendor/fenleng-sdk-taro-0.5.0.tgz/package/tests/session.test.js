import test from 'node:test';
import assert from 'node:assert/strict';
import {TaroAuthSDK,TaroSessionCoordinator,TaroStorageAdapter,MemoryStorageAdapter,FenlengSdkError} from '../index.js';
const tokens=n=>({accessToken:`access-${n}`,refreshToken:`refresh-${n}`,expiresIn:900});
const config={applicationCode:'patent-app',clientId:'patent-miniapp'};
function deferred(){let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});return {promise,resolve,reject};}
function fixture(handler=async()=>tokens(1)){
 const storage=new MemoryStorageAdapter(),calls=[];const client={storage,tokenKey:'session-v1',request:(...args)=>{calls.push(args);return handler(...args);}};
 const auth=new TaroAuthSDK(client,config);return {auth,storage,calls};
}
function clock(){const tasks=new Map();let id=0;return {tasks,setTimeout(fn){tasks.set(++id,fn);return id;},clearTimeout(key){tasks.delete(key);}};}
test('Taro storage survives adapter recreation, isolates namespace and fails on corrupt values',async()=>{
 const values=new Map(),driver={getStorageSync:key=>values.get(key),setStorageSync:(key,value)=>values.set(key,value),removeStorageSync:key=>values.delete(key)};
 const first=new TaroStorageAdapter(driver,{prefix:'patent:'});await first.setItem('session','stored');assert.equal(await new TaroStorageAdapter(driver,{prefix:'patent:'}).getItem('session'),'stored');assert.equal(await new TaroStorageAdapter(driver,{prefix:'other:'}).getItem('session'),null);values.set('patent:session',{invalid:true});await assert.rejects(first.getItem('session'),e=>e.code==='STORAGE_VALUE_INVALID');await first.removeItem('session');assert.equal(await first.getItem('session'),null);assert.throws(()=>new TaroStorageAdapter(),e=>e.code==='CONFIGURATION_INVALID');
});
test('each platform code uses its own exchange route and never persists code',async()=>{
 for(const [method,provider] of [['loginWithWechatCode','wechat'],['loginWithAlipayCode','alipay'],['loginWithDouyinCode','douyin']]){
  const f=fixture();await f.auth[method]('one-use-code');assert.equal(f.calls[0][0],`/api/platform/v1/auth/${provider}/login`);assert.deepEqual(f.calls[0][2],{applicationCode:config.applicationCode,clientId:config.clientId,code:'one-use-code'});assert.deepEqual([...f.storage.store.values()],['access-1','refresh-1']);
 }
});
test('registration owns its application identity and persists the one atomic response',async()=>{
 const f=fixture();await f.auth.register({applicationCode:'override',clientId:'override',verificationCode:'code',email:'synthetic'});assert.equal(f.calls.length,1);assert.equal(f.calls[0][2].applicationCode,config.applicationCode);assert.equal(f.calls[0][2].clientId,config.clientId);assert.equal(await f.auth.accessToken(),'access-1');
});
test('refresh is one flight and persists rotated tokens',async()=>{
 const gate=deferred(),f=fixture(()=>gate.promise);await f.auth.storeTokens(tokens(1));const first=f.auth.refresh(),second=f.auth.refresh();assert.equal(first,second);await Promise.resolve();assert.equal(f.calls.length,1);assert.equal(f.calls[0][2].refreshToken,'refresh-1');gate.resolve(tokens(2));await first;assert.equal(await f.auth.accessToken(),'access-2');
});
test('logout invalidates pending login before any late token can survive',async()=>{
 const gate=deferred(),f=fixture(()=>gate.promise);const login=f.auth.loginWithDouyinCode('code');await Promise.resolve();const rejected=assert.rejects(login,e=>e.code==='SESSION_CHANGED');const logout=f.auth.logout();await assert.rejects(f.auth.register({verificationCode:'code'}),e=>e.code==='IDENTITY_OPERATION_PENDING');gate.resolve(tokens(1));await rejected;await logout;assert.equal(f.storage.store.size,0);
});
test('partial token persistence failure clears both token keys',async()=>{
 const f=fixture();const set=f.storage.setItem.bind(f.storage);f.storage.setItem=async(key,value)=>{if(key.endsWith(':refresh'))throw Error('quota');await set(key,value);};await assert.rejects(f.auth.loginWithWechatCode('code'),/quota/);assert.equal(f.storage.store.size,0);
});
test('consent required does zero storage or network; new consent restores anonymous then explicit login',async()=>{
 const f=fixture(),timers=clock(),session=new TaroSessionCoordinator(f.auth,{timers});let reads=0;const get=f.storage.getItem.bind(f.storage);f.storage.getItem=async key=>{reads++;return get(key);};await session.start();assert.equal(reads,0);assert.equal(f.calls.length,0);await session.start({consent:true});assert.equal(session.snapshot().status,'anonymous');assert.equal(f.calls.length,0);await session.loginWithCode('wechat','code');assert.equal(session.snapshot().status,'authenticated');assert.equal(timers.tasks.size,1);await session.close();assert.equal(timers.tasks.size,0);assert.equal(await f.auth.accessToken(),'access-1');
});
test('suspend stops timer; resume refresh keeps original session scope',async()=>{
 let count=0;const f=fixture(async()=>tokens(++count)),timers=clock(),session=new TaroSessionCoordinator(f.auth,{timers});await session.start({consent:true});await session.loginWithCode('alipay','code');const active=session.captureSession();session.suspend();assert.equal(timers.tasks.size,0);await session.resume();assert.equal(f.calls.length,2);assert.equal(active(),true);assert.equal(await session.accessToken(),'access-2');assert.equal(timers.tasks.size,1);await session.close();
});
test('401 refresh expires session and prevents access or timer loops',async()=>{
 let fail=false;const f=fixture(async()=>{if(fail)throw new FenlengSdkError('AUTHENTICATION_REQUIRED','expired',{status:401});return tokens(1);});const timers=clock(),session=new TaroSessionCoordinator(f.auth,{timers});await session.start({consent:true});await session.loginWithCode('wechat','code');const active=session.captureSession();fail=true;await assert.rejects(session.refresh());assert.equal(session.snapshot().status,'reauthentication-required');assert.equal(active(),false);assert.equal(await session.accessToken(),null);assert.equal(f.storage.store.size,0);assert.equal(timers.tasks.size,0);await session.close();
});
test('consent withdrawal during login clears late session and cannot publish authenticated',async()=>{
 const gate=deferred(),f=fixture(()=>gate.promise),session=new TaroSessionCoordinator(f.auth,{timers:clock()});await session.start({consent:true});const login=session.loginWithCode('douyin','code');await Promise.resolve();const rejected=assert.rejects(login,e=>e.code==='SESSION_CHANGED');const withdrawn=session.withdrawConsent();gate.resolve(tokens(1));await rejected;await withdrawn;assert.equal(session.snapshot().status,'consent-required');assert.equal(f.storage.store.size,0);await session.close();
});
test('restoration network failure remains recoverable and never exposes stale token',async()=>{
 let fail=true;const f=fixture(async()=>{if(fail)throw new FenlengSdkError('NETWORK_ERROR','offline');return tokens(2);});await f.auth.storeTokens(tokens(1));const session=new TaroSessionCoordinator(f.auth,{timers:clock()});await assert.rejects(session.start({consent:true}));assert.equal(session.snapshot().status,'error');assert.equal(await session.accessToken(),null);fail=false;await session.resume();assert.equal(await session.accessToken(),'access-2');await session.close();
});
test('timer and explicit read recovery refresh share the same rotation',async()=>{
 let gate=null;const f=fixture(()=>gate?gate.promise:Promise.resolve(tokens(1))),timers=clock(),session=new TaroSessionCoordinator(f.auth,{timers});await session.start({consent:true});await session.loginWithCode('wechat','code');gate=deferred();const callback=[...timers.tasks.values()][0];timers.tasks.clear();callback();const first=session.refresh(),second=session.refresh();assert.equal(first,second);await Promise.resolve();assert.equal(f.calls.length,2);gate.resolve(tokens(2));await first;assert.equal(timers.tasks.size,1);await session.close();
});
test('logout while persistence is paused clears tokens after the write completes',async()=>{
 const f=fixture(),gate=deferred();const write=f.storage.setItem.bind(f.storage);let blocked=false;
 f.storage.setItem=async(key,value)=>{await write(key,value);if(key.endsWith(':refresh')){blocked=true;await gate.promise;}};
 const login=f.auth.loginWithWechatCode('code');const rejected=assert.rejects(login,e=>e.code==='SESSION_CHANGED');while(!blocked)await Promise.resolve();const logout=f.auth.logout();gate.resolve();await rejected;await logout;assert.equal(f.storage.store.size,0);
});
test('invalid registration metadata clears its session before publishing authenticated',async()=>{
 const f=fixture(async()=>({...tokens(1),userId:'user',applicationId:'app',email:'other@example.test',username:'person',displayName:'Person'}));const session=new TaroSessionCoordinator(f.auth,{timers:clock()});await session.start({consent:true});await assert.rejects(session.register({email:'expected@example.test',verificationCode:'code'}),e=>e.code==='INVALID_REGISTRATION_RESPONSE');assert.equal(session.snapshot().status,'error');assert.equal(f.storage.store.size,0);await session.close();
});
test('storage cleanup failure cannot report successful logout or expose old credentials',async()=>{
 const f=fixture(),session=new TaroSessionCoordinator(f.auth,{timers:clock()});await session.start({consent:true});await session.loginWithCode('wechat','code');const remove=f.storage.removeItem.bind(f.storage);f.storage.removeItem=async()=>{throw Error('storage unavailable');};await assert.rejects(session.logout({localOnly:true}));assert.equal(session.snapshot().status,'error');assert.equal(await session.accessToken(),null);await assert.rejects(session.loginWithCode('wechat','code'),e=>e.code==='IDENTITY_NOT_READY');f.storage.removeItem=remove;await session.start({consent:true});assert.equal(session.snapshot().status,'anonymous');await session.close();
});
test('401 followed by failed storage clear never keeps an authenticated session',async()=>{
 let reject=false;const f=fixture(async()=>{if(reject)throw new FenlengSdkError('AUTHENTICATION_REQUIRED','expired',{status:401});return tokens(1);});const session=new TaroSessionCoordinator(f.auth,{timers:clock()});await session.start({consent:true});await session.loginWithCode('wechat','code');reject=true;const remove=f.storage.removeItem.bind(f.storage);f.storage.removeItem=async()=>{throw Error('storage unavailable');};await assert.rejects(session.refresh(),e=>e.code==='SESSION_CLEANUP_FAILED');assert.equal(session.snapshot().status,'reauthentication-required');assert.equal(await session.accessToken(),null);f.storage.removeItem=remove;await session.invalidate();assert.equal(f.storage.store.size,0);assert.equal(session.snapshot().status,'reauthentication-required');await session.close();
});
