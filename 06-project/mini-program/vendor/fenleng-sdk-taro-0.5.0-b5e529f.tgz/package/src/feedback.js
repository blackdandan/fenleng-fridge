import {FenlengSdkError} from '@fenleng/sdk-core';

/** Text-only feedback; no implicit identity creation or attachment collection. */
export class TaroFeedbackSDK {
  constructor(client, {projectId, version}) {
    if (!client?.request || !projectId || !version) throw invalid();
    this.client = client; this.projectId = projectId; this.version = version;
  }
  async submit(message, idempotencyKey, {signal} = {}) {
    if (typeof message !== 'string' || !message.trim() || message.trim().length > 4000 ||
        typeof idempotencyKey !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._:-]{7,127}$/.test(idempotencyKey)) throw invalid();
    const result = await this.client.request('/api/platform/v1/feedback', 'POST', {
      projectId:this.projectId, version:this.version, traceId:null,
      message:message.trim(), attachmentConsent:false, attachments:[],
    }, {idempotencyKey, signal});
    if (result?.status !== 'RECEIVED' || typeof result.id !== 'string' ||
        !result.id.trim() || result.id.length > 128 || /[\r\n]/.test(result.id)) {
      throw new FenlengSdkError('FEEDBACK_RESPONSE_INVALID', 'Feedback receipt was not confirmed');
    }
    return {id:result.id, status:'RECEIVED'};
  }
}
function invalid() {return new FenlengSdkError('VALIDATION_FAILED', 'Feedback configuration or input is invalid');}
