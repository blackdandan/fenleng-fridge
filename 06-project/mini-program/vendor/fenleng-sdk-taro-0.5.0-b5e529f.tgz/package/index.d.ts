export interface TaroAuthConfig {readonly applicationCode:string;readonly clientId?:string|null;readonly clientTarget?:string|null;}
export interface TaroStorage {getItem(key:string):Promise<string|null>;setItem(key:string,value:string):Promise<void>;removeItem(key:string):Promise<void>;}
export interface TaroRequestOptions {signal?:AbortSignal;timeoutMs?:number;idempotencyKey?:string;actionConfirmationId?:string;traceId?:string;headers?:Record<string,string>;authentication?:'session'|'none';}
export interface TaroSdkClient {readonly storage:TaroStorage;readonly tokenKey:string;request(endpoint:string,method?:string,body?:unknown,options?:TaroRequestOptions):Promise<any>;}
export interface TaroStorageDriver {getStorageSync(key:string):unknown;setStorageSync(key:string,value:string):void;removeStorageSync(key:string):void;}
export class TaroStorageAdapter implements TaroStorage {
 constructor(driver:TaroStorageDriver,options?:{prefix?:string});
 getItem(key:string):Promise<string|null>;setItem(key:string,value:string):Promise<void>;removeItem(key:string):Promise<void>;
}
export interface TaroNativeRequest {
 url:string;method:string;data:unknown;header:Record<string,string>;timeout:number;
 success(response:{statusCode:number;data:unknown;header?:Record<string,string>}):void;
 fail(error:{errMsg?:string}):void;
}
export class TaroPlatformClient implements TaroSdkClient {
 constructor(options:{baseUrl:string;storage:TaroStorage;request:(input:TaroNativeRequest)=>unknown;tokenKey?:string;timeoutMs?:number});
 readonly storage:TaroStorage;readonly tokenKey:string;
 request(endpoint:string,method?:string,body?:unknown,options?:TaroRequestOptions):Promise<any>;
}
export interface TaroRegistrationInput {readonly email:string;readonly password:string;readonly username:string;readonly displayName:string;readonly verificationCode:string;readonly device?:unknown;}
export type TaroIdentityProvider='wechat'|'alipay'|'douyin';
export type TaroDeletionProvider='FIREBASE'|'APPLE'|'WECHAT';
export interface TaroDeletionChallenge {readonly challengeId:string;readonly provider:TaroDeletionProvider;readonly nonce:string;readonly expiresAt:string;}
export interface TaroDeletionConfirmation {readonly confirmationId:string;readonly deletionIdempotencyKey:string;readonly expiresAt:string;}
export interface TaroCurrentUser {readonly id:string;readonly kind:string;readonly status:string;}
export interface TaroUserDataRequest {
 readonly id:string;readonly userId:string;readonly type:'EXPORT'|'DELETE';
 readonly status:'PENDING'|'IN_PROGRESS'|'BLOCKED'|'FAILED'|'COMPLETED'|'CANCELLED';
 readonly requestedAt:string;readonly updatedAt:string;readonly version:number;readonly attemptCount:number;
 readonly nextAttemptAt:string|null;readonly blockingReason:string|null;readonly failureCode:string|null;readonly completionEvidence:string|null;
}
export class TaroAuthSDK {
 constructor(client:TaroSdkClient,config:TaroAuthConfig);
 readonly sessionKind:'guest'|'account';
 loginAsGuest(options?:Pick<TaroRequestOptions,'signal'|'timeoutMs'>&{device?:unknown}):Promise<Record<string,unknown>>;
 loginWithWechatCode(code:string,options?:TaroRequestOptions&{device?:unknown}):Promise<Record<string,unknown>>;
 loginWithAlipayCode(code:string,options?:TaroRequestOptions&{device?:unknown}):Promise<Record<string,unknown>>;
 loginWithDouyinCode(code:string,options?:TaroRequestOptions&{device?:unknown}):Promise<Record<string,unknown>>;
 loginWithCode(provider:TaroIdentityProvider,code:string,options?:TaroRequestOptions&{device?:unknown}):Promise<Record<string,unknown>>;
 loginWithPassword(email:string,password:string,options?:TaroRequestOptions&{device?:unknown}):Promise<Record<string,unknown>>;
 requestRegistrationEmailVerification(email:string,options?:TaroRequestOptions):Promise<Record<string,unknown>>;
 register(input:TaroRegistrationInput,options?:TaroRequestOptions):Promise<Record<string,unknown>>;
 createFederatedDeletionChallenge(provider:TaroDeletionProvider,deletionIdempotencyKey:string,options?:TaroRequestOptions):Promise<TaroDeletionChallenge>;
 confirmFederatedDeletionReauthentication(challengeId:string,identityToken:string,options?:TaroRequestOptions):Promise<TaroDeletionConfirmation>;
 dataRequests(options?:TaroRequestOptions):Promise<{items:TaroUserDataRequest[];page:{nextCursor:string|null;hasMore:boolean}}>;
 currentUser(options?:TaroRequestOptions):Promise<TaroCurrentUser>;
 requestData(type:'EXPORT'|'DELETE',idempotencyKey:string,options?:TaroRequestOptions&{actionConfirmationId?:string}):Promise<TaroUserDataRequest>;
 refresh(options?:TaroRequestOptions):Promise<Record<string,unknown>>;
 logout(options?:{allSessions?:boolean;localOnly?:boolean}):Promise<void>;
 endLocalSession():Promise<void>;accessToken():Promise<string|null>;
}
export type TaroSessionStatus='consent-required'|'anonymous'|'authenticating'|'authenticated'|'restoring'|'ending'|'reauthentication-required'|'binding-required'|'blocked'|'error';
export class TaroFeedbackSDK {
 constructor(client:TaroSdkClient,config:{projectId:string;version:string});
 submit(message:string,idempotencyKey:string,options?:{signal?:AbortSignal}):Promise<{id:string;status:'RECEIVED'}>;
}
export interface TaroMiniReminderDay {readonly day:string;readonly fireAt:string;readonly count:number;}
export interface TaroMiniReminderSnapshot {readonly timezone:string;readonly language:'zh_CN'|'zh_TW'|'zh_HK'|'en_US';readonly days:readonly TaroMiniReminderDay[];}
export interface TaroMiniReminderReceipt extends TaroMiniReminderSnapshot {
 readonly id:string;readonly revision:number;readonly templateId:string;readonly revoked:boolean;readonly observedAcceptances:number;
}
export type TaroMiniObservation='accept'|'reject'|'ban'|'filter';
export interface TaroMiniReminderConfiguration {
 readonly configured:boolean;readonly templateId:string|null;readonly requiresWechatSession:true;readonly allowanceSource:'client-observation';
}
export interface TaroMiniReminderStatus {
 readonly plan:TaroMiniReminderReceipt;
 readonly deliveries:readonly {readonly day:string;readonly status:'PENDING'|'WAITING_PERMISSION'|'SENDING'|'ACCEPTED'|'UNCONFIRMED'|'FAILED'|'CANCELLED'|'EXPIRED';readonly attempts:number;readonly code:string|null}[];
}
export class TaroMiniReminderSDK {
 constructor(client:TaroSdkClient);
 configuration(options?:TaroRequestOptions):Promise<TaroMiniReminderConfiguration>;
 replace(input:TaroMiniReminderSnapshot&{installationId:string;cancellationToken:string;revision:number},options?:TaroRequestOptions):Promise<TaroMiniReminderReceipt>;
 observe(input:{cancellationToken:string;grantId:string;templateId:string;result:TaroMiniObservation},options?:TaroRequestOptions):Promise<TaroMiniReminderReceipt>;
 status(id:string,options?:TaroRequestOptions):Promise<TaroMiniReminderStatus>;
 revoke(cancellationToken:string,options?:TaroRequestOptions):Promise<{revoked:true}>;
}
/** Single owner. Durable capability storage must survive auth cleanup; randomBytes must be cryptographic. */
export class TaroMiniReminderPlan {
 constructor(sdk:TaroMiniReminderSDK,options:{storage:TaroStorage;randomBytes:(length:number)=>Promise<Uint8Array|ArrayBuffer>;storageKey?:string});
 prepare():Promise<{installationId:string;revision:number;hasPlan:boolean}>;
 sync(snapshot:TaroMiniReminderSnapshot,options?:TaroRequestOptions):Promise<TaroMiniReminderReceipt>;
 observe(templateId:string,result:TaroMiniObservation,options?:TaroRequestOptions):Promise<TaroMiniReminderReceipt|null>;
 retryObservations(options?:TaroRequestOptions):Promise<TaroMiniReminderReceipt|null>;
 status(options?:TaroRequestOptions):Promise<TaroMiniReminderStatus|null>;
 revoke(options?:TaroRequestOptions):Promise<{revoked:true}>;
}
export interface TaroSessionSnapshot {readonly status:TaroSessionStatus;readonly refreshing:boolean;readonly errorCode:string|null;readonly identityKind?:'guest'|'account'|null;}
export class TaroSessionCoordinator {
 constructor(auth:TaroAuthSDK,options?:{refreshIntervalMs?:number;timers?:{setTimeout(callback:()=>void,ms:number):unknown;clearTimeout(id:unknown):void}});
 snapshot():TaroSessionSnapshot;subscribe(listener:()=>void):()=>void;captureSession():()=>boolean;accessToken():Promise<string|null>;
 start(options?:{consent?:boolean}):Promise<unknown>;restore():Promise<unknown>;
 loginAsGuest(options?:Pick<TaroRequestOptions,'signal'|'timeoutMs'>&{device?:unknown}):Promise<unknown>;
 loginWithCode(provider:TaroIdentityProvider,code:string,options?:TaroRequestOptions):Promise<unknown>;
 loginWithPassword(email:string,password:string,options?:TaroRequestOptions):Promise<unknown>;
 register(input:TaroRegistrationInput,options?:TaroRequestOptions):Promise<unknown>;
 requestRegistrationEmailVerification(email:string,options?:TaroRequestOptions):Promise<Record<string,unknown>>;
 refresh():Promise<unknown>;suspend():void;resume():Promise<unknown>;
 logout(options?:{localOnly?:boolean}):Promise<void>;invalidate():Promise<void>;withdrawConsent():Promise<void>;close():Promise<void>;
}
export interface TelemetryContext {
 readonly platform:'ios'|'android'|'ohos'|'web'|'mini-program';readonly appVersion:string;readonly buildNumber:string;
 readonly releaseChannel:'china'|'global'|'internal';readonly locale:string;readonly sessionId?:string;
}
export class TaroTelemetrySDK {
 constructor(client:TaroSdkClient,options:{catalog:readonly string[];consent:()=>boolean;context:()=>TelemetryContext;maxQueueSize?:number;batchSize?:number;deliveryIdFactory?:()=>string|Promise<string>});
 track(eventName:string,properties?:Readonly<Record<string,unknown>>,options?:{timestamp?:string}):unknown;flush(options?:TaroRequestOptions):Promise<number>;withdrawConsent():void;readonly pendingCount:number;
}
export type MiniPaymentPresentation='WECHAT_MINI_PROGRAM'|'ALIPAY_MINI_PROGRAM'|'DOUYIN_MINI_PROGRAM';
export class TaroCommerceSDK {
 constructor(client:TaroSdkClient);
 purchaseAgreement(priceOptionId:string,options?:TaroRequestOptions):Promise<unknown>;
 createOrder(priceOptionId:string,idempotencyKey:string,options?:TaroRequestOptions&{agreementConfirmation?:unknown}):Promise<unknown>;
 order(orderId:string,options?:TaroRequestOptions):Promise<unknown>;
 payment(attemptId:string,options?:TaroRequestOptions):Promise<unknown>;
 reconcilePayment(attemptId:string,idempotencyKey:string,options?:TaroRequestOptions):Promise<unknown>;
 cancelPayment(attemptId:string,idempotencyKey:string,options?:TaroRequestOptions):Promise<unknown>;
 startPayment(orderId:string,provider:'wechat-pay'|'alipay'|'douyin-pay',options:{presentation:MiniPaymentPresentation;idempotencyKey:string;returnUrl?:null}&TaroRequestOptions):Promise<unknown>;
 requestWechatPayment(orderId:string,idempotencyKey:string,options?:TaroRequestOptions):Promise<unknown>;
}
export type TaroPaymentPhase='ready'|'invoking'|'checking'|'pending'|'paid'|'cancelled'|'refunded'|'partially-refunded'|'closing'|'unknown'|'closed';
export interface TaroPaymentSnapshot {readonly phase:TaroPaymentPhase;readonly hostOutcome:string|null;readonly errorCode:string|null;}
export class TaroPaymentSession {
 constructor(commerce:Pick<TaroCommerceSDK,'order'|'cancelPayment'>,options:{orderId:string;attemptId:string;invoke:(payload:unknown)=>Promise<{kind:string}>;isSessionActive?:()=>boolean});
 snapshot():TaroPaymentSnapshot;subscribe(listener:()=>void):()=>void;
 launch(payload:unknown):Promise<unknown>;check():Promise<unknown>;cancel(idempotencyKey:string):Promise<unknown>;close():void;
}
