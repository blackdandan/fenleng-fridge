import test from 'node:test';
import assert from 'node:assert/strict';
import {createServer,request as httpRequest} from 'node:http';
import {TaroMiniReminderSDK,TaroMiniReminderPlan,TaroPlatformClient,MemoryStorageAdapter} from '../index.js';

const id='b'.repeat(64),token='a'.repeat(64);
const snapshot=()=>({timezone:'Asia/Shanghai',language:'zh_CN',days:[{day:'2026-11-13',fireAt:'2026-11-13T09:00:00Z',count:3}]});
const receipt=()=>({id,revision:1,templateId:'template-1',revoked:false,observedAcceptances:0,...snapshot()});
const input=()=>({...snapshot(),installationId:'installation-0001',cancellationToken:token,revision:1});
test('configuration preserves observed source and rejects unverified allowance claims',async()=>{
 let result={configured:true,templateId:'template-1',requiresWechatSession:true,allowanceSource:'client-observation',private:'not returned'};
 const sdk=new TaroMiniReminderSDK({request:async()=>result});
 assert.deepEqual(await sdk.configuration(),{configured:true,templateId:'template-1',requiresWechatSession:true,allowanceSource:'client-observation'});
 result={...result,allowanceSource:'verified-wechat-quota'};await assert.rejects(sdk.configuration(),e=>e.code==='MINI_RESPONSE_INVALID');
 result={configured:false,templateId:null,requiresWechatSession:true,allowanceSource:'client-observation'};assert.equal((await sdk.configuration()).configured,false);
});
test('invalid days versions capabilities and grant results issue no request',async()=>{
 let calls=0;const sdk=new TaroMiniReminderSDK({request:async()=>{calls++;return receipt();}});
 for(const patch of [{revision:2**53},{cancellationToken:'invalid'},{installationId:'short'},
  {days:[{...snapshot().days[0],day:'2026-02-30'}]},{days:[{...snapshot().days[0],fireAt:'2026-11-13T09:00:00'}]},
  {days:[...snapshot().days,...snapshot().days]},{days:[{...snapshot().days[0],count:0}]}]) {
  await assert.rejects(sdk.replace({...input(),...patch}),e=>e.code==='VALIDATION_FAILED');
 }
 await assert.rejects(sdk.observe({cancellationToken:token,grantId:'grant-unique-00001',templateId:'template-1',result:'unknown'}),e=>e.code==='VALIDATION_FAILED');
 assert.equal(calls,0);
});
test('plan responses trim storage metadata and malformed successful responses remain unconfirmed',async()=>{
 let result={...receipt(),owner:{userId:'private'},cancellationToken:token};
 const sdk=new TaroMiniReminderSDK({request:async()=>result});
 const plan=await sdk.replace(input());assert.equal(plan.owner,undefined);assert.equal(plan.cancellationToken,undefined);
 result={...receipt(),revision:null};await assert.rejects(sdk.replace(input()),e=>e.code==='MINI_RESPONSE_INVALID');
 result={revoked:false};await assert.rejects(sdk.revoke(token),e=>e.code==='MINI_RESPONSE_INVALID');
});
test('status distinguishes accepted and unknown outcomes and rejects foreign or duplicate days',async()=>{
 let result={plan:receipt(),deliveries:[{day:'2026-11-13',status:'UNCONFIRMED',attempts:1,code:'WECHAT_RESPONSE_UNCONFIRMED',openId:'private'}]};
 const sdk=new TaroMiniReminderSDK({request:async()=>result});
 assert.deepEqual((await sdk.status(id)).deliveries,[{day:'2026-11-13',status:'UNCONFIRMED',attempts:1,code:'WECHAT_RESPONSE_UNCONFIRMED'}]);
 result.deliveries[0].status='ACCEPTED';assert.equal((await sdk.status(id)).deliveries[0].status,'ACCEPTED');
 result.deliveries.push({...result.deliveries[0]});await assert.rejects(sdk.status(id),e=>e.code==='MINI_RESPONSE_INVALID');
 result.deliveries=[{day:'2026-11-14',status:'PENDING',attempts:0,code:null}];await assert.rejects(sdk.status(id),e=>e.code==='MINI_RESPONSE_INVALID');
});

/** Local HTTP integration exercises the actual SDK and Taro callback transport, not a WeChat host. */
test('real local HTTP cancellation works after auth storage is sealed and a lost PUT is not replayed automatically',async()=>{
 const observed=[];let dropped=false;
 const server=createServer((request,response)=>{
  const chunks=[];request.on('data',chunk=>chunks.push(chunk));request.on('end',()=>{
   const body=JSON.parse(Buffer.concat(chunks).toString() || 'null');observed.push({path:request.url,authorization:request.headers.authorization,body});
   if(request.url.endsWith('/plans') && !dropped){dropped=true;request.socket.destroy();return;}
   const result=request.url.endsWith('/revoke')?{revoked:true}:{...receipt(),revision:body.revision,days:body.days};
   response.writeHead(200,{'Content-Type':'application/json'});response.end(JSON.stringify(result));
  });
 });
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try {
  const auth=new MemoryStorageAdapter();await auth.setItem('token','test-access');let sealed=false;
  const get=auth.getItem.bind(auth);auth.getItem=async key=>{if(sealed)throw Error('sealed');return get(key);};
  const client=new TaroPlatformClient({baseUrl:`http://127.0.0.1:${server.address().port}`,storage:auth,tokenKey:'token',request:input=>{
   const request=httpRequest(input.url,{method:input.method,headers:input.header},response=>{
    const chunks=[];response.on('data',chunk=>chunks.push(chunk));response.on('end',()=>input.success({statusCode:response.statusCode,data:Buffer.concat(chunks).toString()}));
   });
   request.on('error',()=>input.fail({errMsg:'connection failed'}));request.end(JSON.stringify(input.data));return {abort:()=>request.destroy()};
  }});
  const sdk=new TaroMiniReminderSDK(client),storage=new MemoryStorageAdapter();let random=0;
  const open=()=>new TaroMiniReminderPlan(sdk,{storage,randomBytes:async()=>new Uint8Array(32).fill(++random)});
  await assert.rejects(open().sync(snapshot()),e=>e.code==='NETWORK_ERROR');assert.equal(observed.length,1);
  await open().sync(snapshot());assert.deepEqual(observed[1].body,observed[0].body);assert.equal(observed[1].authorization,'Bearer test-access');
  sealed=true;await open().revoke();assert.equal(observed.length,3);assert.equal(observed[2].authorization,undefined);
  assert.equal(observed[2].body.cancellationToken,observed[0].body.cancellationToken);
 } finally {await new Promise(resolve=>server.close(resolve));}
});
