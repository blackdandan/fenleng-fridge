import test from 'node:test';import assert from 'node:assert/strict';
import {TaroAuthSDK,TaroPlatformClient,MemoryStorageAdapter} from '../index.js';
import {createServer,request as httpRequest} from 'node:http';
import {readFileSync} from 'node:fs';
import {PLATFORM_OPERATIONS} from '@fenleng/sdk-core';
const contract=JSON.parse(readFileSync(new URL('../fixtures/account-lifecycle-contract.json',import.meta.url),'utf8'));
const confirmationHeader=contract.operations.requestCurrentUserData.parameters.find(p=>p.in==='header' && p.name!=='Idempotency-Key').name;

async function fixture(driver){
 const storage=new MemoryStorageAdapter();await storage.setItem('token','original-access');await storage.setItem('token:refresh','original-refresh');
 const calls=[];const client=new TaroPlatformClient({baseUrl:'https://platform.test',tokenKey:'token',storage,request:input=>{
  calls.push(input);if(driver)return driver(input);input.success({statusCode:200,data:{accepted:true}});
 }});
 return {calls,storage,auth:new TaroAuthSDK(client,{applicationCode:'fenleng-fridge',clientId:'fenleng-fridge-miniapp',clientTarget:'miniapp'})};
}
test('lifecycle methods use authenticated native transport with exact scoped body, intent and confirmation headers',async()=>{
 const f=await fixture();const signal=new AbortController().signal;
 await f.auth.createFederatedDeletionChallenge('WECHAT','delete-intent',{signal});
 await f.auth.confirmFederatedDeletionReauthentication('fdc-once','fresh-wechat-code',{signal});
 await f.auth.requestData('DELETE','delete-intent',{signal,actionConfirmationId:'fdc-once',
  headers:{'idempotency-key':'incorrect-key','x-action-confirmation':'incorrect-confirmation'}});
 await f.auth.dataRequests({signal});
 assert.deepEqual(f.calls.map(c=>c.method),['POST','POST','POST','GET']);
 assert.deepEqual(f.calls[0].data,{provider:'WECHAT',deletionIdempotencyKey:'delete-intent'});
 assert.deepEqual(f.calls[1].data,{identityToken:'fresh-wechat-code'});
 assert.ok(f.calls[1].url.endsWith('/self-deletion/challenges/fdc-once/confirm'));
 assert.deepEqual(f.calls[2].data,{type:'DELETE'});
 assert.equal(f.calls[2].header['Idempotency-Key'],'delete-intent');assert.equal(f.calls[2].header['idempotency-key'],undefined);
 assert.equal(f.calls[2].header['X-Action-Confirmation'],'fdc-once');assert.equal(f.calls[2].header['x-action-confirmation'],undefined);
 assert.equal(f.calls[2].header[confirmationHeader],'fdc-once');
 assert.ok(f.calls.every(c=>c.header.Authorization==='Bearer original-access'));
 assert.equal(await f.storage.getItem('token'),'original-access');assert.equal(await f.storage.getItem('token:refresh'),'original-refresh');
 assert.equal(f.auth.sessionKind,'account');
});
test('invalid provider challenge proof type intent and missing DELETE confirmation never dispatch',async()=>{
 const f=await fixture();
 for(const call of [()=>f.auth.createFederatedDeletionChallenge('UNKNOWN','delete-intent'),()=>f.auth.createFederatedDeletionChallenge('WECHAT','short'),
  ()=>f.auth.confirmFederatedDeletionReauthentication('fdc-bad/path','code'),()=>f.auth.confirmFederatedDeletionReauthentication('fdc-ok',' '),
  ()=>f.auth.confirmFederatedDeletionReauthentication('fdc-ok','x'.repeat(16385)),()=>f.auth.requestData('UNKNOWN','delete-intent'),
  ()=>f.auth.requestData('DELETE','delete-intent'),()=>f.auth.requestData('DELETE','delete-intent',{actionConfirmationId:'bad\r\nvalue'}),
  ()=>f.auth.requestData('EXPORT','short')])assert.throws(call,e=>e.code==='VALIDATION_FAILED');
 assert.equal(f.calls.length,0);
});
test('export reuses authentication but does not require a deletion confirmation',async()=>{
 const f=await fixture();await f.auth.requestData('EXPORT','export-intent');assert.equal(f.calls.length,1);
 assert.deepEqual(f.calls[0].data,{type:'EXPORT'});assert.equal(f.calls[0].header['X-Action-Confirmation'],undefined);
});
test('current user is an authenticated read without creating or replacing a session',async()=>{
 const f=await fixture(input=>input.success({statusCode:200,data:{id:'user-one',kind:'HUMAN',status:'ACTIVE'}}));
 assert.deepEqual(await f.auth.currentUser(),{id:'user-one',kind:'HUMAN',status:'ACTIVE'});
 assert.equal(f.calls.length,1);assert.equal(f.calls[0].method,'GET');assert.ok(f.calls[0].url.endsWith('/users/me'));
 assert.equal(f.calls[0].header.Authorization,'Bearer original-access');assert.equal(await f.storage.getItem('token'),'original-access');
});
test('unknown-write network failure and revoked session are not retried or cleared by native lifecycle calls',async()=>{
 for(const status of ['network',401]){
  const f=await fixture(input=>status==='network'?input.fail({errMsg:'network failed'}):input.success({statusCode:status,data:{code:'AUTHENTICATION_REQUIRED'}}));
  await assert.rejects(f.auth.requestData('DELETE','delete-intent',{actionConfirmationId:'fdc-once'}),e=>e.code===(status==='network'?'NETWORK_ERROR':'AUTHENTICATION_REQUIRED'));
  assert.equal(f.calls.length,1);assert.equal(await f.storage.getItem('token'),'original-access');
 }
});
test('abort prevents late confirmation delivery without replacing original session',async()=>{
 let native,aborts=0;const f=await fixture(input=>{native=input;return {abort:()=>aborts++};});const controller=new AbortController();
 const pending=f.auth.confirmFederatedDeletionReauthentication('fdc-once','fresh-code',{signal:controller.signal});
 await Promise.resolve();controller.abort();await assert.rejects(pending,e=>e.code==='REQUEST_CANCELLED');
 native.success({statusCode:200,data:{confirmationId:'fdc-once'}});assert.equal(aborts,1);assert.equal(f.calls.length,1);
 assert.equal(await f.storage.getItem('token'),'original-access');
});
test('explicit anonymous request option cannot bypass lifecycle authentication',async()=>{
 const f=await fixture();await f.auth.createFederatedDeletionChallenge('WECHAT','delete-intent',{authentication:'none'});
 assert.equal(f.calls[0].header.Authorization,'Bearer original-access');
});
test('actual local HTTP confirms wire headers, unchanged identity and server receipt forwarding',async()=>{
 const seen=[];const receipt={id:'request-one',type:'DELETE',status:'PENDING',requestedAt:'2030-01-01T00:00:00Z',nextAttemptAt:'2030-01-08T00:00:00Z'};
 const server=createServer(async(req,res)=>{
  let body='';for await(const chunk of req)body+=chunk;seen.push({url:req.url,headers:req.headers,body:body?JSON.parse(body):null});
  res.setHeader('Content-Type','application/json');res.end(JSON.stringify(req.url.endsWith('/confirm')?
   {confirmationId:'fdc-once',deletionIdempotencyKey:'delete-intent'}:req.url.endsWith('/challenges')?{challengeId:'fdc-once',provider:'WECHAT'}:receipt));
 });await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
 try{
  const storage=new MemoryStorageAdapter();await storage.setItem('token','original-access');
  const client=new TaroPlatformClient({baseUrl:`http://127.0.0.1:${server.address().port}`,tokenKey:'token',storage,request:input=>{
   const request=httpRequest(input.url,{method:input.method,headers:input.header},response=>{
    let data='';response.on('data',chunk=>data+=chunk);response.on('end',()=>input.success({statusCode:response.statusCode,data}));
   });request.on('error',()=>input.fail({errMsg:'network failure'}));request.end(input.data===null?undefined:JSON.stringify(input.data));
   return {abort:()=>request.destroy()};
  }});
  const auth=new TaroAuthSDK(client,{applicationCode:'fenleng-fridge',clientId:'fenleng-fridge-miniapp'});
  await auth.createFederatedDeletionChallenge('WECHAT','delete-intent');await auth.confirmFederatedDeletionReauthentication('fdc-once','fresh-code');
  assert.deepEqual(await auth.requestData('DELETE','delete-intent',{actionConfirmationId:'fdc-once'}),receipt);
  assert.equal(seen.length,3);assert.equal(seen[2].headers['idempotency-key'],'delete-intent');
  assert.equal(seen[2].headers[confirmationHeader.toLowerCase()],'fdc-once');assert.equal(seen[2].headers.authorization,'Bearer original-access');
  assert.equal(await storage.getItem('token'),'original-access');
 }finally{await new Promise(resolve=>server.close(resolve));}
});
test('actual method dispatch matches frozen public operation catalog and platform candidate provider schema',async()=>{
 const f=await fixture();
 await f.auth.createFederatedDeletionChallenge('WECHAT','delete-intent');await f.auth.confirmFederatedDeletionReauthentication('fdc-once','fresh-code');
 await f.auth.dataRequests();await f.auth.requestData('DELETE','delete-intent',{actionConfirmationId:'fdc-once'});
 for(const [i,id] of ['createFederatedDeletionChallenge','confirmFederatedDeletionReauthentication','listCurrentUserDataRequests','requestCurrentUserData'].entries()){
  const expected=contract.operations[id];assert.deepEqual({method:expected.method,path:expected.path},PLATFORM_OPERATIONS[id]);
  assert.equal(f.calls[i].method,expected.method);assert.equal(new URL(f.calls[i].url).pathname,expected.path.replace('{challengeId}','fdc-once'));
 }
 for(const provider of contract.schemas.FederatedDeletionChallengeRequest.properties.provider.enum){
  await f.auth.createFederatedDeletionChallenge(provider,'delete-intent');assert.equal(f.calls.at(-1).data.provider,provider);
 }
 assert.equal(contract.status,'unreleased-worktree-overlay');assert.equal(confirmationHeader,'X-Action-Confirmation');
});
