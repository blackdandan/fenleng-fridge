import {miniCapability,miniObservation,miniReminderSnapshot,miniReminderPlan,miniReminderError} from './mini-reminders.js';

/** One owner per storage key. Keep this storage outside auth-token cleanup. No random fallback. */
export class TaroMiniReminderPlan {
  constructor(sdk,{storage,randomBytes,storageKey='fl_mini_reminder_plan_v1'}={}) {
    if(!sdk || !storage || typeof storage.getItem!=='function' || typeof storage.setItem!=='function' ||
      typeof randomBytes!=='function' || typeof storageKey!=='string' || !storageKey)throw miniReminderError('CONFIGURATION_INVALID');
    this.sdk=sdk;this.storage=storage;this.randomBytes=randomBytes;this.key=storageKey;this.tail=Promise.resolve();this.stopping=false;
  }
  prepare() {return this.serial(async()=>{
    const state=await this.ensure();return {installationId:state.installationId,revision:state.revision,hasPlan:state.plan!==null};
  });}
  sync(input,options) {
    const snapshot=miniReminderSnapshot(input);
    return this.serial(async()=>{
      let state=await this.ensure();
      if(JSON.stringify(state.intent)!==JSON.stringify(snapshot)) {
        if(!Number.isSafeInteger(state.revision+1))throw miniReminderError('MINI_REVISION_EXHAUSTED');
        state={...state,revision:state.revision+1,intent:snapshot};await this.write(state);
      }
      this.active(state);
      const plan=await this.sdk.replace({installationId:state.installationId,cancellationToken:state.capability,
        revision:state.revision,...state.intent},options);
      if(plan.revoked || plan.revision!==state.revision || state.plan && plan.id!==state.plan.id ||
        JSON.stringify(miniReminderSnapshot(plan))!==JSON.stringify(state.intent))throw miniReminderError('MINI_RESPONSE_INVALID');
      // If cancellation began during the bounded PUT, preserve intent for its queued revoke.
      if(this.stopping)throw miniReminderError('MINI_CANCELLATION_PENDING');
      await this.write({...state,plan});return plan;
    });
  }
  observe(templateId,result,options) {
    return this.serial(async()=>{
      const state=await this.ensure();
      if(!state.plan)throw miniReminderError('MINI_PLAN_REQUIRED');
      if(templateId!==state.plan.templateId || !miniObservation(result))throw miniReminderError('MINI_GRANT_CONTEXT_CHANGED');
      if(state.pending.length>=32)throw miniReminderError('MINI_OBSERVATIONS_FULL');
      const grantId=await this.random();this.active(state);
      await this.write({...state,pending:[...state.pending,{grantId,templateId,result}]});
      return this.flush(options);
    });
  }
  retryObservations(options) {return this.serial(()=>this.flush(options));}
  async flush(options) {
    let state=await this.ensure();
    while(state.pending.length) {
      this.active(state);const observation=state.pending[0];
      if(observation.templateId!==state.plan?.templateId) {
        state={...state,pending:state.pending.slice(1)};await this.write(state);continue;
      }
      const plan=await this.sdk.observe({cancellationToken:state.capability,...observation},options);
      if(plan.id!==state.plan.id || plan.templateId!==observation.templateId || plan.revoked)throw miniReminderError('MINI_RESPONSE_INVALID');
      if(this.stopping)throw miniReminderError('MINI_CANCELLATION_PENDING');
      state={...state,plan,pending:state.pending.slice(1)};await this.write(state);
    }
    return state.plan;
  }
  status(options) {return this.serial(async()=>{
    const state=await this.read();
    if(!state?.plan)return null;
    this.active(state);return this.sdk.status(state.plan.id,options);
  });}
  /** Fence queued/new writes immediately; retain revoking capability until server ACK AND local commit. */
  revoke(options) {
    this.stopping=true;
    return this.serial(async()=>{
      const state=await this.read();
      if(!state?.capability)return {revoked:true};
      await this.write({...state,cancelling:true});
      await this.sdk.revoke(state.capability,options);
      await this.write({...state,capability:null,revision:0,intent:null,plan:null,pending:[],cancelling:false});
      return {revoked:true};
    });
  }
  serial(action) {
    const pending=this.tail.then(action);this.tail=pending.catch(()=>{});return pending;
  }
  active(state) {if(this.stopping || state?.cancelling)throw miniReminderError('MINI_CANCELLATION_PENDING');}
  async ensure() {
    let state=await this.read();this.active(state);
    if(!state)state={version:1,installationId:await this.random(),capability:null,revision:0,intent:null,plan:null,pending:[],cancelling:false};
    if(!state.capability) {
      state={...state,capability:await this.random()};this.active(state);await this.write(state);
    }
    return state;
  }
  async random() {
    try {
      let bytes=await this.randomBytes(32);
      if(bytes instanceof ArrayBuffer)bytes=new Uint8Array(bytes);
      if(!(bytes instanceof Uint8Array) || bytes.length!==32)throw new Error();
      return Array.from(bytes,value=>value.toString(16).padStart(2,'0')).join('');
    } catch {throw miniReminderError('MINI_RANDOM_UNAVAILABLE');}
  }
  async read() {
    let raw;
    try {raw=await this.storage.getItem(this.key);}catch {throw miniReminderError('MINI_STORAGE_UNAVAILABLE');}
    if(raw===null)return null;
    try {
      const s=JSON.parse(raw);
      if(s.version!==1 || !miniCapability(s.installationId) || !(s.capability===null || miniCapability(s.capability)) ||
        !Number.isSafeInteger(s.revision) || s.revision<0 || typeof s.cancelling!=='boolean' || !Array.isArray(s.pending) || s.pending.length>32)throw new Error();
      if(s.intent!==null)s.intent=miniReminderSnapshot(s.intent);
      if(s.plan!==null)s.plan=miniReminderPlan(s.plan);
      if((s.revision===0)!==(s.intent===null) || s.plan && (!s.intent || s.plan.revision>s.revision) ||
        s.capability===null && (s.revision!==0 || s.pending.length || s.plan!==null || s.cancelling))throw new Error();
      for(const p of s.pending)if(!miniCapability(p.grantId) || typeof p.templateId!=='string' || !/^[A-Za-z0-9_-]{1,128}$/.test(p.templateId) || !miniObservation(p.result))throw new Error();
      return s;
    }catch {throw miniReminderError('MINI_STATE_INVALID');}
  }
  async write(state) {
    try {await this.storage.setItem(this.key,JSON.stringify(state));}catch {throw miniReminderError('MINI_STORAGE_UNAVAILABLE');}
  }
}
