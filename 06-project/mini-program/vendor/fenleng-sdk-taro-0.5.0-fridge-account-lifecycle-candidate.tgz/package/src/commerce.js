import {FenlengSdkError} from '@fenleng/sdk-core';

/** Platform owns prices, order state and fulfillment. Host callbacks never mark orders paid. */
export class TaroCommerceSDK {
  constructor(client) {if(!client)throw new FenlengSdkError('CONFIGURATION_INVALID','TaroCommerceSDK requires a configured client');this.client=client;}
  purchaseAgreement(priceOptionId,options={}) {return this.client.request(`/api/platform/v1/commerce/prices/${id(priceOptionId)}/purchase-agreement`,'GET',null,options);}
  createOrder(priceOptionId,idempotencyKey,{agreementConfirmation,...options}={}) {
    return this.client.request('/api/platform/v1/commerce/orders','POST',{priceOptionId:required(priceOptionId),...(agreementConfirmation?{agreementConfirmation}:{})},{...options,idempotencyKey:intent(idempotencyKey)});
  }
  order(orderId,options={}) {return this.client.request(`/api/platform/v1/commerce/orders/${id(orderId)}`,'GET',null,options);}
  payment(attemptId,options={}) {return this.client.request(`/api/platform/v1/commerce/payments/${id(attemptId)}`,'GET',null,options);}
  reconcilePayment(attemptId,idempotencyKey,options={}) {return this.client.request(`/api/platform/v1/commerce/payments/${id(attemptId)}/reconcile`,'POST',null,{...options,idempotencyKey:intent(idempotencyKey)});}
  cancelPayment(attemptId,idempotencyKey,options={}) {return this.client.request(`/api/platform/v1/commerce/payments/${id(attemptId)}/cancel`,'POST',null,{...options,idempotencyKey:intent(idempotencyKey)});}
  startPayment(orderId,provider,{presentation,returnUrl=null,idempotencyKey,...options}={}) {
    if(!['wechat-pay','alipay','douyin-pay'].includes(provider)||!['WECHAT_MINI_PROGRAM','ALIPAY_MINI_PROGRAM','DOUYIN_MINI_PROGRAM'].includes(presentation))throw invalid();
    const expected={'wechat-pay':'WECHAT_MINI_PROGRAM',alipay:'ALIPAY_MINI_PROGRAM','douyin-pay':'DOUYIN_MINI_PROGRAM'};
    if(expected[provider]!==presentation||returnUrl!==null)throw invalid();
    return this.client.request('/api/platform/v1/commerce/payments','POST',{orderId:required(orderId),provider,presentation,returnUrl:null},{...options,idempotencyKey:intent(idempotencyKey)});
  }
  requestWechatPayment(orderId,idempotencyKey,options={}) {return this.startPayment(orderId,'wechat-pay',{...options,presentation:'WECHAT_MINI_PROGRAM',idempotencyKey});}
}
function invalid(){return new FenlengSdkError('CONFIGURATION_INVALID','Mini program payment registration is invalid');}
function required(value){if(typeof value!=='string'||!value.trim()||value.length>128)throw invalid();return value;}
function id(value){return encodeURIComponent(required(value));}
function intent(value){if(typeof value!=='string'||value.length<8||value.length>128||!/^[-A-Za-z0-9_:/.]+$/.test(value))throw invalid();return value;}
