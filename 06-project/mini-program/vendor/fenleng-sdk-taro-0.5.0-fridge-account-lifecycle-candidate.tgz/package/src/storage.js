import { StorageAdapter, FenlengSdkError } from '@fenleng/sdk-core';

/** Persistent host storage; no silent memory fallback. Construct after consent. */
export class TaroStorageAdapter extends StorageAdapter {
  constructor(driver, {prefix = ''} = {}) {
    super();
    if (!driver || ['getStorageSync','setStorageSync','removeStorageSync'].some(name => typeof driver[name] !== 'function')) throw new FenlengSdkError('CONFIGURATION_INVALID', 'Taro storage driver is required');
    this.driver = driver;
    this.prefix = prefix;
  }
  async getItem(key) {
    const value = this.driver.getStorageSync(this.prefix + key);
    if (value === undefined || value === null || value === '') return null;
    if (typeof value !== 'string') throw new FenlengSdkError('STORAGE_VALUE_INVALID', 'Stored SDK value must be a string');
    return value;
  }
  async setItem(key, value) {
    if (typeof value !== 'string') throw new FenlengSdkError('STORAGE_VALUE_INVALID', 'Stored SDK value must be a string');
    this.driver.setStorageSync(this.prefix + key, value);
  }
  async removeItem(key) { this.driver.removeStorageSync(this.prefix + key); }
}
