import { FenlengSdkError } from '@fenleng/sdk-core';

/** Host calls resume/suspend from its lifecycle; no platform globals or hidden login. */
export class TaroSessionCoordinator {
  constructor(auth, {refreshIntervalMs = 300_000, timers = globalThis} = {}) {
    if (!Number.isInteger(refreshIntervalMs) || refreshIntervalMs < 1000 || refreshIntervalMs > 600_000) throw new FenlengSdkError('CONFIGURATION_INVALID', 'refreshIntervalMs must be between 1000 and 600000');
    this.auth = auth;
    this.timers = timers;
    this.refreshIntervalMs = refreshIntervalMs;
    this.value = Object.freeze({status:'consent-required', refreshing:false, errorCode:null});
    this.listeners = new Set();
    this.consent = false;
    this.foreground = false;
    this.closed = false;
    this.cleanupFailed = false;
    this.epoch = 0;
    this.timer = null;
    this.operation = null;
    this.refreshing = null;
  }
  snapshot = () => this.value;
  subscribe = listener => { this.listeners.add(listener); return () => this.listeners.delete(listener); };
  publish(status, errorCode = null, refreshing = false) {
    if (this.closed) return;
    this.value = Object.freeze({status, errorCode, refreshing,
      identityKind:status==='authenticated' ? this.auth.sessionKind || 'account' : null});
    for (const listener of this.listeners) listener();
  }
  captureSession() { const epoch=this.epoch; return () => !this.closed && epoch===this.epoch && this.value.status==='authenticated'; }
  async accessToken() {
    const active=this.captureSession();if (!active()) return null;
    const token=await this.auth.accessToken();return active()?token:null;
  }
  async start({consent = false} = {}) {
    if (this.closed) throw changed();
    if (!consent) { if(this.consent)return this.withdrawConsent();this.publish('consent-required');return; }
    if(this.cleanupFailed){await this.auth.endLocalSession();this.cleanupFailed=false;}
    this.consent = true;this.foreground = true;
    return this.restore();
  }
  restore() { return this.run(() => this.auth.refresh(), 'restoring'); }
  loginWithPassword(email,password,options) { return this.run(() => this.auth.loginWithPassword(email,password,options)); }
  loginWithCode(provider,code,options) { return this.run(() => this.auth.loginWithCode(provider,code,options)); }
  loginAsGuest(options) { return this.run(() => this.auth.loginAsGuest(options)); }
  register(input,options) { return this.run(async () => {
    const result=await this.auth.register(input,options);
    if(!result || typeof result.userId!=='string' || !result.userId.trim() || typeof result.applicationId!=='string' || !result.applicationId.trim() || typeof result.email!=='string' || result.email.toLowerCase()!==input.email.trim().toLowerCase() || typeof result.username!=='string' || typeof result.displayName!=='string') {
      await this.auth.endLocalSession();throw new FenlengSdkError('INVALID_REGISTRATION_RESPONSE','Registration account was not confirmed');
    }
    return result;
  }); }
  requestRegistrationEmailVerification(email,options) {
    if (!this.ready() || this.value.status!=='anonymous' || this.operation || this.refreshing) return Promise.reject(pending());
    return this.auth.requestRegistrationEmailVerification(email,options);
  }
  ready() { return !this.closed && this.consent && !this.cleanupFailed; }
  run(action, phase = 'authenticating') {
    if (!this.ready() || this.operation || this.refreshing || this.value.status==='ending' || (phase==='authenticating' && !['anonymous','error','reauthentication-required','binding-required','blocked'].includes(this.value.status) && !(this.value.status==='authenticated' && this.auth.sessionKind==='guest'))) return Promise.reject(pending());
    const epoch=++this.epoch;this.cancelTimer();this.publish(phase);
    const operation=(async () => {
      try {
        const result=await action();
        if (epoch!==this.epoch || this.closed) throw changed();
        if (!await this.auth.accessToken()) throw new FenlengSdkError('SESSION_MISSING','No access token is available');
        if (epoch!==this.epoch || this.closed) throw changed();
        this.publish('authenticated');this.schedule();return result;
      } catch (error) {
        if (epoch===this.epoch && !this.closed) {
          const status=error.code==='SESSION_MISSING' && phase==='restoring'?'anonymous':loginError(error);
          this.publish(status,status==='anonymous'?null:error.code || 'IDENTITY_UNAVAILABLE');
        }
        if (error.code!=='SESSION_MISSING' || phase!=='restoring') throw error;
      }
    })();
    this.operation=operation;
    return operation.finally(() => { if(this.operation===operation)this.operation=null; });
  }
  refresh() {
    if (this.refreshing) return this.refreshing;
    if (!this.ready() || this.value.status!=='authenticated' || this.operation) return Promise.reject(pending());
    const epoch=this.epoch;this.cancelTimer();this.publish('authenticated',null,true);
    this.refreshing=(async () => {
      try {
        const result=await this.auth.refresh();
        if (epoch!==this.epoch || this.closed) throw changed();
        this.publish('authenticated');this.schedule();return result;
      } catch (error) {
        if (epoch===this.epoch && !this.closed) {
          if (error.status===401 || error.code==='SESSION_MISSING') {
            ++this.epoch;this.cleanupFailed=error.code==='SESSION_CLEANUP_FAILED';this.publish('reauthentication-required',error.code);
          } else {this.publish('authenticated',error.code || 'IDENTITY_UNAVAILABLE');this.schedule();}
        }
        throw error;
      }
    })().finally(() => {this.refreshing=null;});
    return this.refreshing;
  }
  suspend() {this.foreground=false;this.cancelTimer();}
  async resume() {
    if (!this.ready()) return;
    this.foreground=true;
    if (this.operation || this.refreshing || this.value.status==='ending') return;
    if (this.value.status==='authenticated') return this.refresh();
    if (this.value.status==='error') return this.restore();
  }
  schedule() {
    this.cancelTimer();if (!this.foreground || !this.ready() || this.value.status!=='authenticated') return;
    this.timer=this.timers.setTimeout(() => {this.timer=null;void this.refresh().catch(() => {});},this.refreshIntervalMs);
  }
  cancelTimer() {if(this.timer!==null){this.timers.clearTimeout(this.timer);this.timer=null;}}
  async logout({localOnly = false} = {}) {
    if (this.closed) return;
    ++this.epoch;this.cancelTimer();this.publish('ending');
    try {await this.auth.logout({localOnly});this.cleanupFailed=false;if(!this.closed)this.publish(this.consent?'anonymous':'consent-required');}
    catch(error){this.cleanupFailed=true;if(!this.closed)this.publish('error','SESSION_CLEANUP_FAILED');throw error;}
  }
  async invalidate() {
    if(this.closed)return;
    ++this.epoch;this.cancelTimer();this.publish('reauthentication-required');
    try {await this.auth.endLocalSession();this.cleanupFailed=false;}
    catch(error){this.cleanupFailed=true;this.publish('error','SESSION_CLEANUP_FAILED');throw error;}
  }
  async withdrawConsent() {this.consent=false;await this.logout({localOnly:true});}
  async close() {
    if(this.closed)return;this.closed=true;++this.epoch;this.cancelTimer();this.listeners.clear();
    if(this.operation || this.refreshing) await this.auth.endLocalSession();
  }
}
function pending(){return new FenlengSdkError('IDENTITY_NOT_READY','Identity is not ready for this operation');}
function changed(){return new FenlengSdkError('SESSION_CHANGED','The original identity session has ended');}
function loginError(error){if(error.code==='BINDING_REQUIRED')return 'binding-required';if(error.code==='ACCOUNT_BLOCKED')return 'blocked';if(error.status===401)return 'reauthentication-required';return 'error';}
