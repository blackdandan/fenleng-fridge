import { FenlengTelemetryLogger, FenlengSSEClient } from '@fenleng/sdk-core';

export class TaroTelemetrySDK extends FenlengTelemetryLogger {
  constructor(client, options) {
    super(client, options);
  }
}

export class TaroAIServiceSDK extends FenlengSSEClient {
  constructor(client) {
    super(client);
  }
}
