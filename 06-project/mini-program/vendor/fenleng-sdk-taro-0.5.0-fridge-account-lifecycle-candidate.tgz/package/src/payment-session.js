import {FenlengSdkError} from '@fenleng/sdk-core';

/** One original server attempt. Caller injects a host adapter; no callback grants fulfillment. */
export class TaroPaymentSession {
  constructor(commerce,{orderId,attemptId,invoke,isSessionActive=()=>true}={}) {
    if(!orderId||!attemptId||typeof invoke!=='function')throw new FenlengSdkError('CONFIGURATION_INVALID','Original payment attempt is required');
    this.commerce=commerce;this.orderId=orderId;this.attemptId=attemptId;this.invoke=invoke;this.active=isSessionActive;
    this.value=Object.freeze({phase:'ready',hostOutcome:null,errorCode:null});this.listeners=new Set();this.pending=null;this.closed=false;this.epoch=0;
  }
  snapshot=()=>this.value;
  subscribe=listener=>{this.listeners.add(listener);return()=>this.listeners.delete(listener);};
  guard(epoch){if(this.closed||epoch!==this.epoch||!this.active())throw new FenlengSdkError('SESSION_CHANGED','Payment session ended');}
  publish(phase,hostOutcome=this.value.hostOutcome,errorCode=null){this.value=Object.freeze({phase,hostOutcome,errorCode});for(const listener of this.listeners)listener();}
  run(action){
    if(this.pending)return this.pending;
    const epoch=this.epoch;try{this.guard(epoch);}catch(error){return Promise.reject(error);}
    const operation=Promise.resolve().then(()=>action(epoch));this.pending=operation;
    return operation.finally(()=>{if(this.pending===operation)this.pending=null;});
  }
  launch(payload){return this.run(async epoch=>{
    if(this.value.phase!=='ready')return;
    this.publish('invoking');let outcome='unknown';
    try{const result=await this.invoke(payload);outcome=['completed','cancelled','failed'].includes(result?.kind)?result.kind:'unknown';}catch{/* Host result does not settle order state. */}
    this.guard(epoch);this.publish('checking',outcome);return this.query(epoch);
  });}
  check(){return this.run(epoch=>{this.publish('checking');return this.query(epoch);});}
  async query(epoch){
    try{
      const order=await this.commerce.order(this.orderId);this.guard(epoch);
      if(order?.id!==this.orderId||!['PENDING','PAYMENT_PROCESSING','PAID','CANCELED','REFUNDED','PARTIALLY_REFUNDED'].includes(order.status))throw new FenlengSdkError('INVALID_API_RESPONSE','Original order could not be confirmed');
      const phase={PAID:'paid',CANCELED:'cancelled',REFUNDED:'refunded',PARTIALLY_REFUNDED:'partially-refunded'}[order.status]||'pending';
      this.publish(phase);return order;
    }catch(error){this.guard(epoch);this.publish('unknown',this.value.hostOutcome,error.code||'ORDER_STATUS_UNKNOWN');throw error;}
  }
  cancel(idempotencyKey){return this.run(async epoch=>{
    if(['paid','refunded','partially-refunded'].includes(this.value.phase))return this.query(epoch);
    this.publish('closing');
    try{await this.commerce.cancelPayment(this.attemptId,idempotencyKey);this.guard(epoch);}catch(error){this.guard(epoch);this.publish('unknown',this.value.hostOutcome,error.code||'CLOSE_STATUS_UNKNOWN');throw error;}
    // Close acknowledgement alone does not prove no late payment occurred.
    return this.query(epoch);
  });}
  close(){if(this.closed)return;this.closed=true;++this.epoch;this.listeners.clear();this.value=Object.freeze({phase:'closed',hostOutcome:null,errorCode:null});}
}
