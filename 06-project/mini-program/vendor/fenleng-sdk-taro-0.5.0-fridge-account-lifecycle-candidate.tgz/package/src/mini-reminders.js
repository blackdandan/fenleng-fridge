import {FenlengSdkError} from '@fenleng/sdk-core';

const root='/api/platform/v1/users/me/mini-reminders';
const statuses=new Set(['PENDING','WAITING_PERMISSION','SENDING','ACCEPTED','UNCONFIRMED','FAILED','CANCELLED','EXPIRED']);
export const miniReminderError=code=>new FenlengSdkError(code,'Mini reminder request could not be completed');
const invalid=()=>miniReminderError('VALIDATION_FAILED');
export const miniCapability=value=>typeof value==='string' && /^[0-9a-f]{64}$/.test(value);
export const miniObservation=value=>['accept','reject','ban','filter'].includes(value);

/** Copies input immediately; no user/account/OpenID or food identifiers are accepted. */
export function miniReminderSnapshot(input) {
  if(!input || typeof input.timezone!=='string' || !input.timezone.trim() || input.timezone.length>128 ||
    !['zh_CN','zh_TW','zh_HK','en_US'].includes(input.language) || !Array.isArray(input.days) || input.days.length>4000)throw invalid();
  const days=input.days.map(day=>{
    if(!day || typeof day.day!=='string' || !/^\d{4}-\d{2}-\d{2}$/.test(day.day) ||
      !Number.isFinite(Date.parse(day.day)) || new Date(day.day).toISOString().slice(0,10)!==day.day ||
      typeof day.fireAt!=='string' || !Number.isFinite(Date.parse(day.fireAt)) || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:Z|[+-]\d{2}:\d{2})$/.test(day.fireAt) ||
      !Number.isInteger(day.count) || day.count<1 || day.count>100000)throw invalid();
    return {day:day.day,fireAt:new Date(day.fireAt).toISOString(),count:day.count};
  }).sort((a,b)=>a.day.localeCompare(b.day));
  if(new Set(days.map(day=>day.day)).size!==days.length)throw invalid();
  return {timezone:input.timezone,language:input.language,days};
}
export function miniReminderPlan(value) {
  try {
    if(!value || !miniCapability(value.id) || !Number.isSafeInteger(value.revision) || value.revision<1 ||
      typeof value.templateId!=='string' || !/^[A-Za-z0-9_-]{1,128}$/.test(value.templateId) ||
      typeof value.revoked!=='boolean' || !Number.isInteger(value.observedAcceptances) ||
      value.observedAcceptances<0 || value.observedAcceptances>1000)throw invalid();
    return {id:value.id,revision:value.revision,templateId:value.templateId,revoked:value.revoked,
      observedAcceptances:value.observedAcceptances,...miniReminderSnapshot(value)};
  } catch {throw miniReminderError('MINI_RESPONSE_INVALID');}
}

/** Typed transport only. Native subscription dialogs must be invoked by the host gesture. */
export class TaroMiniReminderSDK {
  constructor(client) {if(typeof client?.request!=='function')throw invalid();this.client=client;}
  async configuration(options) {
    const value=await this.client.request(`${root}/config`,'GET',null,options);
    if(typeof value?.configured!=='boolean' || value.requiresWechatSession!==true || value.allowanceSource!=='client-observation' ||
      (value.configured ? typeof value.templateId!=='string' || !/^[A-Za-z0-9_-]{1,128}$/.test(value.templateId) : value.templateId!==null)) {
      throw miniReminderError('MINI_RESPONSE_INVALID');
    }
    return {configured:value.configured,templateId:value.templateId,requiresWechatSession:true,allowanceSource:'client-observation'};
  }
  async replace(input,options) {
    const snapshot=miniReminderSnapshot(input);
    if(!miniCapability(input.cancellationToken) || typeof input.installationId!=='string' || !/^[A-Za-z0-9_-]{16,128}$/.test(input.installationId) ||
      !Number.isSafeInteger(input.revision) || input.revision<1)throw invalid();
    const body={installationId:input.installationId,cancellationToken:input.cancellationToken,revision:input.revision,...snapshot};
    return miniReminderPlan(await this.client.request(`${root}/plans`,'PUT',body,options));
  }
  async observe(input,options) {
    if(!miniCapability(input?.cancellationToken) || typeof input.grantId!=='string' || !/^[A-Za-z0-9_-]{16,128}$/.test(input.grantId) ||
      typeof input.templateId!=='string' || !/^[A-Za-z0-9_-]{1,128}$/.test(input.templateId) || !miniObservation(input.result))throw invalid();
    return miniReminderPlan(await this.client.request(`${root}/observations`,'POST',{
      cancellationToken:input.cancellationToken,grantId:input.grantId,templateId:input.templateId,result:input.result,
    },options));
  }
  async status(id,options) {
    if(!miniCapability(id))throw invalid();
    const value=await this.client.request(`${root}/plans/${id}`,'GET',null,options);
    const plan=miniReminderPlan(value?.plan);
    if(plan.id!==id || !Array.isArray(value.deliveries) || value.deliveries.length>4000)throw miniReminderError('MINI_RESPONSE_INVALID');
    const deliveries=value.deliveries.map(job=>{
      if(!job || !plan.days.some(day=>day.day===job.day) || !statuses.has(job.status) || !Number.isInteger(job.attempts) || job.attempts<0 ||
        !(job.code===null || typeof job.code==='string' && /^[A-Z][A-Z0-9_]{0,95}$/.test(job.code)))throw miniReminderError('MINI_RESPONSE_INVALID');
      return {day:job.day,status:job.status,attempts:job.attempts,code:job.code};
    });
    if(new Set(deliveries.map(job=>job.day)).size!==deliveries.length)throw miniReminderError('MINI_RESPONSE_INVALID');
    return {plan,deliveries};
  }
  async revoke(cancellationToken,options) {
    if(!miniCapability(cancellationToken))throw invalid();
    const value=await this.client.request('/api/platform/v1/mini-reminders/revoke','POST',{cancellationToken},{...options,authentication:'none'});
    if(value?.revoked!==true)throw miniReminderError('MINI_RESPONSE_INVALID');
    return {revoked:true};
  }
}
