import test from 'node:test';
import assert from 'node:assert/strict';
import {TaroCommerceSDK} from '../index.js';
function fixture(){const calls=[];return {calls,sdk:new TaroCommerceSDK({request:async(...args)=>{calls.push(args);return {status:'PAYMENT_PROCESSING'};}})};}
test('mini presentation and provider are exact and caller never supplies amount',async()=>{
 const f=fixture();await f.sdk.requestWechatPayment('order','payment-intent');assert.deepEqual(f.calls[0],['/api/platform/v1/commerce/payments','POST',{orderId:'order',provider:'wechat-pay',presentation:'WECHAT_MINI_PROGRAM',returnUrl:null},{idempotencyKey:'payment-intent'}]);
 for(const [provider,presentation] of [['alipay','ALIPAY_MINI_PROGRAM'],['douyin-pay','DOUYIN_MINI_PROGRAM']])await f.sdk.startPayment('order',provider,{presentation,idempotencyKey:'payment-intent'});assert.equal(f.calls.length,3);
});
test('wrong provider presentation missing intent and redirect fail before writes',()=>{
 const f=fixture();for(const options of [{presentation:'NATIVE_APP',idempotencyKey:'payment-intent'},{presentation:'ALIPAY_MINI_PROGRAM',idempotencyKey:'payment-intent'},{presentation:'WECHAT_MINI_PROGRAM'},{presentation:'WECHAT_MINI_PROGRAM',idempotencyKey:'payment-intent',returnUrl:'https://other.test'}])assert.throws(()=>f.sdk.startPayment('order','wechat-pay',options));assert.equal(f.calls.length,0);
});
test('order creation freezes server price reference and payment recovery targets original attempt',async()=>{
 const f=fixture();await f.sdk.createOrder('price','order-intent',{agreementConfirmation:{documentId:'terms',documentVersion:'1',contentSha256:'digest'}});await f.sdk.order('order/one');await f.sdk.payment('attempt/one');await f.sdk.reconcilePayment('attempt/one','reconcile-intent');await f.sdk.cancelPayment('attempt/one','cancel-intent');assert.equal(f.calls[0][2].priceOptionId,'price');assert.equal('amount'in f.calls[0][2],false);assert.equal(f.calls[1][0],'/api/platform/v1/commerce/orders/order%2Fone');assert.equal(f.calls[3][0],'/api/platform/v1/commerce/payments/attempt%2Fone/reconcile');assert.equal(f.calls[4][3].idempotencyKey,'cancel-intent');
});
test('unknown payment start is returned as failure without SDK write replay',async()=>{
 let calls=0;const sdk=new TaroCommerceSDK({request:async()=>{calls++;throw Error('response lost');}});await assert.rejects(sdk.requestWechatPayment('order','payment-intent'),/response lost/);assert.equal(calls,1);
});
