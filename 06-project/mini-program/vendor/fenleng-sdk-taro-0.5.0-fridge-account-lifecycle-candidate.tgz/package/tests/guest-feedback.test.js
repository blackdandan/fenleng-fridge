import test from 'node:test';
import assert from 'node:assert/strict';
import {TaroAuthSDK,TaroSessionCoordinator,TaroFeedbackSDK,MemoryStorageAdapter,FenlengSdkError} from '../index.js';
const tokens = {accessToken:'guest-access', refreshToken:'guest-refresh'};
function fixture() {
  const storage = new MemoryStorageAdapter(), calls = [];
  const client = {storage, tokenKey:'fridge-session', request:async (...args) => {calls.push(args);return tokens;}};
  const auth = new TaroAuthSDK(client,{applicationCode:'fenleng-fridge',clientId:'fenleng-fridge-miniapp'});
  return {client,storage,auth,calls};
}
const tick = () => new Promise(resolve => setImmediate(resolve));

test('guest creation shares a single flight and never forwards replay credentials', async () => {
  const f=fixture();let resolve;f.client.request=(...args)=>{f.calls.push(args);return new Promise(yes=>{resolve=yes;});};
  const first=f.auth.loginAsGuest({idempotencyKey:'must-not-forward'}),second=f.auth.loginAsGuest();
  assert.equal(first,second);await tick();assert.equal(f.calls.length,1);
  assert.deepEqual(f.calls[0].slice(0,3),['/api/platform/v1/auth/guest/login','POST',{applicationCode:'fenleng-fridge',clientId:'fenleng-fridge-miniapp'}]);
  assert.equal(f.calls[0][3].idempotencyKey,undefined);resolve(tokens);await first;
  assert.equal(f.auth.sessionKind,'guest');
});
test('guest survives restore then WeChat replaces its display kind', async () => {
  const f=fixture();await f.auth.loginAsGuest();
  const reopened=new TaroAuthSDK(f.client,{applicationCode:'fenleng-fridge'});
  const session=new TaroSessionCoordinator(reopened);
  try {
    await session.start({consent:true});assert.equal(session.snapshot().identityKind,'guest');
    await session.loginWithCode('wechat','one-use-code');assert.equal(session.snapshot().identityKind,'account');
    assert.equal(await f.storage.getItem(reopened.kindKey),null);
  } finally {await session.close();}
});
test('offline restore preserves guest and unknown create is not replayed', async () => {
  const f=fixture();await f.auth.loginAsGuest();let calls=0;
  f.client.request=async()=>{calls++;throw new FenlengSdkError('NETWORK_ERROR','offline');};
  await assert.rejects(f.auth.refresh());assert.equal(await f.auth.accessToken(),'guest-access');
  await assert.rejects(f.auth.loginAsGuest());assert.equal(calls,2);
  await assert.rejects(f.auth.loginAsGuest());assert.equal(calls,3);
});
test('withdrawal during guest response cannot retain tokens or publish authenticated', async () => {
  const f=fixture(),session=new TaroSessionCoordinator(f.auth);await session.start({consent:true});
  let resolve;f.client.request=()=>new Promise(yes=>{resolve=yes;});
  const creating=session.loginAsGuest();const rejected=assert.rejects(creating,e=>e.code==='SESSION_CHANGED');
  await tick();const withdrawing=session.withdrawConsent();resolve(tokens);await rejected;await withdrawing;
  assert.equal(session.snapshot().status,'consent-required');assert.equal(f.storage.store.size,0);await session.close();
});
test('guest marker persistence failure clears the full pair', async () => {
  const f=fixture(),set=f.storage.setItem.bind(f.storage);
  f.storage.setItem=async(key,value)=>{if(key.endsWith(':kind'))throw Error('quota');return set(key,value);};
  await assert.rejects(f.auth.loginAsGuest(),/quota/);assert.equal(f.storage.store.size,0);
});
test('expired guest refresh and failed remote logout both clear local marker', async () => {
  const f=fixture();await f.auth.loginAsGuest();
  f.client.request=async()=>{throw new FenlengSdkError('EXPIRED','expired',{status:401});};
  await assert.rejects(f.auth.refresh());assert.equal(f.storage.store.size,0);
  f.client.request=async()=>tokens;await f.auth.loginAsGuest();
  f.client.request=async()=>{throw Error('offline');};
  await assert.rejects(f.auth.logout());assert.equal(f.storage.store.size,0);
});
test('feedback sends exactly the text-only contract and accepts only real receipt fields', async () => {
  const f=fixture(),sdk=new TaroFeedbackSDK(f.client,{projectId:'fenleng-fridge',version:'0.1.0+1'});
  f.client.request=async(...args)=>{f.calls.push(args);return {id:'feedback-1',status:'RECEIVED'};};
  assert.deepEqual(await sdk.submit(' text ','feedback-test-key'),{id:'feedback-1',status:'RECEIVED'});
  assert.deepEqual(f.calls[0],['/api/platform/v1/feedback','POST',{
    projectId:'fenleng-fridge',version:'0.1.0+1',traceId:null,message:'text',attachmentConsent:false,attachments:[],
  },{idempotencyKey:'feedback-test-key',signal:undefined}]);
  f.client.request=async()=>({id:'',status:'RECEIVED'});await assert.rejects(sdk.submit('text','feedback-test-key'),e=>e.code==='FEEDBACK_RESPONSE_INVALID');
  await assert.rejects(sdk.submit(' ','feedback-test-key'),e=>e.code==='VALIDATION_FAILED');
});
