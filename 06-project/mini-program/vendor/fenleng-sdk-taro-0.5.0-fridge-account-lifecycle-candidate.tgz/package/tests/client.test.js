import test from 'node:test';
import assert from 'node:assert/strict';
import {TaroPlatformClient,MemoryStorageAdapter} from '../index.js';
test('host transport reads current token, preserves intent, and uses no browser fetch',async()=>{
 const storage=new MemoryStorageAdapter();await storage.setItem('token','first');const seen=[];
 const client=new TaroPlatformClient({baseUrl:'https://platform.test',storage,tokenKey:'token',request:input=>{seen.push(input);input.success({statusCode:201,data:'{"accepted":true}'});}});
 assert.deepEqual(await client.request('/api/platform/v1/auth/register','POST',{code:'synthetic'},{idempotencyKey:'intent'}),{accepted:true});assert.equal(seen[0].header.Authorization,'Bearer first');assert.equal(seen[0].header['Idempotency-Key'],'intent');assert.equal(seen[0].method,'POST');
 await storage.setItem('token','second');await client.request('/api/platform/v1/users/me');assert.equal(seen[1].header.Authorization,'Bearer second');
});
test('unauthorized and unknown-write network errors are never automatically replayed',async()=>{
 let calls=0;const client=new TaroPlatformClient({baseUrl:'https://platform.test',storage:new MemoryStorageAdapter(),request:input=>{calls++;input.success({statusCode:401,data:{code:'AUTHENTICATION_REQUIRED',message:'private raw detail'}});}});
 await assert.rejects(client.request('/api/platform/v1/auth/refresh','POST',{}),e=>e.status===401 && e.message==='Platform request failed');assert.equal(calls,1);
});
test('abort cancels host task and discards late response',async()=>{
 let input,aborts=0;const controller=new AbortController();const client=new TaroPlatformClient({baseUrl:'https://platform.test',storage:new MemoryStorageAdapter(),request:value=>{input=value;return {abort:()=>aborts++};}});
 const pending=client.request('/api/platform/v1/users/me','GET',null,{signal:controller.signal});await Promise.resolve();controller.abort();await assert.rejects(pending,e=>e.code==='REQUEST_CANCELLED');input.success({statusCode:200,data:{private:true}});assert.equal(aborts,1);
});
test('cancelled before dispatch and malformed JSON fail without exposing private data',async()=>{
 let calls=0;const controller=new AbortController();controller.abort();const client=new TaroPlatformClient({baseUrl:'https://platform.test',storage:new MemoryStorageAdapter(),request:input=>{calls++;input.success({statusCode:200,data:'private non-json'});}});
 await assert.rejects(client.request('/api/platform/v1/users/me','GET',null,{signal:controller.signal}),e=>e.code==='REQUEST_CANCELLED');assert.equal(calls,0);await assert.rejects(client.request('/api/platform/v1/users/me'),e=>e.code==='INVALID_API_RESPONSE');
});
test('capability-only requests never read session storage or forward supplied Authorization variants',async()=>{
 let reads=0,input;
 const client=new TaroPlatformClient({baseUrl:'https://platform.test',storage:{getItem:async()=>{reads++;throw Error('sealed storage');}},
  request:value=>{input=value;value.success({statusCode:200,data:{revoked:true}});}});
 assert.deepEqual(await client.request('/api/platform/v1/mini-reminders/revoke','POST',{cancellationToken:'a'.repeat(64)},
  {authentication:'none',headers:{authorization:'stale',AUTHORIZATION:'also-stale','X-Test':'yes'}}),{revoked:true});
 assert.equal(reads,0);assert.equal(input.header['X-Test'],'yes');assert.ok(Object.keys(input.header).every(key=>key.toLowerCase()!=='authorization'));
 await assert.rejects(client.request('/api/platform/v1/users/me'),/sealed storage/);assert.equal(reads,1);
 await assert.rejects(client.request('/api/platform/v1/users/me','GET',null,{authentication:'invalid'}),error=>error.code==='CONFIGURATION_INVALID');
});
