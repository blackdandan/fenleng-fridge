import test from 'node:test';
import assert from 'node:assert/strict';
import {TaroMiniReminderSDK,TaroMiniReminderPlan,MemoryStorageAdapter} from '../index.js';

const snapshot=()=>({timezone:'Asia/Shanghai',language:'zh_CN',days:[{day:'2026-11-13',fireAt:'2026-11-13T09:00:00Z',count:3}]});
function fixture() {
 const storage=new MemoryStorageAdapter(),requests=[];let random=0;
 const f={storage,requests,fail:null,accepted:new Set(),observed:0,remote:null,revoked:false,writes:0};
 const original=storage.setItem.bind(storage);
 storage.setItem=async(key,value)=>{f.writes++;if(f.failStore?.(JSON.parse(value)))throw Error('private storage diagnostic');await original(key,value);};
 const client={request:async(path,method,body,options)=>{
  requests.push({path,method,body:structuredClone(body),options});
  if(path.endsWith('/plans')) {
   const persisted=JSON.parse(await storage.getItem('plan'));
   assert.equal(persisted.capability,body.cancellationToken);assert.equal(persisted.revision,body.revision);
   if(f.revoked)throw Object.assign(Error(),{code:'MINI_PLAN_REVOKED'});
   f.remote={id:'b'.repeat(64),revision:body.revision,templateId:f.template || 'template-1',revoked:false,observedAcceptances:f.observed,
    timezone:body.timezone,language:body.language,days:body.days};
  } else if(path.endsWith('/observations')) {
   const persisted=JSON.parse(await storage.getItem('plan'));assert.equal(persisted.pending[0].grantId,body.grantId);
   if(!f.accepted.has(body.grantId)){f.accepted.add(body.grantId);f.observed=body.result==='accept'?f.observed+1:0;}
   f.remote={...f.remote,observedAcceptances:f.observed};
  } else if(path.endsWith('/revoke')) {
   assert.equal(options.authentication,'none');assert.equal(JSON.parse(await storage.getItem('plan')).cancelling,true);
   f.revoked=true;if(f.fail){const error=f.fail;f.fail=null;throw error;}return {revoked:true};
  } else if(path.includes('/plans/'))return {plan:f.remote,deliveries:[]};
  if(f.fail){const error=f.fail;f.fail=null;throw error;}
  return structuredClone(f.remote);
 }};
 f.sdk=new TaroMiniReminderSDK(client);
 f.create=()=>new TaroMiniReminderPlan(f.sdk,{storage,storageKey:'plan',randomBytes:async()=>new Uint8Array(32).fill(++random)});
 f.plan=f.create();return f;
}
test('capability and immutable intent precede PUT; reopening reuses exact revision after ambiguous ACK',async()=>{
 const f=fixture();f.fail=Object.assign(Error(),{code:'REQUEST_TIMEOUT'});
 const input=snapshot(),pending=f.plan.sync(input);input.days[0].count=99;
 await assert.rejects(pending,e=>e.code==='REQUEST_TIMEOUT');
 assert.equal(f.requests[0].body.days[0].count,3);
 const persisted=JSON.parse(await f.storage.getItem('plan'));assert.equal(persisted.plan,null);
 const reopened=f.create();assert.equal((await reopened.sync(snapshot())).revision,1);
 assert.deepEqual(f.requests[0].body,f.requests[1].body);
 assert.equal((await reopened.sync(snapshot())).revision,1);
 const changed=snapshot();changed.days[0].count=4;assert.equal((await reopened.sync(changed)).revision,2);
});
test('failed local intent persistence makes zero network requests and does not invent a memory fallback',async()=>{
 const f=fixture();f.failStore=s=>s.revision===1;
 await assert.rejects(f.plan.sync(snapshot()),e=>e.code==='MINI_STORAGE_UNAVAILABLE');assert.equal(f.requests.length,0);
 assert.equal(JSON.parse(await f.storage.getItem('plan')).revision,0);
 f.failStore=null;assert.equal((await f.plan.sync(snapshot())).revision,1);
});
test('ACK local commit failure retains the already durable revision for idempotent retry',async()=>{
 const f=fixture();f.failStore=s=>s.plan!==null;
 await assert.rejects(f.plan.sync(snapshot()),e=>e.code==='MINI_STORAGE_UNAVAILABLE');
 const body=f.requests[0].body;f.failStore=null;await f.create().sync(snapshot());assert.deepEqual(f.requests[1].body,body);
});
test('observations survive ambiguous ACK and replay the grant ID without double allowance',async()=>{
 const f=fixture();await f.plan.sync(snapshot());f.fail=Object.assign(Error(),{code:'REQUEST_TIMEOUT'});
 await assert.rejects(f.plan.observe('template-1','accept'),e=>e.code==='REQUEST_TIMEOUT');
 assert.equal(f.observed,1);const first=f.requests.at(-1).body;
 assert.equal((await f.create().retryObservations()).observedAcceptances,1);
 assert.deepEqual(f.requests.at(-1).body,first);assert.equal(f.observed,1);
 assert.deepEqual(JSON.parse(await f.storage.getItem('plan')).pending,[]);
});
test('observation ACK local commit failure is retried with the same durable observation',async()=>{
 const f=fixture();await f.plan.sync(snapshot());f.failStore=s=>s.plan?.observedAcceptances===1 && s.pending.length===0;
 await assert.rejects(f.plan.observe('template-1','accept'),e=>e.code==='MINI_STORAGE_UNAVAILABLE');
 const grant=f.requests.at(-1).body.grantId;f.failStore=null;await f.create().retryObservations();
 assert.equal(f.requests.at(-1).body.grantId,grant);assert.equal(f.observed,1);
});
test('revoke survives lost response and reopening refuses all new writes until cancellation ACK',async()=>{
 const f=fixture();await f.plan.sync(snapshot());f.fail=Object.assign(Error(),{code:'REQUEST_TIMEOUT'});
 await assert.rejects(f.plan.revoke(),e=>e.code==='REQUEST_TIMEOUT');
 const token=f.requests.at(-1).body.cancellationToken,reopened=f.create(),count=f.requests.length;
 await assert.rejects(reopened.sync(snapshot()),e=>e.code==='MINI_CANCELLATION_PENDING');assert.equal(f.requests.length,count);
 await reopened.revoke();assert.equal(f.requests.at(-1).body.cancellationToken,token);
 const state=JSON.parse(await f.storage.getItem('plan'));assert.equal(state.capability,null);assert.equal(state.plan,null);
 const newer=f.create();await newer.prepare();assert.notEqual(JSON.parse(await f.storage.getItem('plan')).capability,token);
 assert.equal(JSON.parse(await f.storage.getItem('plan')).installationId,state.installationId);
});
test('cancel ACK storage failure keeps the tombstone intent recoverable',async()=>{
 const f=fixture();await f.plan.sync(snapshot());f.failStore=s=>s.capability===null;
 await assert.rejects(f.plan.revoke(),e=>e.code==='MINI_STORAGE_UNAVAILABLE');
 assert.equal(JSON.parse(await f.storage.getItem('plan')).cancelling,true);
 f.failStore=null;await f.create().revoke();assert.equal(f.requests.filter(x=>x.path.endsWith('/revoke')).length,2);
});
test('cancel fences a pending PUT and queued newer plan before any later network send',async()=>{
 const f=fixture();let release,entered;
 const hold=new Promise(resolve=>release=resolve),started=new Promise(resolve=>entered=resolve),original=f.sdk.replace.bind(f.sdk);
 f.sdk.replace=async(...args)=>{entered();await hold;return original(...args);};
 const put=f.plan.sync(snapshot());await started;
 const newer=snapshot();newer.days[0].count=8;const queued=f.plan.sync(newer),cancel=f.plan.revoke();
 release();await assert.rejects(put,e=>e.code==='MINI_CANCELLATION_PENDING');
 await assert.rejects(queued,e=>e.code==='MINI_CANCELLATION_PENDING');await cancel;
 assert.deepEqual(f.requests.map(x=>x.method),['PUT','POST']);assert.ok(f.requests[1].path.endsWith('/revoke'));
});
test('corrupt state and missing crypto fail closed without overwriting a recoverable capability',async()=>{
 const f=fixture();await f.storage.setItem('plan','{}');
 await assert.rejects(f.plan.prepare(),e=>e.code==='MINI_STATE_INVALID');assert.equal(await f.storage.getItem('plan'),'{}');
 await f.storage.removeItem('plan');
 const plan=new TaroMiniReminderPlan(f.sdk,{storage:f.storage,storageKey:'plan',randomBytes:async()=>new Uint8Array(8)});
 await assert.rejects(plan.prepare(),e=>e.code==='MINI_RANDOM_UNAVAILABLE');assert.equal(f.requests.length,0);assert.equal(await f.storage.getItem('plan'),null);
});
test('old template observations are not transferred to a changed template',async()=>{
 const f=fixture();await f.plan.sync(snapshot());f.fail=Error('unknown');await assert.rejects(f.plan.observe('template-1','accept'));
 f.template='template-2';await f.plan.sync(snapshot());const count=f.requests.length;
 await f.plan.retryObservations();assert.equal(f.requests.length,count);assert.deepEqual(JSON.parse(await f.storage.getItem('plan')).pending,[]);
});
