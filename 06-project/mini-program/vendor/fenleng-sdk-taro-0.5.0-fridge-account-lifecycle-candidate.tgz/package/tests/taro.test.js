import assert from 'node:assert/strict';
import test from 'node:test';
import { FenlengBaseClient, TaroAuthSDK } from '../index.js';

test('TaroAuthSDK supports WeChat code login', async () => {
  let request;
  const taroAuth = new TaroAuthSDK(new FenlengBaseClient({baseUrl:'http://localhost:8080', fetch:async(url, init)=>{request={url, init}; return new Response(JSON.stringify({accessToken:'access', refreshToken:'refresh', status:'AUTHENTICATED'}),{status:200});}}), {applicationCode:'demo-app', clientTarget:'miniapp'});
  const res = await taroAuth.loginWithWechatCode('mock-wx-code-123');
  assert.equal(res.status, 'AUTHENTICATED');
  assert.equal(request.url, 'http://localhost:8080/api/platform/v1/auth/wechat/login');
  assert.deepEqual(JSON.parse(request.init.body), {applicationCode:'demo-app', clientId:'demo-app-miniapp', code:'mock-wx-code-123'});
});

test('TaroAuthSDK requires registration email verification', async () => {
  const calls = [];
  const auth = new TaroAuthSDK(new FenlengBaseClient({baseUrl:'http://localhost:8080', fetch:async(url, init)=>{calls.push({url, init}); return new Response(JSON.stringify(url.endsWith('/auth/register')?{accessToken:'registered-access',refreshToken:'registered-refresh'}:{}),{status:200});}}), {applicationCode:'demo-app'});
  await auth.requestRegistrationEmailVerification('user@example.com');
  await auth.register({email:'user@example.com', password:'strong-password', username:'person', displayName:'Person', verificationCode:'code'});
  assert.equal(await auth.client.storage.getItem(auth.client.tokenKey),'registered-access');
  assert.equal(await auth.client.storage.getItem(`${auth.client.tokenKey}:refresh`),'registered-refresh');
  assert.equal(calls[0].url.endsWith('/auth/registration-email-verification'), true);
  assert.equal(JSON.parse(calls[1].init.body).verificationCode, 'code');
});
