# `@fenleng/sdk-taro`

Fenleng Taro 微信/支付宝小程序官方 SDK。导出 `TaroAuthSDK`、`TaroCommerceSDK` 与 `TaroStorageAdapter`。

## 微信登录

每个 FL 项目只需要提供 Platform API、`applicationCode` 和客户端表面；
`clientId` 默认派生为 `<applicationCode>-<clientTarget>`。

```js
const auth = new TaroAuthSDK(client, {
  applicationCode: 'your-app',
  clientTarget: 'miniapp',
});

await auth.loginWithWechatCode(await Taro.login().then(({ code }) => code));
```

小程序 AppSecret 只配置在 Shared Platform 服务端，不能进入 Taro 构建参数。

## 持久存储与受控 Session

`TaroStorageAdapter` 现在必须显式传入 `getStorageSync/setStorageSync/removeStorageSync` 驱动，不再以内存代替真实持久化。`TaroPlatformClient` 使用注入的 `Taro.request` 驱动，不要求浏览器 fetch/Response；认证写不自动重放。

```js
// 仅在用户已明确同意协议后创建这些对象。
const storage = new TaroStorageAdapter(Taro, {prefix: 'patent.identity.v1:'});
const client = new TaroPlatformClient({baseUrl, storage, request: input => Taro.request(input)});
const auth = new TaroAuthSDK(client, {applicationCode, clientId});
const session = new TaroSessionCoordinator(auth);
await session.start({consent: true}); // 无刷新令牌时保持 anonymous，不触发平台授权。
// 用户主动选择平台登录后，Adapter 才获取一次性 code。
await session.loginWithCode('wechat', code);
```

应用 onShow 调用 `resume()`，onHide 调用 `suspend()`；前台每5分钟受控刷新，后台不启动计时器。401进入重新认证，网络失败保留可恢复状态。注销/撤回同意清令牌并使原会话 predicate 失效；迟到认证或轮换不复活会话。`close()` 停止计时/监听，正常已登录会话保留供下次恢复；存在在途认证时清理其迟到令牌。

支付宝 `loginWithAlipayCode`、抖音 `loginWithDouyinCode` 使用各自平台交换路由；必须先完成共享平台对应 Provider 登记和契约，不能仅凭客户端方法存在声明真实登录已验收。三端生产 AppID/合法域名/开发者工具及真机验证独立记录。

## 微信提醒候选接口

`TaroMiniReminderSDK` 对应 Shared Platform 本地候选的配置、计划、许可观察、状态和撤销五项操作；需要后端正式发布及启用，不能仅因SDK方法存在宣称可发送。`observedAcceptances` 是客户端许可观察，不能当微信核验配额；ACCEPTED是Provider受理，UNCONFIRMED不自动重发。

`TaroMiniReminderPlan(sdk,{storage,randomBytes,storageKey})` 提供单所有者持久协调。storage须为持久存储并保留在认证清理之外；randomBytes必须调用平台密码学随机源返回32字节，无Math.random降级。prepare先持久保存安装标识和取消凭据；sync在PUT之前写入不可变快照/安全整数revision，相同快照保留revision，响应不确定由调用方明确重试。observe须在原生用户许可结果之后调用，先保存唯一grantId，失败用retryObservations重放同一观察，不再累计新许可。

原生requestSubscribeMessage必须由宿主用户点击直接调用，之前不得await登录、随机数或HTTP；预先在前台准备配置和计划，未就绪时引导登录/重试。SDK不隐式调用原生许可或登录。只上传日期、时间与数量，不上传食材、照片、食材ID或客户端OpenID。

退出、换账号、关闭订阅、撤回隐私时先调用plan.revoke：立即阻止新同步，持久标记cancelling，再请求无会话撤销；TaroPlatformClient的authentication:none路径完全跳过令牌存储，也去掉所有Authorization大小写变体。只有服务端确认且本机清理提交成功，才清除取消凭据。失败保留同一凭据，重启时先继续revoke；不能用重新创建plan规避待取消状态。已受理消息无法召回。同一实例revoke后保持停止，未来重新开启由宿主在满足同意/身份条件后构造新实例。

同storageKey只能有一个协调器所有者；并行生命周期由宿主统一串行管理。保留对应服务端和storageKey直到取消确认；服务器环境迁移需先完成旧环境撤销。storage损坏不会悄悄生成新能力，须保留可恢复入口。当前候选有本地HTTP与存储故障测试，无微信主机/生产送达证明。

## 账号生命周期候选

TaroAuthSDK提供createFederatedDeletionChallenge、confirmFederatedDeletionReauthentication、dataRequests、requestData；联合注销provider支持WECHAT/APPLE/FIREBASE。微信App/小程序应先获得挑战，再主动取得新native code，以identityToken字段提交，不能调用普通登录代替重认证。DELETE请求传与挑战完全一致的idempotencyKey和actionConfirmationId；TaroPlatformClient发送Idempotency-Key与X-Action-Confirmation（管理操作的Action-Confirmation-Id不能替代）。

这些接口使用当前身份，不清空/替换Token、不创建游客、不启动native登录。原生TaroPlatformClient写请求没有自动重放；注入其它传输时须遵守其自身重试策略。服务器回执必须由产品校验并持久化，再本机清理旧会话。网络失败或401不等于申请失败，不得自动重新登录同一账号，以免撤销已受理申请。七天等待、登录撤销、实际处理状态以服务端为准。候选未发布，正式提供者和产品UI验收尚待接续。
