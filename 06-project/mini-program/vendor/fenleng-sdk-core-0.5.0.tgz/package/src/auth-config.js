import { FenlengSdkError } from './client.js';

const APPLICATION_CODE_PATTERN = /^[a-z][a-z0-9-]{2,63}$/;
const CLIENT_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{2,127}$/;
const CLIENT_TARGET_PATTERN = /^[a-z][a-z0-9-]{1,31}$/;

/**
 * Creates the stable application/client context shared by every FL SDK.
 * A client ID defaults to `<applicationCode>-<clientTarget>` so consumers
 * only need to choose the project code and surface.
 */
export function resolveFenlengAuthConfig({
  applicationCode,
  clientId = null,
  clientTarget = null,
  wechatAppId = null,
} = {}, defaultClientTarget = null) {
  if (typeof applicationCode !== 'string' || !APPLICATION_CODE_PATTERN.test(applicationCode)) {
    throw new FenlengSdkError('CONFIGURATION_INVALID', 'applicationCode must be a valid FL application code');
  }
  const target = clientTarget || defaultClientTarget;
  if (target !== null && (typeof target !== 'string' || !CLIENT_TARGET_PATTERN.test(target))) {
    throw new FenlengSdkError('CONFIGURATION_INVALID', 'clientTarget must be a valid FL client target');
  }
  const resolvedClientId = clientId || (target ? `${applicationCode}-${target}` : null);
  if (typeof resolvedClientId !== 'string' || !CLIENT_ID_PATTERN.test(resolvedClientId)) {
    throw new FenlengSdkError('CONFIGURATION_INVALID', 'clientId or clientTarget is required');
  }
  if (wechatAppId !== null && (typeof wechatAppId !== 'string' || !wechatAppId.trim())) {
    throw new FenlengSdkError('CONFIGURATION_INVALID', 'wechatAppId must be a non-empty string');
  }
  return Object.freeze({
    applicationCode,
    clientId: resolvedClientId,
    clientTarget: target,
    wechatAppId,
  });
}
