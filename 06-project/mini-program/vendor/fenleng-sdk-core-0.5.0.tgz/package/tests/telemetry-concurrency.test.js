import test from 'node:test';
import assert from 'node:assert/strict';
import {FenlengTelemetryLogger} from '../src/telemetry.js';
function fixture(options={}) {
  const calls=[];
  const logger=new FenlengTelemetryLogger({request:(_path,_method,body)=>new Promise((resolve,reject)=>calls.push({body,resolve,reject}))},{catalog:['test.event.v1'],consent:()=>true,context:()=>({platform:'ohos',appVersion:'1',buildNumber:'1',releaseChannel:'china',locale:'zh-CN'}),maxQueueSize:2,batchSize:2,...options});
  return {logger,calls,track:source=>logger.track('test.event.v1',{source})};
}
test('in-flight overflow only removes acknowledged events still in queue',async()=>{
  const {logger,calls,track}=fixture();track('a');track('b');const sent=logger.flush();track('c');track('d');
  calls[0].resolve();assert.equal(await sent,2);assert.equal(logger.pendingCount,2);
  const next=logger.flush();assert.deepEqual(calls[1].body.events.map(e=>e.properties.source),['c','d']);calls[1].resolve();assert.equal(await next,2);assert.equal(logger.pendingCount,0);
});
test('withdraw and renew consent preserve new events after late response',async()=>{
  const {logger,calls,track}=fixture();track('old');const sent=logger.flush();logger.withdrawConsent();track('new');calls[0].resolve();assert.equal(await sent,0);assert.equal(logger.pendingCount,1);
  const next=logger.flush();assert.equal(calls[1].body.events[0].properties.source,'new');calls[1].resolve();await next;
});
test('overlapping flushes share one request and failed batch stays retryable',async()=>{
  const {logger,calls,track}=fixture();track('a');const first=logger.flush();const duplicate=logger.flush();assert.equal(first,duplicate);assert.equal(calls.length,1);
  calls[0].reject(Error('offline'));await assert.rejects(first,/offline/);assert.equal(logger.pendingCount,1);
  const retry=logger.flush();assert.equal(calls.length,2);calls[1].resolve();assert.equal(await retry,1);
});
test('withdrawn failed flush never restores cleared events',async()=>{
  const {logger,calls,track}=fixture();track('old');const first=logger.flush();logger.withdrawConsent();track('new');calls[0].reject(Error('offline'));await assert.rejects(first);assert.equal(logger.pendingCount,1);
});
test('ohos context is explicit and unsupported platforms still reject',()=>{
  const {track}=fixture();assert.equal(track('a').context.platform,'ohos');
  const invalid=fixture({context:()=>({platform:'invalid'})});assert.throws(()=>invalid.track('a'),e=>e.code==='TELEMETRY_CONTEXT_INVALID');
});
