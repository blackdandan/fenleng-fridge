# `@fenleng/sdk-taro`

Fenleng Taro 微信/支付宝小程序官方 SDK。导出 `TaroAuthSDK`、`TaroCommerceSDK` 与 `TaroStorageAdapter`。

## 微信登录

每个 FL 项目只需要提供 Platform API、`applicationCode` 和客户端表面；
`clientId` 默认派生为 `<applicationCode>-<clientTarget>`。

```js
const auth = new TaroAuthSDK(client, {
  applicationCode: 'your-app',
  clientTarget: 'miniapp',
});

await auth.loginWithWechatCode(await Taro.login().then(({ code }) => code));
```

小程序 AppSecret 只配置在 Shared Platform 服务端，不能进入 Taro 构建参数。

## 持久存储与受控 Session

`TaroStorageAdapter` 现在必须显式传入 `getStorageSync/setStorageSync/removeStorageSync` 驱动，不再以内存代替真实持久化。`TaroPlatformClient` 使用注入的 `Taro.request` 驱动，不要求浏览器 fetch/Response；认证写不自动重放。

```js
// 仅在用户已明确同意协议后创建这些对象。
const storage = new TaroStorageAdapter(Taro, {prefix: 'patent.identity.v1:'});
const client = new TaroPlatformClient({baseUrl, storage, request: input => Taro.request(input)});
const auth = new TaroAuthSDK(client, {applicationCode, clientId});
const session = new TaroSessionCoordinator(auth);
await session.start({consent: true}); // 无刷新令牌时保持 anonymous，不触发平台授权。
// 用户主动选择平台登录后，Adapter 才获取一次性 code。
await session.loginWithCode('wechat', code);
```

应用 onShow 调用 `resume()`，onHide 调用 `suspend()`；前台每5分钟受控刷新，后台不启动计时器。401进入重新认证，网络失败保留可恢复状态。注销/撤回同意清令牌并使原会话 predicate 失效；迟到认证或轮换不复活会话。`close()` 停止计时/监听，正常已登录会话保留供下次恢复；存在在途认证时清理其迟到令牌。

支付宝 `loginWithAlipayCode`、抖音 `loginWithDouyinCode` 使用各自平台交换路由；必须先完成共享平台对应 Provider 登记和契约，不能仅凭客户端方法存在声明真实登录已验收。三端生产 AppID/合法域名/开发者工具及真机验证独立记录。
