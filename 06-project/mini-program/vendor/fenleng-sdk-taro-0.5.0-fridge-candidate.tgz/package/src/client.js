import {FenlengSdkError, SDK_VERSION} from '@fenleng/sdk-core';

/** Taro.request-backed Platform transport. Does not require browser fetch/Response. */
export class TaroPlatformClient {
  constructor({baseUrl, storage, request, tokenKey = 'fl_session_token', timeoutMs = 10000} = {}) {
    let url;try {url=new URL(baseUrl);}catch {throw invalid();}
    if (url.protocol!=='https:' && !['localhost','127.0.0.1'].includes(url.hostname)) throw invalid();
    if (url.username || url.password || url.search || url.hash || !storage || typeof request!=='function') throw invalid();
    this.baseUrl=url.toString().replace(/\/$/,'');this.storage=storage;this.driver=request;this.tokenKey=tokenKey;this.timeoutMs=timeoutMs;
  }
  async request(endpoint,method='GET',body=null,options={}) {
    if (typeof endpoint!=='string' || !endpoint.startsWith('/api/platform/v1/')) throw invalid();
    const timeout=options.timeoutMs ?? this.timeoutMs;
    if (!Number.isInteger(timeout) || timeout<100 || timeout>60000) throw invalid();
    if(options.signal?.aborted)throw cancelled();
    const access=await this.storage.getItem(this.tokenKey);
    if(options.signal?.aborted)throw cancelled();
    const header={'Content-Type':'application/json','X-Fenleng-API-Version':'1.0.0','X-Fenleng-SDK-Version':SDK_VERSION,...(access?{Authorization:`Bearer ${access}`}:{})};
    if(options.idempotencyKey)header['Idempotency-Key']=options.idempotencyKey;
    if(options.traceId)header.traceparent=options.traceId;
    Object.assign(header,options.headers || {});
    return new Promise((resolve,reject) => {
      let done=false,task;
      const finish=(error,value) => {if(done)return;done=true;options.signal?.removeEventListener('abort',abort);error?reject(error):resolve(value);};
      const abort=() => {finish(cancelled());task?.abort?.();};
      options.signal?.addEventListener('abort',abort,{once:true});
      try {
        task=this.driver({url:`${this.baseUrl}${endpoint}`,method:method.toUpperCase(),data:body,header,timeout,
          success:response => {
            let value=response.data;
            if(typeof value==='string')try {value=value?JSON.parse(value):null;}catch {finish(new FenlengSdkError('INVALID_API_RESPONSE','Platform returned invalid JSON'));return;}
            if(response.statusCode>=200 && response.statusCode<300){finish(null,value);return;}
            const code=typeof value?.code==='string' && /^[A-Z][A-Z0-9_]{1,95}$/.test(value.code)?value.code:`HTTP_${response.statusCode}`;
            finish(new FenlengSdkError(code,'Platform request failed',{status:response.statusCode,requestId:response.header?.['x-request-id'] || null}));
          },
          fail:error => finish(new FenlengSdkError(/timeout/i.test(error?.errMsg || '')?'REQUEST_TIMEOUT':'NETWORK_ERROR','Platform request failed')),
        });
        // Some hosts return a rejecting Promise as well as invoking fail.
        task?.catch?.(() => {});
        if(done && options.signal?.aborted)task?.abort?.();
      } catch {finish(new FenlengSdkError('NETWORK_ERROR','Platform request failed'));}
    });
  }
}
function invalid(){return new FenlengSdkError('CONFIGURATION_INVALID','Platform transport configuration is invalid');}
function cancelled(){return new FenlengSdkError('REQUEST_CANCELLED','Platform request was cancelled');}
