export interface TaroAuthConfig {readonly applicationCode:string;readonly clientId?:string|null;readonly clientTarget?:string|null;}
export interface TaroStorage {getItem(key:string):Promise<string|null>;setItem(key:string,value:string):Promise<void>;removeItem(key:string):Promise<void>;}
export interface TaroRequestOptions {signal?:AbortSignal;timeoutMs?:number;idempotencyKey?:string;traceId?:string;headers?:Record<string,string>;}
export interface TaroSdkClient {readonly storage:TaroStorage;readonly tokenKey:string;request(endpoint:string,method?:string,body?:unknown,options?:TaroRequestOptions):Promise<any>;}
export interface TaroStorageDriver {getStorageSync(key:string):unknown;setStorageSync(key:string,value:string):void;removeStorageSync(key:string):void;}
export class TaroStorageAdapter implements TaroStorage {
 constructor(driver:TaroStorageDriver,options?:{prefix?:string});
 getItem(key:string):Promise<string|null>;setItem(key:string,value:string):Promise<void>;removeItem(key:string):Promise<void>;
}
export interface TaroNativeRequest {
 url:string;method:string;data:unknown;header:Record<string,string>;timeout:number;
 success(response:{statusCode:number;data:unknown;header?:Record<string,string>}):void;
 fail(error:{errMsg?:string}):void;
}
export class TaroPlatformClient implements TaroSdkClient {
 constructor(options:{baseUrl:string;storage:TaroStorage;request:(input:TaroNativeRequest)=>unknown;tokenKey?:string;timeoutMs?:number});
 readonly storage:TaroStorage;readonly tokenKey:string;
 request(endpoint:string,method?:string,body?:unknown,options?:TaroRequestOptions):Promise<any>;
}
export interface TaroRegistrationInput {readonly email:string;readonly password:string;readonly username:string;readonly displayName:string;readonly verificationCode:string;readonly device?:unknown;}
export type TaroIdentityProvider='wechat'|'alipay'|'douyin';
export class TaroAuthSDK {
 constructor(client:TaroSdkClient,config:TaroAuthConfig);
 readonly sessionKind:'guest'|'account';
 loginAsGuest(options?:Pick<TaroRequestOptions,'signal'|'timeoutMs'>&{device?:unknown}):Promise<Record<string,unknown>>;
 loginWithWechatCode(code:string,options?:TaroRequestOptions&{device?:unknown}):Promise<Record<string,unknown>>;
 loginWithAlipayCode(code:string,options?:TaroRequestOptions&{device?:unknown}):Promise<Record<string,unknown>>;
 loginWithDouyinCode(code:string,options?:TaroRequestOptions&{device?:unknown}):Promise<Record<string,unknown>>;
 loginWithCode(provider:TaroIdentityProvider,code:string,options?:TaroRequestOptions&{device?:unknown}):Promise<Record<string,unknown>>;
 loginWithPassword(email:string,password:string,options?:TaroRequestOptions&{device?:unknown}):Promise<Record<string,unknown>>;
 requestRegistrationEmailVerification(email:string,options?:TaroRequestOptions):Promise<Record<string,unknown>>;
 register(input:TaroRegistrationInput,options?:TaroRequestOptions):Promise<Record<string,unknown>>;
 refresh(options?:TaroRequestOptions):Promise<Record<string,unknown>>;
 logout(options?:{allSessions?:boolean;localOnly?:boolean}):Promise<void>;
 endLocalSession():Promise<void>;accessToken():Promise<string|null>;
}
export type TaroSessionStatus='consent-required'|'anonymous'|'authenticating'|'authenticated'|'restoring'|'ending'|'reauthentication-required'|'binding-required'|'blocked'|'error';
export class TaroFeedbackSDK {
 constructor(client:TaroSdkClient,config:{projectId:string;version:string});
 submit(message:string,idempotencyKey:string,options?:{signal?:AbortSignal}):Promise<{id:string;status:'RECEIVED'}>;
}
export interface TaroSessionSnapshot {readonly status:TaroSessionStatus;readonly refreshing:boolean;readonly errorCode:string|null;readonly identityKind?:'guest'|'account'|null;}
export class TaroSessionCoordinator {
 constructor(auth:TaroAuthSDK,options?:{refreshIntervalMs?:number;timers?:{setTimeout(callback:()=>void,ms:number):unknown;clearTimeout(id:unknown):void}});
 snapshot():TaroSessionSnapshot;subscribe(listener:()=>void):()=>void;captureSession():()=>boolean;accessToken():Promise<string|null>;
 start(options?:{consent?:boolean}):Promise<unknown>;restore():Promise<unknown>;
 loginAsGuest(options?:Pick<TaroRequestOptions,'signal'|'timeoutMs'>&{device?:unknown}):Promise<unknown>;
 loginWithCode(provider:TaroIdentityProvider,code:string,options?:TaroRequestOptions):Promise<unknown>;
 loginWithPassword(email:string,password:string,options?:TaroRequestOptions):Promise<unknown>;
 register(input:TaroRegistrationInput,options?:TaroRequestOptions):Promise<unknown>;
 requestRegistrationEmailVerification(email:string,options?:TaroRequestOptions):Promise<Record<string,unknown>>;
 refresh():Promise<unknown>;suspend():void;resume():Promise<unknown>;
 logout(options?:{localOnly?:boolean}):Promise<void>;invalidate():Promise<void>;withdrawConsent():Promise<void>;close():Promise<void>;
}
export interface TelemetryContext {
 readonly platform:'ios'|'android'|'ohos'|'web'|'mini-program';readonly appVersion:string;readonly buildNumber:string;
 readonly releaseChannel:'china'|'global'|'internal';readonly locale:string;readonly sessionId?:string;
}
export class TaroTelemetrySDK {
 constructor(client:TaroSdkClient,options:{catalog:readonly string[];consent:()=>boolean;context:()=>TelemetryContext;maxQueueSize?:number;batchSize?:number});
 track(eventName:string,properties?:Readonly<Record<string,unknown>>):unknown;flush(options?:{idempotencyKey?:string}):Promise<number>;withdrawConsent():void;readonly pendingCount:number;
}
export type MiniPaymentPresentation='WECHAT_MINI_PROGRAM'|'ALIPAY_MINI_PROGRAM'|'DOUYIN_MINI_PROGRAM';
export class TaroCommerceSDK {
 constructor(client:TaroSdkClient);
 purchaseAgreement(priceOptionId:string,options?:TaroRequestOptions):Promise<unknown>;
 createOrder(priceOptionId:string,idempotencyKey:string,options?:TaroRequestOptions&{agreementConfirmation?:unknown}):Promise<unknown>;
 order(orderId:string,options?:TaroRequestOptions):Promise<unknown>;
 payment(attemptId:string,options?:TaroRequestOptions):Promise<unknown>;
 reconcilePayment(attemptId:string,idempotencyKey:string,options?:TaroRequestOptions):Promise<unknown>;
 cancelPayment(attemptId:string,idempotencyKey:string,options?:TaroRequestOptions):Promise<unknown>;
 startPayment(orderId:string,provider:'wechat-pay'|'alipay'|'douyin-pay',options:{presentation:MiniPaymentPresentation;idempotencyKey:string;returnUrl?:null}&TaroRequestOptions):Promise<unknown>;
 requestWechatPayment(orderId:string,idempotencyKey:string,options?:TaroRequestOptions):Promise<unknown>;
}
export type TaroPaymentPhase='ready'|'invoking'|'checking'|'pending'|'paid'|'cancelled'|'refunded'|'partially-refunded'|'closing'|'unknown'|'closed';
export interface TaroPaymentSnapshot {readonly phase:TaroPaymentPhase;readonly hostOutcome:string|null;readonly errorCode:string|null;}
export class TaroPaymentSession {
 constructor(commerce:Pick<TaroCommerceSDK,'order'|'cancelPayment'>,options:{orderId:string;attemptId:string;invoke:(payload:unknown)=>Promise<{kind:string}>;isSessionActive?:()=>boolean});
 snapshot():TaroPaymentSnapshot;subscribe(listener:()=>void):()=>void;
 launch(payload:unknown):Promise<unknown>;check():Promise<unknown>;cancel(idempotencyKey:string):Promise<unknown>;close():void;
}
