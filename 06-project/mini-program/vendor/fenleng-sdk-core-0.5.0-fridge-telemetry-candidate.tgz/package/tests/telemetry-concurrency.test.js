import test from 'node:test';
import assert from 'node:assert/strict';
import {FenlengTelemetryLogger} from '../src/telemetry.js';
function fixture(options={}) {
  const calls=[];
  const logger=new FenlengTelemetryLogger({request:(_path,_method,body,options)=>new Promise((resolve,reject)=>calls.push({body,options,resolve:(value)=>resolve(value ?? {accepted:body.events.length}),reject}))},{catalog:['test.event.v1'],consent:()=>true,context:()=>({platform:'ohos',appVersion:'1',buildNumber:'1',releaseChannel:'china',locale:'zh-CN'}),maxQueueSize:2,batchSize:2,...options});
  return {logger,calls,track:source=>logger.track('test.event.v1',{source})};
}
test('in-flight overflow only removes acknowledged events still in queue',async()=>{
  const {logger,calls,track}=fixture();track('a');track('b');const sent=logger.flush();track('c');track('d');
  calls[0].resolve();assert.equal(await sent,2);assert.equal(logger.pendingCount,2);
  const next=logger.flush();assert.deepEqual(calls[1].body.events.map(e=>e.properties.source),['c','d']);calls[1].resolve();assert.equal(await next,2);assert.equal(logger.pendingCount,0);
});
test('withdraw and renew consent preserve new events after late response',async()=>{
  const {logger,calls,track}=fixture();track('old');const sent=logger.flush();logger.withdrawConsent();track('new');calls[0].resolve();assert.equal(await sent,0);assert.equal(logger.pendingCount,1);
  const next=logger.flush();assert.equal(calls[1].body.events[0].properties.source,'new');calls[1].resolve();await next;
});
test('overlapping flushes share one request and failed batch stays retryable',async()=>{
  const {logger,calls,track}=fixture();track('a');const first=logger.flush();const duplicate=logger.flush();assert.equal(first,duplicate);assert.equal(calls.length,1);
  calls[0].reject(Error('offline'));await assert.rejects(first,/offline/);assert.equal(logger.pendingCount,1);
  const retry=logger.flush();assert.equal(calls.length,2);calls[1].resolve();assert.equal(await retry,1);
});
test('withdrawn failed flush never restores cleared events',async()=>{
  const {logger,calls,track}=fixture();track('old');const first=logger.flush();logger.withdrawConsent();track('new');calls[0].reject(Error('offline'));await assert.rejects(first);assert.equal(logger.pendingCount,1);
});
test('ohos context is explicit and unsupported platforms still reject',()=>{
  const {track}=fixture();assert.equal(track('a').context.platform,'ohos');
  const invalid=fixture({context:()=>({platform:'invalid'})});assert.throws(()=>invalid.track('a'),e=>e.code==='TELEMETRY_CONTEXT_INVALID');
});
test('failed batch pins identical payload and key while new events arrive',async()=>{
 const {logger,calls,track}=fixture();track('old');const first=logger.flush({idempotencyKey:'original-key'});
 const payload=JSON.stringify(calls[0].body);calls[0].reject(Error('offline'));await assert.rejects(first);
 track('new');const retry=logger.flush({idempotencyKey:'replacement-must-not-be-used'});
 assert.equal(JSON.stringify(calls[1].body),payload);assert.equal(calls[1].options.idempotencyKey,'original-key');
 calls[1].resolve();assert.equal(await retry,1);assert.equal(logger.pendingCount,1);
 const next=logger.flush({idempotencyKey:'new-batch-key'});assert.equal(calls[2].options.idempotencyKey,'new-batch-key');
 calls[2].resolve();await next;
});
test('malformed and partial acknowledgements retain the batch for identical retry',async()=>{
 const {logger,calls,track}=fixture();track('a');const first=logger.flush({idempotencyKey:'receipt-key'});
 calls[0].resolve({});await assert.rejects(first,e=>e.code==='TELEMETRY_RESPONSE_INVALID');assert.equal(logger.pendingCount,1);
 const second=logger.flush();calls[1].resolve({accepted:0});await assert.rejects(second,e=>e.code==='TELEMETRY_RESPONSE_INVALID');
 const retry=logger.flush();calls[2].resolve();assert.equal(await retry,1);
});
test('JSON snapshot works without structuredClone and caller mutation cannot change queued values',async()=>{
 const {logger,calls}=fixture();const properties={nested:{source:'original'}};
 const original=globalThis.structuredClone;globalThis.structuredClone=undefined;
 try {
  const returned=logger.track('test.event.v1',properties);properties.nested.source='changed';returned.properties.nested.source='also-changed';
  const sent=logger.flush();assert.equal(calls[0].body.events[0].properties.nested.source,'original');calls[0].resolve();await sent;
  const cycle={};cycle.self=cycle;assert.throws(()=>logger.track('test.event.v1',cycle),e=>e.code==='TELEMETRY_PROPERTIES_INVALID');
  assert.throws(()=>logger.track('test.event.v1',{value:undefined}),e=>e.code==='TELEMETRY_PROPERTIES_INVALID');
 } finally {globalThis.structuredClone=original;}
});
