# `@fenleng/sdk-core`

Fenleng 跨端客户端 SDK 通用核心包。提供基础 HTTP 拦截器（`X-Fenleng-API-Version`, `X-Idempotency-Key`）、抽象存储适配器（`StorageAdapter`）、SSE 流式连接拦截器与埋点收集器。
