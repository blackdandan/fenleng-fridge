// Generated from contract/platform-api.json. Do not edit directly.
export const PLATFORM_OPENAPI_SHA256 = "5f76148c38d9b0afbe1d3788fcef23f1453894e3b04974726ad71504cff6872f";
export const PLATFORM_API_VERSION = "1.10.0";
export const PLATFORM_OPERATIONS = Object.freeze({
  "abandonAppleCommercePayment": {
    "method": "POST",
    "path": "/api/platform/v1/commerce/payments/{attemptId}/abandon-apple"
  },
  "authorizeCliOwnerChallenge": {
    "method": "POST",
    "path": "/api/platform/v1/auth/cli/authorize"
  },
  "cancelCommercePayment": {
    "method": "POST",
    "path": "/api/platform/v1/commerce/payments/{attemptId}/cancel"
  },
  "cancelControlledOperationTask": {
    "method": "POST",
    "path": "/api/platform/v1/admin/operations/tasks/{taskId}/cancel"
  },
  "cancelCurrentUserCommerceSubscription": {
    "method": "POST",
    "path": "/api/platform/v1/commerce/subscription/cancel"
  },
  "cancelUnpaidCreditPackIntent": {
    "method": "POST",
    "path": "/api/platform/v1/commerce/orders/cancel-credit-intent"
  },
  "cancelUnpaidCreditPackOrder": {
    "method": "POST",
    "path": "/api/platform/v1/commerce/orders/{id}/cancel-credit"
  },
  "changeApplicationMemberStatus": {
    "method": "PATCH",
    "path": "/api/platform/v1/admin/applications/{applicationId}/members/{userId}/status"
  },
  "changeApplicationStatus": {
    "method": "PATCH",
    "path": "/api/platform/v1/admin/applications/{applicationId}/status"
  },
  "changeCurrentUserConsent": {
    "method": "PUT",
    "path": "/api/platform/v1/users/me/consents"
  },
  "changeUserStatus": {
    "method": "PATCH",
    "path": "/api/platform/v1/admin/users/{userId}/status"
  },
  "checkProviderIntegrationReadiness": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/provider-registrations/readiness"
  },
  "claimQrLoginChallenge": {
    "method": "POST",
    "path": "/api/platform/v1/auth/qr/challenges/status"
  },
  "confirmEmailVerification": {
    "method": "POST",
    "path": "/api/platform/v1/auth/email-verification/confirm"
  },
  "confirmFederatedDeletionReauthentication": {
    "method": "POST",
    "path": "/api/platform/v1/auth/step-up/self-deletion/challenges/{challengeId}/confirm"
  },
  "confirmQrLoginChallenge": {
    "method": "POST",
    "path": "/api/platform/v1/auth/qr/challenges/confirm"
  },
  "createApplication": {
    "method": "POST",
    "path": "/api/platform/v1/admin/applications"
  },
  "createApplicationRole": {
    "method": "POST",
    "path": "/api/platform/v1/admin/applications/{applicationId}/roles"
  },
  "createCliOwnerChallenge": {
    "method": "POST",
    "path": "/api/platform/v1/auth/cli/challenge"
  },
  "createCommerceOrder": {
    "method": "POST",
    "path": "/api/platform/v1/commerce/orders"
  },
  "createFederatedDeletionChallenge": {
    "method": "POST",
    "path": "/api/platform/v1/auth/step-up/self-deletion/challenges"
  },
  "createOAuthClient": {
    "method": "POST",
    "path": "/api/platform/v1/admin/applications/{applicationId}/clients"
  },
  "deleteOwnerConsoleAdministrator": {
    "method": "DELETE",
    "path": "/api/platform/v1/console/administrators/{administratorId}"
  },
  "editOwnerConsoleCatalog": {
    "method": "POST",
    "path": "/api/platform/v1/console/catalog"
  },
  "forceLogoutUser": {
    "method": "POST",
    "path": "/api/platform/v1/admin/users/{userId}/sessions/revoke"
  },
  "generateQrLoginChallenge": {
    "method": "POST",
    "path": "/api/platform/v1/auth/qr/challenges"
  },
  "getAdminIncident": {
    "method": "GET",
    "path": "/api/platform/v1/admin/incidents/{incidentId}"
  },
  "getAdminOperationsStatus": {
    "method": "GET",
    "path": "/api/platform/v1/admin/operations/status"
  },
  "getApplication": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}"
  },
  "getApplicationManagementActivityAnalytics": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/analytics/activity"
  },
  "getApplicationManagementAnalytics": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/analytics"
  },
  "getApplicationManagementAnalyticsFacts": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/analytics/facts"
  },
  "getApplicationManagementCapabilities": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/capabilities"
  },
  "getApplicationManagementCatalog": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/catalog"
  },
  "getApplicationManagementContext": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/context"
  },
  "getApplicationManagementFunnelAnalytics": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/analytics/funnels/{definitionId}"
  },
  "getApplicationManagementOrder": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/orders/{orderId}"
  },
  "getApplicationManagementOverview": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/overview"
  },
  "getApplicationManagementRetentionAnalytics": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/analytics/retention"
  },
  "getApplicationManagementUser": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/users/{userId}"
  },
  "getApplicationMember": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/members/{userId}"
  },
  "getApplicationMetrics": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/metrics"
  },
  "getApplicationPackageCatalog": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/catalog/packages/{packageId}"
  },
  "getApplicationRole": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/roles/{roleCode}"
  },
  "getApplicationServiceOrder": {
    "method": "GET",
    "path": "/api/platform/v1/service/applications/{applicationId}/commerce/orders/{orderId}"
  },
  "getAuditEvent": {
    "method": "GET",
    "path": "/api/platform/v1/admin/audit-events/{eventId}"
  },
  "getCommerceOrderTrace": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/orders/{orderId}/trace"
  },
  "getControlledOperationTask": {
    "method": "GET",
    "path": "/api/platform/v1/admin/operations/tasks/{taskId}"
  },
  "getCurrentUser": {
    "method": "GET",
    "path": "/api/platform/v1/users/me"
  },
  "getCurrentUserCommerceOrder": {
    "method": "GET",
    "path": "/api/platform/v1/commerce/orders/{orderId}"
  },
  "getCurrentUserCommercePaymentAttempt": {
    "method": "GET",
    "path": "/api/platform/v1/commerce/payments/{attemptId}"
  },
  "getCurrentUserCommerceSubscription": {
    "method": "GET",
    "path": "/api/platform/v1/commerce/subscription"
  },
  "getDataGovernanceStatus": {
    "method": "GET",
    "path": "/api/platform/v1/admin/data-governance/status"
  },
  "getFeatureFlags": {
    "method": "GET",
    "path": "/api/platform/v1/feature-flags"
  },
  "getJwks": {
    "method": "GET",
    "path": "/api/platform/v1/oauth/jwks"
  },
  "getKpiDecisionSummary": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/kpi-summary"
  },
  "getMatrixProjectOverview": {
    "method": "GET",
    "path": "/api/platform/v1/admin/matrix/projects/{projectId}"
  },
  "getOAuthClient": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/clients/{oauthClientId}"
  },
  "getOwnerActivityAnalytics": {
    "method": "GET",
    "path": "/api/platform/v1/console/analytics/activity"
  },
  "getOwnerConsoleAdministrator": {
    "method": "GET",
    "path": "/api/platform/v1/console/auth/me"
  },
  "getOwnerConsoleAnalytics": {
    "method": "GET",
    "path": "/api/platform/v1/console/analytics"
  },
  "getOwnerConsoleApplications": {
    "method": "GET",
    "path": "/api/platform/v1/console/applications"
  },
  "getOwnerConsoleCatalog": {
    "method": "GET",
    "path": "/api/platform/v1/console/catalog"
  },
  "getOwnerConsoleOrder": {
    "method": "GET",
    "path": "/api/platform/v1/console/order"
  },
  "getOwnerConsoleOverview": {
    "method": "GET",
    "path": "/api/platform/v1/console/overview"
  },
  "getOwnerConsoleServer": {
    "method": "GET",
    "path": "/api/platform/v1/console/server"
  },
  "getOwnerConsoleUser": {
    "method": "GET",
    "path": "/api/platform/v1/console/user"
  },
  "getOwnerRetentionAnalytics": {
    "method": "GET",
    "path": "/api/platform/v1/console/analytics/retention"
  },
  "getPlatformMetrics": {
    "method": "GET",
    "path": "/api/platform/v1/admin/system/metrics"
  },
  "getPurchaseAgreement": {
    "method": "GET",
    "path": "/api/platform/v1/commerce/prices/{priceId}/purchase-agreement"
  },
  "getTelemetryAnalytics": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/kpi-summary/telemetry"
  },
  "getUser": {
    "method": "GET",
    "path": "/api/platform/v1/admin/users/{userId}"
  },
  "grantCurrentUserTestEntitlement": {
    "method": "POST",
    "path": "/api/platform/v1/applications/{applicationId}/entitlements/test-grant"
  },
  "grantEntitlement": {
    "method": "POST",
    "path": "/api/platform/v1/admin/applications/{applicationId}/entitlement-grants"
  },
  "grantOwnerConsoleEntitlement": {
    "method": "POST",
    "path": "/api/platform/v1/console/grants"
  },
  "grantUserPlatformRole": {
    "method": "PUT",
    "path": "/api/platform/v1/admin/users/{userId}/platform-roles/{platformRoleCode}"
  },
  "ingestAnonymousClientTelemetry": {
    "method": "POST",
    "path": "/api/platform/v1/telemetry/anonymous/events"
  },
  "ingestClientTelemetry": {
    "method": "POST",
    "path": "/api/platform/v1/telemetry/events"
  },
  "listAdminCommerceOrders": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/orders"
  },
  "listAdminCommercePaymentAttempts": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/payment-attempts"
  },
  "listAdminCommerceRefunds": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/refunds"
  },
  "listAdminCommerceSubscriptions": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/subscriptions"
  },
  "listAdminIncidents": {
    "method": "GET",
    "path": "/api/platform/v1/admin/incidents"
  },
  "listAdminProviderNotifications": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/provider-notifications"
  },
  "listApplicationManagementAdministrators": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/administrators"
  },
  "listApplicationManagementOrders": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/orders"
  },
  "listApplicationManagementUsers": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/users"
  },
  "listApplicationMembers": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/members"
  },
  "listApplicationPermissions": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/permissions"
  },
  "listApplicationPlans": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/plans"
  },
  "listApplicationProducts": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/products"
  },
  "listApplicationRoles": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/roles"
  },
  "listApplications": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications"
  },
  "listAuditEvents": {
    "method": "GET",
    "path": "/api/platform/v1/admin/audit-events"
  },
  "listAuthenticationDiagnostics": {
    "method": "GET",
    "path": "/api/platform/v1/admin/authentication-diagnostics"
  },
  "listCommerceAnomalies": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/anomalies"
  },
  "listControlledOperations": {
    "method": "GET",
    "path": "/api/platform/v1/admin/operations/catalog"
  },
  "listCurrentUserApplications": {
    "method": "GET",
    "path": "/api/platform/v1/users/me/applications"
  },
  "listCurrentUserCommerceOrders": {
    "method": "GET",
    "path": "/api/platform/v1/commerce/orders"
  },
  "listCurrentUserConsents": {
    "method": "GET",
    "path": "/api/platform/v1/users/me/consents"
  },
  "listCurrentUserDataRequests": {
    "method": "GET",
    "path": "/api/platform/v1/users/me/data-requests"
  },
  "listCurrentUserDevices": {
    "method": "GET",
    "path": "/api/platform/v1/users/me/devices"
  },
  "listCurrentUserEntitlements": {
    "method": "GET",
    "path": "/api/platform/v1/applications/{applicationId}/entitlements/me"
  },
  "listCurrentUserNotifications": {
    "method": "GET",
    "path": "/api/platform/v1/users/me/notifications"
  },
  "listMatrixProjectOverviews": {
    "method": "GET",
    "path": "/api/platform/v1/admin/matrix/projects"
  },
  "listOAuthClients": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/clients"
  },
  "listOwnerApplicationAdministratorCandidates": {
    "method": "GET",
    "path": "/api/platform/v1/console/administrator-candidates"
  },
  "listOwnerApplicationAdministrators": {
    "method": "GET",
    "path": "/api/platform/v1/console/application-administrators"
  },
  "listOwnerConsoleAdministrators": {
    "method": "GET",
    "path": "/api/platform/v1/console/administrators"
  },
  "listOwnerConsoleOrders": {
    "method": "GET",
    "path": "/api/platform/v1/console/orders"
  },
  "listOwnerConsoleUsers": {
    "method": "GET",
    "path": "/api/platform/v1/console/users"
  },
  "listProviderProductBindings": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/provider-bindings"
  },
  "listProviderRegistrations": {
    "method": "GET",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/provider-registrations"
  },
  "listPurchasablePrices": {
    "method": "GET",
    "path": "/api/platform/v1/commerce/plans/{planId}/prices"
  },
  "listServiceStatuses": {
    "method": "GET",
    "path": "/api/platform/v1/admin/system/services"
  },
  "listUserDataRequests": {
    "method": "GET",
    "path": "/api/platform/v1/admin/users/{userId}/data-requests"
  },
  "listUserDevices": {
    "method": "GET",
    "path": "/api/platform/v1/admin/users/{userId}/devices"
  },
  "listUserMemberships": {
    "method": "GET",
    "path": "/api/platform/v1/admin/users/{userId}/memberships"
  },
  "listUserPlatformRoles": {
    "method": "GET",
    "path": "/api/platform/v1/admin/users/{userId}/platform-roles"
  },
  "listUsers": {
    "method": "GET",
    "path": "/api/platform/v1/admin/users"
  },
  "listUserSessions": {
    "method": "GET",
    "path": "/api/platform/v1/admin/users/{userId}/sessions"
  },
  "login": {
    "method": "POST",
    "path": "/api/platform/v1/auth/login"
  },
  "loginOwnerConsole": {
    "method": "POST",
    "path": "/api/platform/v1/console/auth/login"
  },
  "loginWithAlipayMiniProgram": {
    "method": "POST",
    "path": "/api/platform/v1/auth/alipay/login"
  },
  "loginWithAppleIdentityToken": {
    "method": "POST",
    "path": "/api/platform/v1/auth/federated/apple/login"
  },
  "loginWithDouyinMiniProgram": {
    "method": "POST",
    "path": "/api/platform/v1/auth/douyin/login"
  },
  "loginWithFirebaseIdToken": {
    "method": "POST",
    "path": "/api/platform/v1/auth/federated/firebase/login"
  },
  "loginWithWechat": {
    "method": "POST",
    "path": "/api/platform/v1/auth/wechat/login"
  },
  "logout": {
    "method": "POST",
    "path": "/api/platform/v1/auth/logout"
  },
  "logoutOwnerConsole": {
    "method": "POST",
    "path": "/api/platform/v1/console/auth/logout"
  },
  "provisionApplicationPackageCatalog": {
    "method": "PUT",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/catalog/packages/{packageId}"
  },
  "provisionOwnerApplicationAdministrator": {
    "method": "POST",
    "path": "/api/platform/v1/console/application-administrators"
  },
  "publishPurchaseAgreement": {
    "method": "POST",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/purchase-agreements"
  },
  "readApplicationServiceRefund": {
    "method": "GET",
    "path": "/api/platform/v1/service/applications/{applicationId}/commerce/orders/{orderId}/refund"
  },
  "receiveCommerceProviderNotification": {
    "method": "POST",
    "path": "/api/platform/v1/commerce/applications/{applicationId}/providers/{provider}/notifications"
  },
  "reconcileCommercePayment": {
    "method": "POST",
    "path": "/api/platform/v1/commerce/payments/{attemptId}/reconcile"
  },
  "refreshOwnerConsole": {
    "method": "POST",
    "path": "/api/platform/v1/console/auth/refresh"
  },
  "refreshToken": {
    "method": "POST",
    "path": "/api/platform/v1/auth/refresh"
  },
  "refulfillCommerceEntitlement": {
    "method": "POST",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/orders/{orderId}/refulfill"
  },
  "registerIdentity": {
    "method": "POST",
    "path": "/api/platform/v1/auth/register"
  },
  "registerNotificationSubscription": {
    "method": "POST",
    "path": "/api/platform/v1/users/me/notification-subscriptions"
  },
  "removeNotificationSubscription": {
    "method": "DELETE",
    "path": "/api/platform/v1/users/me/notification-subscriptions/{id}"
  },
  "removeOwnerApplicationAdministrator": {
    "method": "DELETE",
    "path": "/api/platform/v1/console/applications/{applicationId}/administrators/{userId}"
  },
  "replaceApplicationMemberRoles": {
    "method": "PUT",
    "path": "/api/platform/v1/admin/applications/{applicationId}/members/{userId}/roles"
  },
  "replayProviderNotification": {
    "method": "POST",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/provider-notifications/{provider}/{eventId}/replay"
  },
  "requestApplicationServiceRefund": {
    "method": "POST",
    "path": "/api/platform/v1/service/applications/{applicationId}/commerce/orders/{orderId}/refund"
  },
  "requestCommerceRefund": {
    "method": "POST",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/orders/{orderId}/refund"
  },
  "requestCurrentUserData": {
    "method": "POST",
    "path": "/api/platform/v1/users/me/data-requests"
  },
  "requestEmailVerification": {
    "method": "POST",
    "path": "/api/platform/v1/users/me/email-verification"
  },
  "requestPasswordRecovery": {
    "method": "POST",
    "path": "/api/platform/v1/auth/password-recovery"
  },
  "requestRegistrationEmailVerification": {
    "method": "POST",
    "path": "/api/platform/v1/auth/registration-email-verification"
  },
  "resetPassword": {
    "method": "POST",
    "path": "/api/platform/v1/auth/password-reset"
  },
  "restoreAppleCommercePurchase": {
    "method": "POST",
    "path": "/api/platform/v1/commerce/providers/apple-app-store/restore"
  },
  "retirePatentCasePurchase": {
    "method": "POST",
    "path": "/api/platform/v1/commerce/orders/{id}/retire-case-purchase"
  },
  "retirePatentCasePurchaseIntent": {
    "method": "POST",
    "path": "/api/platform/v1/commerce/orders/retire-case-intent"
  },
  "revokeCurrentUserDevice": {
    "method": "POST",
    "path": "/api/platform/v1/users/me/devices/{deviceId}/revoke"
  },
  "revokeEntitlementGrant": {
    "method": "POST",
    "path": "/api/platform/v1/admin/applications/{applicationId}/entitlement-grants/{grantId}/revoke"
  },
  "revokeOAuthClient": {
    "method": "POST",
    "path": "/api/platform/v1/admin/applications/{applicationId}/clients/{oauthClientId}/revoke"
  },
  "revokeUserPlatformRole": {
    "method": "POST",
    "path": "/api/platform/v1/admin/users/{userId}/platform-roles/{platformRoleCode}/revoke"
  },
  "rotateOAuthClientSecret": {
    "method": "POST",
    "path": "/api/platform/v1/admin/applications/{applicationId}/clients/{oauthClientId}/rotate-secret"
  },
  "saveProviderProductBinding": {
    "method": "POST",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/provider-bindings"
  },
  "saveProviderRegistration": {
    "method": "POST",
    "path": "/api/platform/v1/admin/applications/{applicationId}/commerce/provider-registrations"
  },
  "scanQrLoginChallenge": {
    "method": "POST",
    "path": "/api/platform/v1/auth/qr/challenges/scan"
  },
  "startCommercePayment": {
    "method": "POST",
    "path": "/api/platform/v1/commerce/payments"
  },
  "startControlledOperation": {
    "method": "POST",
    "path": "/api/platform/v1/admin/operations/tasks"
  },
  "stepUpAuthentication": {
    "method": "POST",
    "path": "/api/platform/v1/auth/step-up"
  },
  "submitControlledOperationTechnicalReview": {
    "method": "POST",
    "path": "/api/platform/v1/admin/operations/approvals/technical-review"
  },
  "submitControlledOperationUserApproval": {
    "method": "POST",
    "path": "/api/platform/v1/admin/operations/approvals/{confirmationId}/user-approval"
  },
  "submitUserFeedback": {
    "method": "POST",
    "path": "/api/platform/v1/feedback"
  },
  "updateApplicationManagementCatalog": {
    "method": "POST",
    "path": "/api/platform/v1/admin/applications/{applicationId}/management/catalog"
  },
  "updateApplicationRole": {
    "method": "PATCH",
    "path": "/api/platform/v1/admin/applications/{applicationId}/roles/{roleCode}"
  },
  "updateCurrentUserProfile": {
    "method": "PATCH",
    "path": "/api/platform/v1/users/me"
  },
  "verifyCommercePurchase": {
    "method": "POST",
    "path": "/api/platform/v1/commerce/payments/{attemptId}/verify"
  }
});
