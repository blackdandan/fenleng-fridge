import { MemoryStorageAdapter } from './storage.js';

export const SDK_VERSION = '0.5.0';
export const SUPPORTED_PLATFORM_API = Object.freeze({ minimum: '1.0.0', maximum: '1.0.0' });

export class FenlengSdkError extends Error {
  constructor(code, message, { status = 0, requestId = null, retryable = false, cause } = {}) {
    super(message, { cause });
    this.name = 'FenlengSdkError';
    this.code = code;
    this.status = status;
    this.requestId = requestId;
    this.retryable = retryable;
  }
}

export class IncompatiblePlatformError extends FenlengSdkError {
  constructor(version) { super('INCOMPATIBLE_PLATFORM_API', `Platform API ${version} is not supported by SDK ${SDK_VERSION}`); }
}

export class FenlengBaseClient {
  constructor(options = {}) {
    if (!options.baseUrl) throw new FenlengSdkError('CONFIGURATION_INVALID', 'baseUrl is required');
    const url = new URL(options.baseUrl);
    if (url.protocol !== 'https:' && url.hostname !== 'localhost' && url.hostname !== '127.0.0.1') {
      throw new FenlengSdkError('INSECURE_TRANSPORT', 'HTTPS is required outside localhost');
    }
    this.baseUrl = url.toString().replace(/\/$/, '');
    this.apiVersion = options.apiVersion || '1.0.0';
    assertCompatible(this.apiVersion);
    this.storage = options.storage || new MemoryStorageAdapter();
    this.tokenKey = options.tokenKey || 'fl_session_token';
    this.fetch = options.fetch ?? globalThis.fetch?.bind(globalThis);
    if (typeof this.fetch !== 'function') throw new FenlengSdkError('FETCH_UNAVAILABLE', 'A fetch implementation is required');
    this.timeoutMs = bounded(options.timeoutMs ?? 10_000, 100, 60_000, 'timeoutMs');
    this.maxRetries = bounded(options.maxRetries ?? 2, 0, 3, 'maxRetries');
    this.logger = options.logger || (() => {});
    this.authMode = options.authMode || 'bearer';
    if (!['bearer', 'cookie', 'anonymous'].includes(this.authMode)) throw new FenlengSdkError('CONFIGURATION_INVALID', 'authMode must be bearer, cookie or anonymous');
    this.csrfTokenProvider = options.csrfTokenProvider || null;
  }

  async getHeaders(idempotencyKey = null, traceId = null) {
    const headers = { 'Content-Type': 'application/json', 'X-Fenleng-API-Version': this.apiVersion, 'X-Fenleng-SDK-Version': SDK_VERSION };
    const token = this.authMode === 'bearer' ? await this.storage.getItem(this.tokenKey) : null;
    if (token) headers.Authorization = `Bearer ${token}`;
    if (idempotencyKey) headers['Idempotency-Key'] = idempotencyKey;
    if (traceId) headers.traceparent = traceId;
    return headers;
  }

  async request(endpoint, method = 'GET', body = null, options = {}) {
    if (!endpoint.startsWith('/')) throw new FenlengSdkError('ENDPOINT_INVALID', 'endpoint must be an absolute API path');
    if (this.authMode === 'anonymous' && (
      (options.credentials != null && options.credentials !== 'omit') ||
      Object.keys(options.headers || {}).some(key => /^(authorization|cookie|x-csrf-token)$/i.test(key))
    )) throw new FenlengSdkError('CONFIGURATION_INVALID', 'Anonymous requests cannot carry account credentials');
    const upperMethod = method.toUpperCase();
    const csrfToken = this.authMode === 'cookie' && !['GET','HEAD','OPTIONS'].includes(upperMethod) ? await this.csrfTokenProvider?.() : null;
    if (this.authMode === 'cookie' && !['GET','HEAD','OPTIONS'].includes(upperMethod) && !csrfToken) throw new FenlengSdkError('CSRF_TOKEN_REQUIRED', 'Cookie-mode writes require a CSRF token');
    const retryableMethod = upperMethod === 'GET' || upperMethod === 'HEAD' || Boolean(options.idempotencyKey);
    const attempts = retryableMethod ? this.maxRetries + 1 : 1;
    for (let attempt = 0; attempt < attempts; attempt += 1) {
      const timeout = AbortSignal.timeout(options.timeoutMs ?? this.timeoutMs);
      const signal = options.signal ? AbortSignal.any([options.signal, timeout]) : timeout;
      try {
        const response = await this.fetch(`${this.baseUrl}${endpoint}`, {
          method: upperMethod,
          headers: { ...(await this.getHeaders(options.idempotencyKey, options.traceId)), ...(csrfToken?{'X-CSRF-Token':csrfToken}:{}), ...(options.headers || {}) },
          body: body == null ? undefined : JSON.stringify(body),
          signal,
          credentials: this.authMode === 'anonymous' ? 'omit' : options.credentials ?? (this.authMode === 'cookie' ? 'include' : undefined),
        });
        if (response.ok) return response.status === 204 ? null : await response.json();
        const envelope = await safeJson(response);
        const retryable = response.status === 429 || response.status === 502 || response.status === 503 || response.status === 504;
        if (retryable && attempt + 1 < attempts) { await delay(backoff(attempt), options.signal); continue; }
        throw new FenlengSdkError(envelope?.code || `HTTP_${response.status}`, envelope?.message || 'Platform request failed', {
          status: response.status, requestId: envelope?.requestId || response.headers.get('x-request-id'), retryable,
        });
      } catch (error) {
        if (error instanceof FenlengSdkError) throw error;
        const cancelled = options.signal?.aborted;
        const mapped = new FenlengSdkError(cancelled ? 'REQUEST_CANCELLED' : signal.aborted ? 'REQUEST_TIMEOUT' : 'NETWORK_ERROR', cancelled ? 'Request cancelled' : signal.aborted ? 'Request timed out' : 'Network request failed', { retryable: !cancelled, cause: error });
        if (mapped.retryable && attempt + 1 < attempts) { await delay(backoff(attempt), options.signal); continue; }
        throw mapped;
      } finally {
        this.logger({ event: 'sdk.request', method: upperMethod, endpoint, attempt: attempt + 1 });
      }
    }
    throw new FenlengSdkError('INTERNAL_ERROR', 'Request loop ended unexpectedly');
  }
}

export function redact(value) {
  if (Array.isArray(value)) return value.map(redact);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, /token|secret|password|authorization|credential|receipt/i.test(key) ? '[REDACTED]' : redact(item)]));
}

export function assertCompatible(version) {
  if (version !== SUPPORTED_PLATFORM_API.minimum || version !== SUPPORTED_PLATFORM_API.maximum) throw new IncompatiblePlatformError(version);
}
function bounded(value, minimum, maximum, name) { if (!Number.isInteger(value) || value < minimum || value > maximum) throw new FenlengSdkError('CONFIGURATION_INVALID', `${name} must be between ${minimum} and ${maximum}`); return value; }
async function safeJson(response) { try { return await response.json(); } catch { return null; } }
function backoff(attempt) { return Math.min(100 * (2 ** attempt), 1000); }
function delay(ms, signal) { return new Promise((resolve, reject) => { const timer = setTimeout(resolve, ms); signal?.addEventListener('abort', () => { clearTimeout(timer); reject(signal.reason); }, { once: true }); }); }
