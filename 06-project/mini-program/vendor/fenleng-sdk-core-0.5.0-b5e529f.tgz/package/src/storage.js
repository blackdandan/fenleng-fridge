/**
 * Fenleng Storage Adapter Specification
 */
export class StorageAdapter {
  async getItem(key) {
    throw new Error('StorageAdapter.getItem() must be implemented');
  }
  async setItem(key, value) {
    throw new Error('StorageAdapter.setItem() must be implemented');
  }
  async removeItem(key) {
    throw new Error('StorageAdapter.removeItem() must be implemented');
  }
}

export class MemoryStorageAdapter extends StorageAdapter {
  constructor() {
    super();
    this.store = new Map();
  }
  async getItem(key) {
    return this.store.get(key) || null;
  }
  async setItem(key, value) {
    this.store.set(key, value);
  }
  async removeItem(key) {
    this.store.delete(key);
  }
}
