import { FenlengSdkError } from './client.js';
export class FenlengSSEClient {
  constructor(client) { this.client=client; this.controller=null; }
  async connectStream(endpoint,payload,onEvent,{signal}={}) {
    this.controller=new AbortController(); const combined=signal?AbortSignal.any([signal,this.controller.signal]):this.controller.signal;
    const response=await this.client.fetch(`${this.client.baseUrl}${endpoint}`,{method:'POST',headers:{...(await this.client.getHeaders()),accept:'text/event-stream'},body:JSON.stringify(payload),signal:combined});
    if(!response.ok||!response.body)throw new FenlengSdkError(`HTTP_${response.status}`,'Stream connection failed',{status:response.status,retryable:response.status>=500});
    const reader=response.body.getReader(),decoder=new TextDecoder(); let buffer='';
    while(true){const {done,value}=await reader.read(); if(done)break; buffer+=decoder.decode(value,{stream:true}); let boundary; while((boundary=buffer.indexOf('\n\n'))>=0){const block=buffer.slice(0,boundary); buffer=buffer.slice(boundary+2); const data=block.split('\n').filter(line=>line.startsWith('data:')).map(line=>line.slice(5).trim()).join('\n'); if(data)onEvent?.(JSON.parse(data));}}
    return {status:'completed'};
  }
  cancelStream(){if(!this.controller)return false;this.controller.abort();this.controller=null;return true;}
}
