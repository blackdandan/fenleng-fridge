import { FenlengSdkError } from './client.js';

const SENSITIVE_KEY = /token|secret|password|authorization|credential|receipt|verification.?code|email/i;
const PLATFORMS = new Set(['ios', 'android', 'ohos', 'web', 'mini-program']);
const CHANNELS = new Set(['china', 'global', 'internal']);

export class FenlengTelemetryLogger {
  constructor(client, { catalog = [], consent = () => false, context, maxQueueSize = 100, batchSize = 50, deliveryIdFactory } = {}) {
    if (typeof context !== 'function') throw new FenlengSdkError('CONFIGURATION_INVALID', 'telemetry context provider is required');
    if (deliveryIdFactory !== undefined && typeof deliveryIdFactory !== 'function') throw new FenlengSdkError('CONFIGURATION_INVALID', 'deliveryIdFactory must be a function');
    this.deliveryIdFactory = deliveryIdFactory;
    this.client = client;
    this.catalog = new Set(catalog);
    this.consent = consent;
    this.context = context;
    this.maxQueueSize = bounded(maxQueueSize, 1, 1000, 'maxQueueSize');
    this.batchSize = bounded(batchSize, 1, 50, 'batchSize');
    this.events = [];
    this.deliveryIds = new WeakMap();
    this.consentGeneration = 0;
    this.flushing = null;
    this.pendingBatch = null;
  }
  track(eventName, properties = {}, options = {}) {
    if (!this.consent()) return null;
    if (!this.catalog.has(eventName)) throw new FenlengSdkError('TELEMETRY_EVENT_UNREGISTERED', `Event ${eventName} is not registered`);
    const snapshot = cloneJson(properties);
    if (!snapshot || Array.isArray(snapshot) || typeof snapshot !== 'object') throw invalidProperties();
    rejectSensitive(snapshot);
    const timestamp = options.timestamp ?? new Date().toISOString();
    if (typeof timestamp !== 'string' || !Number.isFinite(Date.parse(timestamp))) throw new FenlengSdkError('TELEMETRY_TIME_INVALID', 'timestamp must be an ISO timestamp');
    const event = { event: eventName, timestamp: new Date(timestamp).toISOString(), properties: snapshot, context: validateContext(this.context()) };
    let delivery;
    if (this.deliveryIdFactory) {
      delivery = this.deliveryIdFactory();
      if (!delivery || typeof delivery.then !== 'function') event.deliveryId = validateDeliveryId(delivery);
    }
    if (this.events.length >= this.maxQueueSize) this.events.shift();
    this.events.push(event);
    if (delivery && typeof delivery.then === 'function') {
      const ready = Promise.resolve(delivery).then(id => {
        event.deliveryId = validateDeliveryId(id);
        return cloneJson(event);
      }).catch(error => { this.events = this.events.filter(item => item !== event); throw error; });
      this.deliveryIds.set(event, ready);
      // Tracking is optional; callers may ignore its receipt, while flush still observes failure.
      ready.catch(() => {});
      return ready;
    }
    return cloneJson(event);
  }
  get pendingCount() { return this.events.length; }
  withdrawConsent() { this.consentGeneration++; this.events.length = 0; this.pendingBatch = null; }
  flush(options = {}) {
    if (this.flushing) return this.flushing;
    if (!this.consent() || (!this.pendingBatch && this.events.length === 0)) return Promise.resolve(0);
    const generation = this.consentGeneration;
    const pinBatch = !this.deliveryIdFactory || options.idempotencyKey !== undefined;
    const pending = pinBatch ? (this.pendingBatch ||= {events:this.events.slice(0, this.batchSize),key:options.idempotencyKey}) : {events:this.events.slice(0, this.batchSize),key:undefined};
    const batch = pending.events;
    const accepted = new Set(batch);
    this.flushing = (async () => {
      const pendingIds = batch.map(event => this.deliveryIds.get(event)).filter(Boolean);
      if (pendingIds.length) await Promise.all(pendingIds);
      if (generation !== this.consentGeneration || !this.consent()) return 0;
      const response = await this.client.request('/api/platform/v1/telemetry/events', 'POST', { events: batch }, { ...options, idempotencyKey: pending.key });
      if (generation !== this.consentGeneration) return 0;
      if (!Number.isInteger(response?.accepted) || response.accepted !== batch.length) throw new FenlengSdkError('TELEMETRY_RESPONSE_INVALID','Telemetry receipt was not confirmed');
      // Overflow may have evicted in-flight entries. Remove only acknowledged objects.
      this.events = this.events.filter(event => !accepted.has(event));
      this.pendingBatch = null;
      return batch.length;
    })().finally(() => { this.flushing = null; });
    return this.flushing;
  }
}

function rejectSensitive(value) {
  if (Array.isArray(value)) return value.forEach(rejectSensitive);
  if (!value || typeof value !== 'object') return;
  for (const [key, item] of Object.entries(value)) {
    if (SENSITIVE_KEY.test(key)) throw new FenlengSdkError('TELEMETRY_SENSITIVE_FIELD_REJECTED', `Sensitive telemetry property ${key} is not allowed`);
    rejectSensitive(item);
  }
}
function validateContext(value = {}) {
  if (!PLATFORMS.has(value.platform) || !CHANNELS.has(value.releaseChannel)) throw new FenlengSdkError('TELEMETRY_CONTEXT_INVALID', 'platform or releaseChannel is invalid');
  for (const key of ['appVersion', 'buildNumber', 'locale']) if (typeof value[key] !== 'string' || value[key].length < 1 || value[key].length > 32) throw new FenlengSdkError('TELEMETRY_CONTEXT_INVALID', `${key} is required`);
  if (value.locale.length < 2 || value.locale.length > 16) throw new FenlengSdkError('TELEMETRY_CONTEXT_INVALID','locale is invalid');
  return { platform: value.platform, appVersion: value.appVersion, buildNumber: value.buildNumber, releaseChannel: value.releaseChannel, locale: value.locale, ...(value.sessionId ? { sessionId: value.sessionId } : {}) };
}
function bounded(value, minimum, maximum, name) { if (!Number.isInteger(value) || value < minimum || value > maximum) throw new FenlengSdkError('CONFIGURATION_INVALID', `${name} must be between ${minimum} and ${maximum}`); return value; }

function validateDeliveryId(value) {
  if (typeof value !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(value)) throw new FenlengSdkError('CONFIGURATION_INVALID', 'deliveryIdFactory must return a canonical UUID');
  return value;
}

function invalidProperties(){return new FenlengSdkError('TELEMETRY_PROPERTIES_INVALID','Telemetry properties must be JSON values');}
// WeChat JS hosts need not provide structuredClone. Reject unsupported values
// rather than silently dropping fields or retaining caller-owned objects.
function cloneJson(value, seen = new Set(), depth = 0) {
  if (depth > 16) throw invalidProperties();
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value !== 'object' || seen.has(value)) throw invalidProperties();
  if (!Array.isArray(value) && ![Object.prototype,null].includes(Object.getPrototypeOf(value))) throw invalidProperties();
  seen.add(value);
  const result = Array.isArray(value) ? value.map(item=>cloneJson(item,seen,depth+1)) :
    Object.fromEntries(Object.entries(value).map(([key,item])=>[key,cloneJson(item,seen,depth+1)]));
  seen.delete(value);return result;
}
