import assert from 'node:assert/strict';
import test from 'node:test';
import { MemoryStorageAdapter, FenlengBaseClient, FenlengTelemetryLogger, resolveFenlengAuthConfig } from '../index.js';

test('MemoryStorageAdapter manages session keys correctly', async () => {
  const storage = new MemoryStorageAdapter();
  await storage.setItem('token', 'abc-123');
  assert.equal(await storage.getItem('token'), 'abc-123');
  await storage.removeItem('token');
  assert.equal(await storage.getItem('token'), null);
});

test('FenlengBaseClient injects compatible versions and idempotency header', async () => {
  const client = new FenlengBaseClient({ baseUrl: 'http://localhost:8080', apiVersion: '1.0.0', fetch: async () => {} });
  const headers = await client.getHeaders('idempotent-nonce-99');
  assert.equal(headers['X-Fenleng-API-Version'], '1.0.0');
  assert.equal(headers['Idempotency-Key'], 'idempotent-nonce-99');
});

test('client fails closed on incompatible API and insecure transport', () => {
  assert.throws(() => new FenlengBaseClient({baseUrl: 'http://example.com'}), /HTTPS/);
  assert.throws(() => new FenlengBaseClient({baseUrl: 'https://example.com', apiVersion: '2.0.0'}), /not supported/);
});

test('client parses stable errors and never returns mock success', async () => {
  const client = new FenlengBaseClient({baseUrl: 'http://localhost:8080', maxRetries: 0, fetch: async () => new Response(JSON.stringify({code: 'PERMISSION_DENIED', message: 'denied', requestId: 'req-1'}), {status: 403, headers: {'content-type': 'application/json'}})});
  await assert.rejects(() => client.request('/api/platform/v1/users/me'), error => error.code === 'PERMISSION_DENIED' && error.requestId === 'req-1');
});
test('default browser fetch keeps the global receiver', async () => {
  const originalFetch = globalThis.fetch;
  let requestedUrl;
  globalThis.fetch = function receiverSensitiveFetch(url) {
    assert.equal(this, globalThis);
    requestedUrl = url;
    return Promise.resolve(new Response('{}', {status: 200}));
  };
  try {
    const client = new FenlengBaseClient({baseUrl: 'http://localhost:8080'});
    await client.request('/api/platform/v1/auth/wechat/login', 'POST', {code: 'temporary-code'});
    assert.equal(requestedUrl, 'http://localhost:8080/api/platform/v1/auth/wechat/login');
  } finally {
    globalThis.fetch = originalFetch;
  }
});
test('auth config derives a stable client id from the application and target', () => {
  assert.deepEqual(resolveFenlengAuthConfig({applicationCode: 'demo-app', clientTarget: 'miniapp'}), {
    applicationCode: 'demo-app',
    clientId: 'demo-app-miniapp',
    clientTarget: 'miniapp',
    wechatAppId: null,
  });
});
test('telemetry adds controlled context, batches, and rejects sensitive fields', async () => {
  const bodies = [];
  const client = new FenlengBaseClient({baseUrl:'http://localhost',fetch:async(_,init)=>{bodies.push(JSON.parse(init.body));return new Response('{"accepted":1}',{status:200});}});
  const telemetry = new FenlengTelemetryLogger(client,{catalog:['prompt.created.v1'],consent:()=>true,context:()=>({platform:'web',appVersion:'1.0.0',buildNumber:'3',releaseChannel:'global',locale:'zh-CN'}),batchSize:1});
  telemetry.track('prompt.created.v1',{source:'editor'});
  telemetry.track('prompt.created.v1',{source:'import'});
  assert.throws(()=>telemetry.track('prompt.created.v1',{email:'private@example.com'}),error=>error.code==='TELEMETRY_SENSITIVE_FIELD_REJECTED');
  assert.equal(await telemetry.flush({idempotencyKey:'telemetry-1'}),1);
  assert.equal(telemetry.pendingCount,1);
  assert.equal(bodies[0].events[0].context.platform,'web');
});
test('cookie mode sends credentials and CSRF without Authorization',async()=>{let seen;const client=new FenlengBaseClient({baseUrl:'http://localhost',authMode:'cookie',csrfTokenProvider:async()=>'csrf-1',fetch:async(_,init)=>{seen=init;return new Response('{}',{status:200});}});await client.storage.setItem(client.tokenKey,'must-not-leak');await client.request('/api/platform/v1/users/me/consents','PUT',{});assert.equal(seen.credentials,'include');assert.equal(seen.headers.Authorization,undefined);assert.equal(seen.headers['X-CSRF-Token'],'csrf-1');});
