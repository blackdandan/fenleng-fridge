import test from 'node:test';
import assert from 'node:assert/strict';
import {FenlengTelemetryLogger} from '../src/telemetry.js';
test('lazy consumers can preserve occurrence time without changing the payload contract',async()=>{
 const requests=[];
 const logger=new FenlengTelemetryLogger({request:async(...args)=>{requests.push(args);return {accepted:args[2].events.length};}},{catalog:['custom.clicked.v1'],consent:()=>true,context:()=>({platform:'web',appVersion:'1',buildNumber:'1',releaseChannel:'china',locale:'zh-CN'})});
 logger.track('custom.clicked.v1',{}, {timestamp:'2026-11-09T01:00:00Z'});await logger.flush();
 assert.equal(requests[0][2].events[0].timestamp,'2026-11-09T01:00:00.000Z');
 assert.throws(()=>logger.track('custom.clicked.v1',{}, {timestamp:'invalid'}),error=>error.code==='TELEMETRY_TIME_INVALID');
 assert.equal(logger.pendingCount,0);
});
