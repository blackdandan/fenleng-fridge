import {FenlengSdkError} from '@fenleng/sdk-core';
/** Native WeChat URL is encoded as a QR image; it must never be treated as an H5 navigation target. */
export function readWechatNativeQr(session){
 const payload=session?.clientPayload;
 if(session?.redirectUrl!==null || payload?.presentation!=='NATIVE_QR' || typeof payload.codeUrl!=='string' || payload.codeUrl.length>2048 || typeof payload.expiresAt!=='string' || !Number.isFinite(Date.parse(payload.expiresAt)))throw new FenlengSdkError('PAYMENT_SESSION_INVALID','Invalid Native QR session');
 let url;try{url=new URL(payload.codeUrl);}catch{throw new FenlengSdkError('PAYMENT_SESSION_INVALID','Invalid Native QR URL');}
 if(url.protocol!=='weixin:' || url.hostname!=='wxpay' || url.pathname!=='/bizpayurl' || url.username || url.password || url.hash || !url.searchParams.get('pr'))throw new FenlengSdkError('PAYMENT_SESSION_INVALID','Invalid Native QR URL');
 return {codeUrl:payload.codeUrl,expiresAt:payload.expiresAt};
}
