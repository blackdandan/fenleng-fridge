/** Application-scoped management facade. Never accepts Owner Console credentials. */
export class ApplicationManagementSDK {
  constructor(client, { applicationId, refreshSession } = {}) {
    if (!client || !applicationId) throw new Error('client and applicationId are required');
    this.client = client;
    this.refreshSession = refreshSession;
    this.root = `/api/platform/v1/admin/applications/${encodeURIComponent(applicationId)}/management`;
  }
  async request(path, method, body, options) {
    try { return await this.client.request(path, method, body, options); }
    catch (error) { if (error.status !== 401 || !this.refreshSession) throw error; await this.refreshSession(); return this.client.request(path, method, body, options); }
  }
  read(resource, query = {}, options = {}) {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(query)) if (value !== undefined && value !== null && value !== '') params.set(key, String(value));
    return this.request(`${this.root}/${resource}${params.size ? `?${params}` : ''}`, 'GET', null, options);
  }
  context(options) { return this.read('context', {}, options); }
  capabilities(options) { return this.read('capabilities', {}, options); }
  overview(options) { return this.read('overview', {}, options); }
  users(query, options) { return this.read('users', query, options); }
  user(userId, options) { return this.read(`users/${encodeURIComponent(userId)}`, {}, options); }
  orders(query, options) { return this.read('orders', query, options); }
  order(orderId, options) { return this.read(`orders/${encodeURIComponent(orderId)}`, {}, options); }
  catalog(options) { return this.read('catalog', {}, options); }
  packageCatalog(packageId, options) { return this.read(`catalog/packages/${encodeURIComponent(packageId)}`, {}, options); }
  provisionPackageCatalog(packageId, input, { idempotencyKey, ...options } = {}) {
    if (!idempotencyKey) throw new Error('idempotencyKey is required');
    return this.request(`${this.root}/catalog/packages/${encodeURIComponent(packageId)}`, 'PUT', input, { ...options, idempotencyKey });
  }
  analytics(query, options) { return this.read('analytics', query, options); }
  activityAnalytics(query, options) { return this.read('analytics/activity', query, options); }
  retentionAnalytics(query, options) { return this.read('analytics/retention', query, options); }
  analyticsFacts(query, options) { return this.read('analytics/facts', query, options); }
  funnelAnalytics(definitionId, query, options) { return this.read(`analytics/funnels/${encodeURIComponent(definitionId)}`, query, options); }
  administrators(query, options) { return this.read('administrators', query, options); }
  stepUp(password, options = {}) { return this.client.request('/api/platform/v1/auth/step-up', 'POST', { password }, options); }
  updateCatalog(input, { idempotencyKey, ...options } = {}) {
    if (!idempotencyKey) throw new Error('idempotencyKey is required');
    return this.request(`${this.root}/catalog`, 'POST', input, { ...options, idempotencyKey });
  }
}
