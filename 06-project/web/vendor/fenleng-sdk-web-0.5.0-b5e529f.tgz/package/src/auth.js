import { FenlengSdkError, resolveFenlengAuthConfig } from '@fenleng/sdk-core';
import { WebSessionStorageAdapter } from './storage.js';

const WECHAT_QR_AUTHORIZE_ENDPOINT = 'https://open.weixin.qq.com/connect/qrconnect';
const WECHAT_STATE_PATTERN = /^[A-Za-z0-9_-]{43}$/;

export class AuthSDK {
  constructor(client, { applicationCode, clientId = null, clientTarget = 'web', wechatAppId = null, oauthStateStorage = new WebSessionStorageAdapter() } = {}) {
    if (!client) throw new FenlengSdkError('CONFIGURATION_INVALID', 'AuthSDK requires a configured client');
    const identity = resolveFenlengAuthConfig({applicationCode, clientId, clientTarget, wechatAppId}, 'web');
    if (!oauthStateStorage || typeof oauthStateStorage.getItem !== 'function' || typeof oauthStateStorage.setItem !== 'function' || typeof oauthStateStorage.removeItem !== 'function') throw new FenlengSdkError('CONFIGURATION_INVALID', 'oauthStateStorage must implement the storage adapter contract');
    this.client = client;
    this.applicationCode = identity.applicationCode;
    this.clientId = identity.clientId;
    this.clientTarget = identity.clientTarget;
    this.wechatAppId = identity.wechatAppId;
    this.oauthStateStorage = oauthStateStorage;
    this.wechatStateKey = `${client.tokenKey}:wechat-oauth-state`;
    this.refreshKey = `${client.tokenKey}:refresh`;
    this.refreshInFlight = null;
  }
  requestRegistrationEmailVerification(email, options = {}) { return this.client.request('/api/platform/v1/auth/registration-email-verification', 'POST', {applicationCode: this.applicationCode, clientId: this.clientId, email}, options); }
  async register(input, options = {}) {
    if (!input?.verificationCode) throw new FenlengSdkError('VALIDATION_FAILED', 'verificationCode is required');
    const result = await this.client.request('/api/platform/v1/auth/register', 'POST', {...input, applicationCode: this.applicationCode, clientId: this.clientId}, options);
    await this.storeTokens(result);
    return result;
  }
  requestAccountDeletion(idempotencyKey, options = {}) { return this.client.request('/api/platform/v1/users/me/data-requests', 'POST', {type: 'DELETE'}, {...options, idempotencyKey}); }
  async loginWithPassword(email, password, {device, ...options} = {}) {
    const tokens = await this.client.request('/api/platform/v1/auth/login', 'POST', {applicationCode: this.applicationCode, clientId: this.clientId, email, password, device}, options);
    await this.storeTokens(tokens);
    return tokens;
  }
  async beginWechatLogin({ redirectUri } = {}) {
    if (!this.wechatAppId) throw new FenlengSdkError('CONFIGURATION_INVALID', 'wechatAppId is required to begin WeChat login');
    const callback = validateWechatRedirectUri(redirectUri);
    const state = createWechatState();
    await this.oauthStateStorage.setItem(this.wechatStateKey, state);
    const url = new URL(WECHAT_QR_AUTHORIZE_ENDPOINT);
    url.search = new URLSearchParams({
      appid: this.wechatAppId,
      redirect_uri: callback.toString(),
      response_type: 'code',
      scope: 'snsapi_login',
      state,
    }).toString();
    return `${url.toString()}#wechat_redirect`;
  }
  async completeWechatLogin({ code, state, device, ...options } = {}) {
    validateWechatCode(code);
    if (typeof state !== 'string' || !WECHAT_STATE_PATTERN.test(state)) throw new FenlengSdkError('WECHAT_OAUTH_STATE_INVALID', 'WeChat OAuth state is invalid');
    const expectedState = await this.oauthStateStorage.getItem(this.wechatStateKey);
    await this.oauthStateStorage.removeItem(this.wechatStateKey);
    if (!expectedState || !constantTimeEqual(state, expectedState)) throw new FenlengSdkError('WECHAT_OAUTH_STATE_MISMATCH', 'WeChat OAuth state did not match the login request');
    return this.loginWithWechatCode(code, {device, ...options});
  }
  async loginWithWechatCode(code, {device, ...options} = {}) {
    validateWechatCode(code);
    const tokens = await this.client.request('/api/platform/v1/auth/wechat/login', 'POST', {applicationCode: this.applicationCode, clientId: this.clientId, code, device}, options);
    await this.storeTokens(tokens);
    return tokens;
  }
  refresh(options = {}) {
    if (this.refreshInFlight) return this.refreshInFlight;
    this.refreshInFlight = this.performRefresh(options).finally(() => { this.refreshInFlight = null; });
    return this.refreshInFlight;
  }
  async performRefresh(options) {
    const refreshToken = await this.client.storage.getItem(this.refreshKey);
    if (!refreshToken) throw new FenlengSdkError('SESSION_MISSING', 'No refresh token is available');
    try {
      const tokens = await this.client.request('/api/platform/v1/auth/refresh', 'POST', {refreshToken}, options);
      await this.storeTokens(tokens);
      return tokens;
    } catch (error) {
      if (error.status === 401) await this.clear();
      throw error;
    }
  }
  async logout({allSessions = false, ...options} = {}) {
    const refreshToken = await this.client.storage.getItem(this.refreshKey);
    try { if (refreshToken) await this.client.request('/api/platform/v1/auth/logout', 'POST', {refreshToken, allSessions}, options); }
    finally { await this.clear(); }
  }
  async getCurrentSession() {
    const accessToken = await this.client.storage.getItem(this.client.tokenKey);
    return accessToken ? {status: 'AUTHENTICATED'} : null;
  }
  createFederatedDeletionChallenge(provider, deletionIdempotencyKey, options = {}) {
    if (!['FIREBASE', 'APPLE', 'WECHAT'].includes(provider) || typeof deletionIdempotencyKey !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9._:-]{7,127}$/.test(deletionIdempotencyKey)) throw new FenlengSdkError('VALIDATION_FAILED', 'Invalid deletion reauthentication request');
    return this.client.request('/api/platform/v1/auth/step-up/self-deletion/challenges', 'POST', {provider, deletionIdempotencyKey}, options);
  }
  confirmFederatedDeletionReauthentication(challengeId, identityToken, options = {}) {
    if (typeof challengeId !== 'string' || !/^fdc-[A-Za-z0-9._:-]+$/.test(challengeId) || challengeId.length > 128 || typeof identityToken !== 'string' || !identityToken.trim() || identityToken.length > 16384) throw new FenlengSdkError('VALIDATION_FAILED', 'Invalid deletion reauthentication proof');
    return this.client.request(`/api/platform/v1/auth/step-up/self-deletion/challenges/${encodeURIComponent(challengeId)}/confirm`, 'POST', {identityToken}, options);
  }
  dataRequests(options = {}) { return this.client.request('/api/platform/v1/users/me/data-requests', 'GET', null, options); }
  consents(options = {}) { return this.client.request('/api/platform/v1/users/me/consents', 'GET', null, options); }
  changeConsent(input, options = {}) { return this.client.request('/api/platform/v1/users/me/consents', 'PUT', input, options); }
  async storeTokens(tokens) {
    if (!tokens?.accessToken || !tokens?.refreshToken) throw new FenlengSdkError('TOKEN_RESPONSE_INVALID', 'Platform returned an invalid token response');
    await this.client.storage.setItem(this.client.tokenKey, tokens.accessToken);
    await this.client.storage.setItem(this.refreshKey, tokens.refreshToken);
  }
  async clear() { await this.client.storage.removeItem(this.client.tokenKey); await this.client.storage.removeItem(this.refreshKey); }
}

function validateWechatRedirectUri(value) {
  let url;
  try { url = new URL(value); } catch { throw new FenlengSdkError('WECHAT_REDIRECT_URI_INVALID', 'redirectUri must be an absolute HTTPS URL'); }
  if (url.protocol !== 'https:' || url.username || url.password || url.hash) throw new FenlengSdkError('WECHAT_REDIRECT_URI_INVALID', 'redirectUri must be an absolute HTTPS URL without credentials or fragment');
  return url;
}

function validateWechatCode(code) {
  if (typeof code !== 'string' || !code.trim() || code.length > 1024) throw new FenlengSdkError('VALIDATION_FAILED', 'WeChat authorization code is invalid');
}

function createWechatState() {
  const bytes = new Uint8Array(32);
  if (!globalThis.crypto?.getRandomValues) throw new FenlengSdkError('CRYPTO_UNAVAILABLE', 'Secure random values are required for WeChat OAuth state');
  globalThis.crypto.getRandomValues(bytes);
  return toBase64Url(bytes);
}

function toBase64Url(bytes) {
  if (typeof Buffer !== 'undefined') return Buffer.from(bytes).toString('base64url');
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll('+', '-').replaceAll('/', '_').replace(/=+$/, '');
}

function constantTimeEqual(actual, expected) {
  if (actual.length !== expected.length) return false;
  let difference = 0;
  for (let index = 0; index < actual.length; index += 1) difference |= actual.charCodeAt(index) ^ expected.charCodeAt(index);
  return difference === 0;
}
