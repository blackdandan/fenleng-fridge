export interface ManagementPage<T> { items: T[]; total: number; offset: number; limit: number; }
export interface ManagementQuery { q?: string; event?:string; platform?:string; status?: string; offset?: number; limit?: number; paymentClass?: 'paid'|'ordinary'; kind?: 'orders'|'subscriptions'|'refunds'; provider?: string; clientPlatform?: string; amountAboveMinor?: number; from?: string; until?: string; days?: 7|14|30; }
export interface ManagementCapability { id: string; operationId: string; permission: string; write: boolean; stepUp: boolean;additionalPermissions?:string[]; }
export interface ManagementClient { request(path:string, method?:string, body?:unknown, options?:Record<string,unknown>):Promise<any>; }
export declare class ApplicationManagementSDK {
 constructor(client:ManagementClient, config:{applicationId:string;refreshSession?:()=>Promise<unknown>});
 context(options?:Record<string,unknown>):Promise<{applicationId:string;subject:string;activeAdministrator:boolean}>;
 capabilities(options?:Record<string,unknown>):Promise<{version:string;items:ManagementCapability[]}>;
 overview(options?:Record<string,unknown>):Promise<{usersTotal:number;paidOrdersLast7Days:number;paidUsersLast7Days?:number}>;
 users(query?:ManagementQuery,options?:Record<string,unknown>):Promise<ManagementPage<Record<string,unknown>>>;
 user(userId:string,options?:Record<string,unknown>):Promise<Record<string,unknown>>;
 orders(query?:ManagementQuery,options?:Record<string,unknown>):Promise<ManagementPage<Record<string,unknown>>>;
 order(orderId:string,options?:Record<string,unknown>):Promise<Record<string,unknown>>;
 catalog(options?:Record<string,unknown>):Promise<{items:Record<string,unknown>[]}>;
 packageCatalog(packageId:string,options?:Record<string,unknown>):Promise<PackageCatalogItem>;
 provisionPackageCatalog(packageId:string,input:{sourcePriceId:string;name:string;units:number;amountMinor:number;revision?:string|null},options:{idempotencyKey:string}):Promise<PackageCatalogItem>;
 analytics(query?:ManagementQuery,options?:Record<string,unknown>):Promise<Record<string,unknown>>;
 activityAnalytics(query?:ProductAnalyticsQuery,options?:Record<string,unknown>):Promise<ProductAnalyticsResponse<ActivityAnalyticsDay>>;
 retentionAnalytics(query?:ProductAnalyticsQuery,options?:Record<string,unknown>):Promise<ProductAnalyticsResponse<RetentionAnalyticsCell>>;
 analyticsFacts(query?:Pick<ProductAnalyticsQuery,'days'>,options?:Record<string,unknown>):Promise<{events:Record<string,unknown>[];members:Record<string,unknown>[];orders:Record<string,unknown>[];truncated:boolean;asOf:string}>;
 funnelAnalytics(definitionId:string,query?:{days?:number;windowDays?:7|14},options?:Record<string,unknown>):Promise<Record<string,unknown>>;
 administrators(query?:ManagementQuery,options?:Record<string,unknown>):Promise<ManagementPage<Record<string,unknown>>>;
 stepUp(password:string,options?:Record<string,unknown>):Promise<unknown>;
 updateCatalog(input:{priceId:string;revision:string;amountMinor:number;productName:string;planStatus:'DRAFT'|'ACTIVE'|'RETIRED';active:boolean},options:{idempotencyKey:string}):Promise<Record<string,unknown>>;
}

export interface PackageCatalogItem {packageId:string;productId:string;planId:string;priceOptionId:string;name:string;units:number;amountMinor:number;currency:string;ready:boolean;providers:string[];revision:string}

export interface ProductAnalyticsQuery {days?:number;platform?:'ios'|'android'|'ohos'|'web'|'mini-program';appVersion?:string;releaseChannel?:'china'|'global'|'internal'}
export interface ProductAnalyticsResponse<T> {schemaVersion:string;timeZone:string;from:string;to:string;asOf:string;collectionStartedAt:string|null;sourceUpdatedAt:string|null;coverage:string;registrationCoverage:string;cohortScope:'application';partial:boolean;items:T[]}
export interface ActivityAnalyticsDay {day:string;registrations:number;dau:number|null;wau:number|null;mau:number|null;coverage:string}
export interface RetentionAnalyticsCell {day:string;offset:1|7|14|30;cohortSize:number;retained:number|null;rate:number|null;observedRate:number|null;maturity:'not-mature'|'unavailable'|'partial'|'partial-coverage';coverage:string}
