import {test} from 'node:test';import assert from 'node:assert/strict';
import {CommerceSDK,readWechatNativeQr} from '../index.js';
test('Native QR uses explicit presentation and does not send a browser return URL',async()=>{
 let sent;const sdk=new CommerceSDK({request:async(...args)=>{sent=args;return {};}});await sdk.startPayment('order','wechat-pay',{presentation:'NATIVE_QR',idempotencyKey:'original-order-attempt'});
 assert.equal(sent[2].presentation,'NATIVE_QR');assert.equal(sent[2].returnUrl,null);assert.equal(sent[3].idempotencyKey,'original-order-attempt');
 assert.throws(()=>sdk.startPayment('order','alipay',{presentation:'NATIVE_QR'}));assert.throws(()=>sdk.startPayment('order','wechat-pay',{presentation:'NATIVE_QR',returnUrl:'https://example.test'}));
});
test('QR decoder permits only the exact Native WeChat target and retains expiry as display metadata',()=>{
 const session={redirectUrl:null,clientPayload:{presentation:'NATIVE_QR',codeUrl:'weixin://wxpay/bizpayurl?pr=synthetic',expiresAt:'2026-10-28T00:15:00Z'}};
 assert.equal(readWechatNativeQr(session).codeUrl,session.clientPayload.codeUrl);
 for(const codeUrl of ['javascript:alert(1)','https://example.test/','weixin://wxpay/bizpayurl','weixin://other/bizpayurl?pr=synthetic'])assert.throws(()=>readWechatNativeQr({...session,clientPayload:{...session.clientPayload,codeUrl}}));
 assert.throws(()=>readWechatNativeQr({...session,redirectUrl:'https://example.test'}));assert.throws(()=>readWechatNativeQr({...session,clientPayload:{...session.clientPayload,expiresAt:'invalid'}}));
});
