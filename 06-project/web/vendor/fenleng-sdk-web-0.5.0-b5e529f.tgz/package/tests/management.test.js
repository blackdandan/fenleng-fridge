import test from 'node:test';
import assert from 'node:assert/strict';
import {ApplicationManagementSDK} from '../src/management.js';
test('management scope cannot be changed by query, IDs are encoded, writes require idempotency',async()=>{
 const calls=[];const sdk=new ApplicationManagementSDK({request:async(...args)=>{calls.push(args);return {items:[],total:0};}},{applicationId:'app/one'});
 await sdk.users({q:'a+b',offset:20,limit:10});await sdk.user('other/user');
 assert.equal(calls[0][0],'/api/platform/v1/admin/applications/app%2Fone/management/users?q=a%2Bb&offset=20&limit=10');
 assert.ok(calls[1][0].endsWith('/users/other%2Fuser'));
 assert.throws(()=>sdk.updateCatalog({}),/idempotencyKey/);
 await sdk.stepUp('test-only');assert.equal(calls[2][0],'/api/platform/v1/auth/step-up');
 await sdk.updateCatalog({priceId:'p'},{idempotencyKey:'test-key-001'});assert.equal(calls[3][3].idempotencyKey,'test-key-001');
});
test('expired app management token refreshes once through the host session',async()=>{
 let calls=0,refreshes=0;const sdk=new ApplicationManagementSDK({request:async()=>{calls++;if(calls===1)throw {status:401};return {activeAdministrator:true};}},{applicationId:'app',refreshSession:async()=>{refreshes++;}});
 assert.equal((await sdk.context()).activeAdministrator,true);assert.equal(refreshes,1);assert.equal(calls,2);
});

test('package provisioning stays application scoped and preserves recovery key and encoded package identity',async()=>{
 const calls=[];const sdk=new ApplicationManagementSDK({request:async(...args)=>{calls.push(args);return {ready:true};}},{applicationId:'app/one'});
 await sdk.packageCatalog('pack/one');assert.ok(calls[0][0].endsWith('/management/catalog/packages/pack%2Fone'));
 assert.throws(()=>sdk.provisionPackageCatalog('pack',{}),/idempotencyKey/);
 const input={sourcePriceId:'template',name:'Custom',units:7,amountMinor:12900};await sdk.provisionPackageCatalog('pack/one',input,{idempotencyKey:'package-test-001'});
 assert.equal(calls[1][1],'PUT');assert.deepEqual(calls[1][2],input);assert.equal(calls[1][3].idempotencyKey,'package-test-001');
});

test('observed activity and retention remain additive scoped read operations',async()=>{
 const calls=[];const sdk=new ApplicationManagementSDK({request:async(...args)=>{calls.push(args);return {items:[]};}},{applicationId:'app/one'});
 await sdk.activityAnalytics({days:30,platform:'web'});await sdk.retentionAnalytics({days:7});await sdk.analytics({days:7});
 assert.equal(calls[0][0],'/api/platform/v1/admin/applications/app%2Fone/management/analytics/activity?days=30&platform=web');
 assert.equal(calls[1][0],'/api/platform/v1/admin/applications/app%2Fone/management/analytics/retention?days=7');
 assert.equal(calls[2][0],'/api/platform/v1/admin/applications/app%2Fone/management/analytics?days=7');
 assert.ok(calls.every(call=>call[1]==='GET'&&call[2]===null));
});
