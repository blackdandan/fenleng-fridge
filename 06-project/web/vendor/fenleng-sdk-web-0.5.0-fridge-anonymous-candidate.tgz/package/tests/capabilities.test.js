import assert from 'node:assert/strict';import test from 'node:test';import {EntitlementSDK,FeatureFlagSDK,FeedbackSDK,FenlengBaseClient,WebPaymentCoordinator,WebSessionCoordinator} from '../index.js';
function json(value){return new Response(JSON.stringify(value),{status:200});}
test('stale entitlements never authorize feature experience',async()=>{let now=0;const client=new FenlengBaseClient({baseUrl:'http://localhost',fetch:async()=>json({items:[{entitlements:{pro:true,quota:3}}]})});const sdk=new EntitlementSDK(client,{applicationId:'app-1',maxAgeMs:10,clock:()=>now});await sdk.refresh();assert.deepEqual(sdk.has('pro'),{allowed:true,freshness:'FRESH'});now=11;assert.deepEqual(sdk.has('pro'),{allowed:false,freshness:'STALE'});});
test('kill switch and stale high-risk flags fail closed with one exposure',async()=>{let now=0,exposures=0;const client=new FenlengBaseClient({baseUrl:'http://localhost',fetch:async()=>json({flags:{safe:{enabled:true},payment:{enabled:true}},killSwitches:['payment']})});const sdk=new FeatureFlagSDK(client,{clock:()=>now,maxAgeMs:10,exposure:()=>exposures++});await sdk.refresh();assert.equal(sdk.evaluate('payment',{highRisk:true}).value,false);sdk.evaluate('safe');sdk.evaluate('safe');assert.equal(exposures,2);now=20;assert.equal(sdk.evaluate('safe',{highRisk:true}).value,false);});
test('feedback attachments require explicit consent',()=>{const client=new FenlengBaseClient({baseUrl:'http://localhost',fetch:async()=>json({})});const feedback=new FeedbackSDK(client,{projectId:'demo',version:'1.0.0'});assert.throws(()=>feedback.submit({message:'broken',screenshot:'data'}),error=>error.code==='ATTACHMENT_CONSENT_REQUIRED');});
test('multi-tab session coordinator broadcasts logout',async()=>{const sent=[];const auth={logout:async()=>{},getCurrentSession:async()=>null};const sdk=new WebSessionCoordinator(auth,{channelFactory:()=>({postMessage:value=>sent.push(value),close(){}})});let event;sdk.subscribe(value=>event=value);await sdk.logout();assert.equal(sent[0].type,'SESSION_ENDED');assert.equal(event.type,'SESSION_ENDED');});
test('checkout deduplicates clicks and return trusts server state only',async()=>{let creates=0;const commerce={createOrder:async()=>{creates++;return{id:'order-1'};},startPayment:async()=>({redirectUrl:'https://pay.test'}),waitForFinalOrder:async id=>({id,status:'PAID'})};const sdk=new WebPaymentCoordinator(commerce,{allowedReturnOrigins:['https://app.test']});await Promise.all([sdk.checkout('price','wechat',{returnUrl:'https://app.test/pay-return',idempotencyKey:'idem-123'}),sdk.checkout('price','wechat',{returnUrl:'https://app.test/pay-return',idempotencyKey:'idem-123'})]);assert.equal(creates,1);assert.equal((await sdk.recoverReturn('https://app.test/pay-return?orderId=order-1&success=true')).status,'PAID');assert.throws(()=>sdk.checkout('price','wechat',{returnUrl:'https://evil.test',idempotencyKey:'idem'}),error=>error.code==='RETURN_ORIGIN_DENIED');});

test('checkout rejects a changed agreement while the same order key is in flight', async () => {
  let finish;
  let captured;
  const pending = new Promise(resolve => { finish = resolve; });
  const sdk = new WebPaymentCoordinator({
    createOrder: async (_price, _key, options) => { captured = options.agreementConfirmation; await pending; return { id: 'order' }; },
    startPayment: async () => ({ status: 'PENDING' }),
  });
  const confirmation = { documentId: 'basic', documentVersion: 'v1', contentSha256: 'a'.repeat(64), accepted: true };
  const purchase = sdk.checkout('price', 'alipay', { idempotencyKey: 'same-key', agreementConfirmation: confirmation });
  confirmation.documentVersion = 'v2';
  assert.throws(() => sdk.checkout('price', 'alipay', { idempotencyKey: 'same-key', agreementConfirmation: confirmation }), { code: 'IDEMPOTENCY_KEY_REUSED' });
  assert.equal(captured.documentVersion, 'v1');
  finish();
  await purchase;
});
