import assert from 'node:assert/strict';
import test from 'node:test';
import { AuthSDK, CommerceSDK, FenlengBaseClient, MemoryStorageAdapter } from '../index.js';

function response(value, status = 200) { return new Response(JSON.stringify(value), {status, headers: {'content-type': 'application/json'}}); }
test('Web AuthSDK stores real platform tokens and deduplicates concurrent refresh', async () => {
  let refreshes = 0;
  const client = new FenlengBaseClient({baseUrl: 'http://localhost:8080', fetch: async (url) => url.endsWith('/auth/login') ? response({accessToken:'access-1', refreshToken:'refresh-1'}) : (refreshes++, response({accessToken:'access-2', refreshToken:'refresh-2'}))});
  const auth = new AuthSDK(client, {applicationCode:'demo-app', clientId:'web-client'});
  await auth.loginWithPassword('user@example.com', 'secret');
  assert.equal((await auth.getCurrentSession()).status, 'AUTHENTICATED');
  await Promise.all([auth.refresh(), auth.refresh()]);
  assert.equal(refreshes, 1);
  assert.equal(await client.storage.getItem(client.tokenKey), 'access-2');
});

test('Web CommerceSDK trusts only final platform state', async () => {
  const calls = [];
  const client = new FenlengBaseClient({baseUrl:'http://localhost:8080', fetch: async (url, init) => { calls.push({url, init}); return response({id:'order-1', status:'PENDING'}); }});
  const commerce = new CommerceSDK(client);
  const order = await commerce.createOrder('price-1', 'idempotent-123');
  assert.equal(order.status, 'PENDING');
  assert.equal(calls[0].init.headers['Idempotency-Key'], 'idempotent-123');
});

test('Web AuthSDK performs WeChat QR OAuth with state validation and server-only code exchange', async () => {
  const oauthStateStorage = new MemoryStorageAdapter();
  const calls = [];
  const client = new FenlengBaseClient({baseUrl:'http://localhost:8080', fetch: async (url, init) => {
    calls.push({url, init});
    return response({accessToken:'wechat-access', refreshToken:'wechat-refresh'});
  }});
  const auth = new AuthSDK(client, {applicationCode:'demo-app', clientId:'web-client', wechatAppId:'wx-web-app', oauthStateStorage});
  const authorizationUrl = new URL(await auth.beginWechatLogin({redirectUri:'https://app.example.com/auth/wechat/callback'}));
  assert.equal(authorizationUrl.origin, 'https://open.weixin.qq.com');
  assert.equal(authorizationUrl.pathname, '/connect/qrconnect');
  assert.equal(authorizationUrl.searchParams.get('appid'), 'wx-web-app');
  assert.equal(authorizationUrl.searchParams.get('scope'), 'snsapi_login');
  const state = authorizationUrl.searchParams.get('state');
  await auth.completeWechatLogin({code:'temporary-wechat-code', state});
  assert.equal(calls[0].url, 'http://localhost:8080/api/platform/v1/auth/wechat/login');
  assert.deepEqual(JSON.parse(calls[0].init.body), {applicationCode:'demo-app', clientId:'web-client', code:'temporary-wechat-code'});
  assert.equal(await client.storage.getItem(client.tokenKey), 'wechat-access');
  assert.equal(await oauthStateStorage.getItem(`${client.tokenKey}:wechat-oauth-state`), null);
});

test('Web AuthSDK rejects a forged WeChat callback before exchanging its code', async () => {
  const oauthStateStorage = new MemoryStorageAdapter();
  let requests = 0;
  const client = new FenlengBaseClient({baseUrl:'http://localhost:8080', fetch: async () => { requests += 1; return response({}); }});
  const auth = new AuthSDK(client, {applicationCode:'demo-app', clientId:'web-client', wechatAppId:'wx-web-app', oauthStateStorage});
  await auth.beginWechatLogin({redirectUri:'https://app.example.com/auth/wechat/callback'});
  await assert.rejects(auth.completeWechatLogin({code:'temporary-wechat-code', state:'A'.repeat(43)}), {code:'WECHAT_OAUTH_STATE_MISMATCH'});
  assert.equal(requests, 0);
});

test('Web AuthSDK verifies email before registration and exposes account deletion', async () => {
  const calls = [];
  const client = new FenlengBaseClient({baseUrl:'http://localhost:8080', fetch:async(url, init)=>{calls.push({url, init}); return response(url.endsWith('/auth/register')?{userId:'new-user',accessToken:'registered-access',refreshToken:'registered-refresh'}:{acknowledged:true});}});
  const auth = new AuthSDK(client, {applicationCode:'demo-app', clientId:'web-client'});
  await auth.requestRegistrationEmailVerification('user@example.com');
  await auth.register({email:'user@example.com', password:'strong-password', username:'person', displayName:'Person', verificationCode:'123456'});
  assert.equal(await client.storage.getItem(client.tokenKey),'registered-access');
  assert.equal(await client.storage.getItem(`${client.tokenKey}:refresh`),'registered-refresh');
  await auth.requestAccountDeletion('delete-account-1');
  assert.deepEqual(calls.map(({url}) => url), [
    'http://localhost:8080/api/platform/v1/auth/registration-email-verification',
    'http://localhost:8080/api/platform/v1/auth/register',
    'http://localhost:8080/api/platform/v1/users/me/data-requests',
  ]);
  assert.equal(JSON.parse(calls[1].init.body).verificationCode, '123456');
  assert.equal(calls[2].init.headers['Idempotency-Key'], 'delete-account-1');
});

test('federated deletion challenge and proof keep existing tokens and bind exact deletion intent', async () => {
  const calls=[];const storage=new MemoryStorageAdapter();
  const client=new FenlengBaseClient({baseUrl:'http://localhost:8080',storage,fetch:async(url,init)=>{
    calls.push({url,method:init.method,body:JSON.parse(init.body),headers:init.headers});
    return response(url.endsWith('/confirm')?{confirmationId:'fdc-once',deletionIdempotencyKey:'delete-intent',expiresAt:'2026-10-26T08:05:00Z'}:{challengeId:'fdc-once',provider:'FIREBASE',nonce:'server-nonce',expiresAt:'2026-10-26T08:05:00Z'});
  }});
  await storage.setItem(client.tokenKey,'existing-access');await storage.setItem(`${client.tokenKey}:refresh`,'existing-refresh');
  const auth=new AuthSDK(client,{applicationCode:'demo-app',clientId:'web-client'});
  const challenge=await auth.createFederatedDeletionChallenge('FIREBASE','delete-intent');
  const confirmation=await auth.confirmFederatedDeletionReauthentication(challenge.challengeId,'fresh-private-token');
  assert.equal(confirmation.confirmationId,'fdc-once');assert.equal(calls.length,2);
  assert.deepEqual(calls[0].body,{provider:'FIREBASE',deletionIdempotencyKey:'delete-intent'});
  assert.deepEqual(calls[1].body,{identityToken:'fresh-private-token'});
  assert.ok(calls[1].url.endsWith('/auth/step-up/self-deletion/challenges/fdc-once/confirm'));
  assert.equal(await storage.getItem(client.tokenKey),'existing-access');assert.equal(await storage.getItem(`${client.tokenKey}:refresh`),'existing-refresh');
});
test('invalid federated deletion input never dispatches a request',()=>{
  let calls=0;const client=new FenlengBaseClient({baseUrl:'http://localhost:8080',fetch:async()=>{calls++;return response({});}});
  const auth=new AuthSDK(client,{applicationCode:'demo-app',clientId:'web-client'});
  for(const args of [['WECHAT','delete-intent'],['FIREBASE','short']])assert.throws(()=>auth.createFederatedDeletionChallenge(...args));
  for(const args of [['fdc-one/other','token'],['fdc-one',''],['password-confirm','token']])assert.throws(()=>auth.confirmFederatedDeletionReauthentication(...args));
  assert.equal(calls,0);
});
