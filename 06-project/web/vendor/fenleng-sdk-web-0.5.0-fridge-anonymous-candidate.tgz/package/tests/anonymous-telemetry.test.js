import test from 'node:test';
import assert from 'node:assert/strict';
import { FenlengBaseClient, WebAnonymousTelemetrySDK } from '../index.js';
const context = () => ({platform:'web',appVersion:'1.0',buildNumber:'1',releaseChannel:'china',locale:'zh-CN'});
function fixture(fetch,extra={}) {
  const client = new FenlengBaseClient({baseUrl:'https://identity.test',authMode:'anonymous',maxRetries:0,storage:{getItem(){throw Error('must not read business storage');}},fetch});
  return new WebAnonymousTelemetrySDK(client,{clientId:'patent-website',catalog:['website.page.viewed.v1'],consent:()=>true,context,...extra});
}
test('anonymous logger is inert without consent and sends no account credentials or product id',async()=>{
  const calls=[];let consent=false;
  const logger=fixture(async(url,options)=>{calls.push({url,options});return Response.json({accepted:1});},{consent:()=>consent});
  assert.equal(logger.track('website.page.viewed.v1',{page:'home'}),null);assert.equal(await logger.flush(),0);assert.equal(calls.length,0);
  consent=true;logger.track('website.page.viewed.v1',{page:'home'});assert.equal(await logger.flush(),1);
  const {url,options}=calls[0];assert.ok(url.endsWith('/telemetry/anonymous/events'));assert.equal(options.credentials,'omit');assert.equal(options.headers['X-Fenleng-Client-Id'],'patent-website');assert.equal(options.headers.Authorization,undefined);
  const body=JSON.parse(options.body);assert.deepEqual(Object.keys(body),['events']);assert.match(body.events[0].eventId,/^[0-9a-f-]{36}$/);assert.equal(body.events[0].context.sessionId,undefined);
});
test('unknown result retries preserve event ids and require exact server acknowledgement',async()=>{
  const calls=[];let failures=2;
  const logger=fixture(async(_url,options)=>{calls.push(options);if(failures-->1)throw Error('lost response');return Response.json({accepted:failures===0?0:1});});
  logger.track('website.page.viewed.v1',{page:'home'});
  await assert.rejects(logger.flush(),e=>e.code==='NETWORK_ERROR');assert.equal(logger.pendingCount,1);
  await assert.rejects(logger.flush(),e=>e.code==='INVALID_RESPONSE');assert.equal(logger.pendingCount,1);
  assert.equal(await logger.flush(),1);assert.equal(logger.pendingCount,0);
  assert.equal(calls[0].body,calls[1].body);assert.equal(calls[1].body,calls[2].body);assert.equal(calls[0].headers['Idempotency-Key'],calls[2].headers['Idempotency-Key']);
});
test('withdrawal during asynchronous batch preparation never starts delivery',async()=>{
  let calls=0;let consent=true;
  const logger=fixture(async()=>{calls++;return Response.json({accepted:1});},{consent:()=>consent});
  logger.track('website.page.viewed.v1',{page:'home'});const pending=logger.flush();consent=false;logger.withdrawConsent();
  consent=true;logger.track('website.page.viewed.v1',{page:'missing'});
  await assert.rejects(pending,e=>e.code==='REQUEST_CANCELLED');assert.equal(calls,0);assert.equal(logger.pendingCount,1);assert.equal(await logger.flush(),1);
});
test('anonymous mode rejects credential override and logger rejects identity contexts and sensitive data',async()=>{
  const client=new FenlengBaseClient({baseUrl:'https://identity.test',authMode:'anonymous',fetch:async()=>{throw Error('must not fetch');}});
  await assert.rejects(client.request('/public','POST',{}, {headers:{Authorization:'Bearer secret'}}),e=>e.code==='CONFIGURATION_INVALID');
  await assert.rejects(client.request('/public','POST',{}, {credentials:'include'}),e=>e.code==='CONFIGURATION_INVALID');
  assert.throws(()=>new WebAnonymousTelemetrySDK(new FenlengBaseClient({baseUrl:'https://identity.test'}),{clientId:'patent-website',context}),e=>e.code==='CONFIGURATION_INVALID');
  for(const value of [{...context(),sessionId:'session-123'},{...context(),platform:'android'}])assert.throws(()=>fixture(async()=>{}, {context:()=>value}).track('website.page.viewed.v1',{}),e=>e.code==='TELEMETRY_CONTEXT_INVALID');
  assert.throws(()=>fixture(async()=>{}).track('website.page.viewed.v1',{email:'private@test.invalid'}),e=>e.code==='TELEMETRY_SENSITIVE_FIELD_REJECTED');
});
