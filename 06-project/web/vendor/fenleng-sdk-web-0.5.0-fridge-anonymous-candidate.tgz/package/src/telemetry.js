import { FenlengTelemetryLogger } from '@fenleng/sdk-core';

export class WebTelemetrySDK extends FenlengTelemetryLogger {
  constructor(client, options) {
    super(client, options);
  }
}
