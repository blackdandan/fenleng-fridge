import { FenlengSSEClient } from '@fenleng/sdk-core';

export class WebAIServiceSDK extends FenlengSSEClient {
  constructor(client) {
    super(client);
  }
}
