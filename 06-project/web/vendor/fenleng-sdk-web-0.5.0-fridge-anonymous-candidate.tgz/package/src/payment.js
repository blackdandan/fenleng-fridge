import { FenlengSdkError } from '@fenleng/sdk-core';

export class WebPaymentCoordinator {
  constructor(commerce, { allowedReturnOrigins = [] } = {}) {
    this.commerce = commerce;
    this.allowedReturnOrigins = new Set(allowedReturnOrigins);
    this.inFlight = new Map();
    this.fingerprints = new Map();
  }

  checkout(priceOptionId, provider, { returnUrl, idempotencyKey, agreementConfirmation, mode = 'REDIRECT' } = {}) {
    if (!['REDIRECT', 'QR', 'POPUP'].includes(mode)) throw new FenlengSdkError('PAYMENT_MODE_UNSUPPORTED', 'Unsupported checkout mode');
    if (returnUrl && !this.allowedReturnOrigins.has(new URL(returnUrl).origin)) throw new FenlengSdkError('RETURN_ORIGIN_DENIED', 'Return URL origin is not allowed');
    const confirmation = agreementConfirmation == null ? undefined : Object.freeze({ ...agreementConfirmation });
    const fingerprint = JSON.stringify([priceOptionId, provider, returnUrl, mode,
      confirmation?.documentId, confirmation?.documentVersion, confirmation?.contentSha256, confirmation?.accepted]);
    if (this.inFlight.has(idempotencyKey)) {
      if (this.fingerprints.get(idempotencyKey) !== fingerprint) {
        throw new FenlengSdkError('IDEMPOTENCY_KEY_REUSED', 'Checkout key is already used with different purchase details');
      }
      return this.inFlight.get(idempotencyKey);
    }
    const operation = (async () => {
      const order = await this.commerce.createOrder(priceOptionId, idempotencyKey, { agreementConfirmation: confirmation });
      const started = await this.commerce.startPayment(order.id, provider, { returnUrl, idempotencyKey: `${idempotencyKey}:payment` });
      return { mode, order, started };
    })().finally(() => {
      this.inFlight.delete(idempotencyKey);
      this.fingerprints.delete(idempotencyKey);
    });
    this.fingerprints.set(idempotencyKey, fingerprint);
    this.inFlight.set(idempotencyKey, operation);
    return operation;
  }

  async recoverReturn(url, { signal } = {}) {
    const parsed = new URL(url);
    const orderId = parsed.searchParams.get('orderId');
    if (!orderId) throw new FenlengSdkError('PAYMENT_RETURN_INVALID', 'orderId is missing');
    return this.commerce.waitForFinalOrder(orderId, { signal });
  }
}
