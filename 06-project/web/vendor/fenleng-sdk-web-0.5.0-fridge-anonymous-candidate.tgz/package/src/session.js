import { FenlengSdkError } from '@fenleng/sdk-core';
export class WebSessionCoordinator {
  constructor(auth,{channelFactory=name=>new BroadcastChannel(name),channelName='fenleng.identity'}={}){this.auth=auth;this.listeners=new Set();this.channel=channelFactory?.(channelName);if(this.channel)this.channel.onmessage=event=>this.notify(event.data);}
  subscribe(listener){this.listeners.add(listener);return()=>this.listeners.delete(listener);}
  async logout(options={}){await this.auth.logout(options);this.channel?.postMessage({type:'SESSION_ENDED'});this.notify({type:'SESSION_ENDED'});}
  session(){return this.auth.getCurrentSession();}
  can(actor,scope){return Boolean(actor?.scopes?.includes(scope));}
  require(actor,scope){if(!this.can(actor,scope))throw new FenlengSdkError('PERMISSION_DENIED',`Missing scope ${scope}`,{status:403});}
  notify(event){for(const listener of this.listeners)listener(event);}
  close(){this.channel?.close();this.listeners.clear();}
}
export function createAuthExternalStore(coordinator){let snapshot=null;const listeners=new Set();const unsubscribe=coordinator.subscribe(event=>{snapshot=event;for(const listener of listeners)listener();});return{subscribe(listener){listeners.add(listener);return()=>listeners.delete(listener);},getSnapshot(){return snapshot;},destroy(){unsubscribe();listeners.clear();}};}
