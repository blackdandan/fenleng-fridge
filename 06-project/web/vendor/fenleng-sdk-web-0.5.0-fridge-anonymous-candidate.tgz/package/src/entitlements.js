export class EntitlementSDK {
  constructor(client,{applicationId,maxAgeMs=60_000,clock=()=>Date.now()}={}){if(!client||!applicationId)throw new Error('client and applicationId are required');this.client=client;this.applicationId=applicationId;this.maxAgeMs=maxAgeMs;this.clock=clock;this.snapshot=null;this.listeners=new Set();}
  async refresh(options={}){const page=await this.client.request(`/api/platform/v1/applications/${encodeURIComponent(this.applicationId)}/entitlements/me`,'GET',null,options);this.snapshot={items:page.items||[],fetchedAt:this.clock(),freshness:'FRESH'};for(const listener of this.listeners)listener(this.snapshot);return this.snapshot;}
  current(){if(!this.snapshot)return{items:[],fetchedAt:null,freshness:'MISSING'};return{...this.snapshot,freshness:this.clock()-this.snapshot.fetchedAt<=this.maxAgeMs?'FRESH':'STALE'};}
  has(feature){const snapshot=this.current();const now=new Date(this.clock()).getTime();return{allowed:snapshot.freshness==='FRESH'&&snapshot.items.some(item=>item.entitlements?.[feature]===true&&(!item.validFrom||new Date(item.validFrom).getTime()<=now)&&(!item.validUntil||new Date(item.validUntil).getTime()>now||new Date(item.graceUntil||0).getTime()>now)),freshness:snapshot.freshness};}
  quota(key){const snapshot=this.current();const values=snapshot.items.map(item=>item.entitlements?.[key]).filter(Number.isFinite);return{value:values.length?Math.max(...values):0,freshness:snapshot.freshness};}
  subscribe(listener){this.listeners.add(listener);return()=>this.listeners.delete(listener);}
}
