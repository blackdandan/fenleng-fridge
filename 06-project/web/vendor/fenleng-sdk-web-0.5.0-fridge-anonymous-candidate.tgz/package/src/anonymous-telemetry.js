import { FenlengTelemetryLogger, FenlengSdkError } from '@fenleng/sdk-core';

/** Public registered-client delivery. No user/session identity or storage is read. */
export class WebAnonymousTelemetrySDK extends FenlengTelemetryLogger {
  constructor(client, { clientId, context, ...options } = {}) {
    if (client?.authMode !== 'anonymous' || !/^[A-Za-z0-9][A-Za-z0-9._:-]{2,127}$/.test(clientId || '') || typeof context !== 'function') {
      throw new FenlengSdkError('CONFIGURATION_INVALID', 'Anonymous telemetry requires an anonymous client and registered clientId');
    }
    const eventIds = new WeakMap();
    let logger;
    const transport = {
      async request(_endpoint, _method, body, requestOptions = {}) {
        const generation = logger.consentGeneration;
        const events = body.events.map(event => {
          if (!eventIds.has(event)) eventIds.set(event, globalThis.crypto.randomUUID());
          return { ...event, eventId: eventIds.get(event) };
        });
        const digest = await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(events.map(event => event.eventId).join(',')));
        if (generation !== logger.consentGeneration || !logger.consent()) throw new FenlengSdkError('REQUEST_CANCELLED', 'Telemetry consent changed');
        const key = `telemetry-${Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('')}`;
        const result = await client.request('/api/platform/v1/telemetry/anonymous/events', 'POST', { events }, {
          ...requestOptions,
          idempotencyKey: key,
          credentials: 'omit',
          headers: { ...requestOptions.headers, 'X-Fenleng-Client-Id': clientId },
        });
        if (!result || result.accepted !== events.length) throw new FenlengSdkError('INVALID_RESPONSE', 'Anonymous telemetry acknowledgement is invalid');
        return result;
      },
    };
    super(transport, { ...options, context: () => {
      const value = context();
      if (value?.platform !== 'web' || value?.sessionId != null) throw new FenlengSdkError('TELEMETRY_CONTEXT_INVALID', 'Anonymous web telemetry cannot carry a session');
      return value;
    } });
    logger = this;
  }
}
