import { FenlengSdkError } from '@fenleng/sdk-core';

export class CommerceSDK {
  constructor(client) { if (!client) throw new FenlengSdkError('CONFIGURATION_INVALID', 'CommerceSDK requires a configured client'); this.client = client; }
  createOrder(priceOptionId, idempotencyKey, {agreementConfirmation, ...options} = {}) { return this.client.request('/api/platform/v1/commerce/orders', 'POST', {priceOptionId, ...(agreementConfirmation ? {agreementConfirmation} : {})}, {...options, idempotencyKey}); }
  purchaseAgreement(priceOptionId, options = {}) { return this.client.request(`/api/platform/v1/commerce/prices/${encodeURIComponent(priceOptionId)}/purchase-agreement`, 'GET', null, options); }
  order(orderId, options = {}) { return this.client.request(`/api/platform/v1/commerce/orders/${encodeURIComponent(orderId)}`, 'GET', null, options); }
  startPayment(orderId, provider, {returnUrl = null, idempotencyKey, ...options} = {}) { return this.client.request('/api/platform/v1/commerce/payments', 'POST', {orderId, provider, returnUrl}, {...options, idempotencyKey}); }
  payment(attemptId, options = {}) { return this.client.request(`/api/platform/v1/commerce/payments/${encodeURIComponent(attemptId)}`, 'GET', null, options); }
  verifyPurchase(attemptId, purchaseToken, {idempotencyKey, ...options} = {}) { return this.client.request(`/api/platform/v1/commerce/payments/${encodeURIComponent(attemptId)}/verify`, 'POST', {purchaseToken}, {...options, idempotencyKey}); }
  subscription(options = {}) { return this.client.request('/api/platform/v1/commerce/subscription', 'GET', null, options); }
  entitlements(applicationId, options = {}) { return this.client.request(`/api/platform/v1/applications/${encodeURIComponent(applicationId)}/entitlements/me`, 'GET', null, options); }
  async waitForFinalOrder(orderId, {signal, attempts = 8} = {}) {
    for (let count = 0; count < attempts; count += 1) {
      const order = await this.order(orderId, {signal});
      if (['PAID', 'CANCELLED', 'EXPIRED', 'FAILED', 'REFUNDED'].includes(order.status)) return order;
      await new Promise((resolve, reject) => { const timer = setTimeout(resolve, Math.min(500 * 2 ** count, 5000)); signal?.addEventListener('abort', () => { clearTimeout(timer); reject(signal.reason); }, {once: true}); });
    }
    throw new FenlengSdkError('ORDER_STATUS_UNKNOWN', 'Order did not reach a final server state', {retryable: true});
  }
}
