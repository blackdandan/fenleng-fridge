import { FenlengSdkError } from '@fenleng/sdk-core';
export class NotificationSDK {
  constructor(client){this.client=client;}
  registerSubscription(subscription,{deviceId,idempotencyKey,...options}){if(!subscription?.endpoint)throw new FenlengSdkError('SUBSCRIPTION_INVALID','Push endpoint is required');return this.client.request('/api/platform/v1/users/me/notification-subscriptions','POST',{channel:'WEB_PUSH',deviceId,endpoint:subscription.endpoint,keys:subscription.keys},{...options,idempotencyKey});}
  unregister(id,{idempotencyKey,...options}){return this.client.request(`/api/platform/v1/users/me/notification-subscriptions/${encodeURIComponent(id)}`,'DELETE',null,{...options,idempotencyKey});}
  preferences(options={}){return this.client.request('/api/platform/v1/users/me/consents','GET',null,options);}
  updatePreference(purpose,enabled,policyVersion,options={}){return this.client.request('/api/platform/v1/users/me/consents','PUT',{purpose,granted:enabled,policyVersion,notificationEnabled:enabled},options);}
  inbox(cursor,options={}){return this.client.request(`/api/platform/v1/users/me/notifications${cursor?`?cursor=${encodeURIComponent(cursor)}`:''}`,'GET',null,options);}
}
export class FeedbackSDK {
  constructor(client,{projectId,version,traceId}={}){if(!projectId||!version)throw new FenlengSdkError('CONFIGURATION_INVALID','projectId and version are required');this.client=client;this.context={projectId,version,traceId};}
  submit({message,category='GENERAL',screenshot,logs,attachmentConsent=false,idempotencyKey,...options}){if((screenshot||logs)&&!attachmentConsent)throw new FenlengSdkError('ATTACHMENT_CONSENT_REQUIRED','Attachment consent is required');return this.client.request('/api/platform/v1/feedback','POST',{...this.context,message,category,attachmentConsent,attachments:[screenshot&&{type:'SCREENSHOT',content:screenshot},logs&&{type:'LOGS',content:logs}].filter(Boolean)},{...options,idempotencyKey});}
}
