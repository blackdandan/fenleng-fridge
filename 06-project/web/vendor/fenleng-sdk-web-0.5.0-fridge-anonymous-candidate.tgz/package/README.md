# `@fenleng/sdk-web`

Fenleng Web / TypeScript 官方客户端 SDK。导出 `AuthSDK`、`CommerceSDK`、`WebTelemetrySDK` 和 `WebAIServiceSDK`。

## 微信扫码登录

浏览器端只配置微信开放平台的公开 `AppID`；`AppSecret` 只保存在 Shared Platform。SDK 使用 `snsapi_login` 发起扫码 OAuth，保存一次性 state 到 `sessionStorage`，并且只有回调 state 通过校验后才将临时 code 交给平台交换 Fenleng token。

```js
const auth = new AuthSDK(client, {
  applicationCode: 'your-app',
  clientTarget: 'web',
  wechatAppId: 'wx-your-web-app',
});

// 登录按钮：跳转到微信扫码页。
location.assign(await auth.beginWechatLogin({
  redirectUri: 'https://app.example.com/auth/wechat/callback',
}));

// 回调页：读取 ?code= 和 ?state=，校验 state 后换取平台 session。
const query = new URLSearchParams(location.search);
await auth.completeWechatLogin({
  code: query.get('code'),
  state: query.get('state'),
});
```

回调地址必须为在微信开放平台登记的 HTTPS 地址。需要由宿主自行处理用户取消或微信返回的 `error` 参数；不要在浏览器中配置或传递 `AppSecret`。
